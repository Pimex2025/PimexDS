<?php
// models/Noticia.php
class Noticia {
    private $conn;
    private $table = "noticias";
    
    public $id;
    public $titulo;
    public $contenido;
    public $imagen;
    public $categoria;
    public $autor;
    public $fecha_publicacion;
    public $estado;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Crear noticia
    public function crear() {
        $query = "INSERT INTO " . $this->table . " 
                 SET titulo=:titulo, contenido=:contenido, imagen=:imagen, 
                     categoria=:categoria, autor=:autor, estado=:estado";
        
        $stmt = $this->conn->prepare($query);
        
        // Limpiar datos
        $this->titulo = htmlspecialchars(strip_tags($this->titulo));
        $this->contenido = htmlspecialchars(strip_tags($this->contenido));
        $this->categoria = htmlspecialchars(strip_tags($this->categoria));
        $this->autor = htmlspecialchars(strip_tags($this->autor));
        
        // Bind parameters
        $stmt->bindParam(":titulo", $this->titulo);
        $stmt->bindParam(":contenido", $this->contenido);
        $stmt->bindParam(":imagen", $this->imagen);
        $stmt->bindParam(":categoria", $this->categoria);
        $stmt->bindParam(":autor", $this->autor);
        $stmt->bindParam(":estado", $this->estado);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }
    
    // Leer noticias
    public function leer() {
        $query = "SELECT * FROM " . $this->table . " 
                 WHERE estado = 'publicado' 
                 ORDER BY fecha_publicacion DESC 
                 LIMIT 10";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt;
    }
    
    // Leer noticia individual
    public function leerUno() {
        $query = "SELECT * FROM " . $this->table . " 
                 WHERE id = ? LIMIT 0,1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($row) {
            $this->titulo = $row['titulo'];
            $this->contenido = $row['contenido'];
            $this->imagen = $row['imagen'];
            $this->categoria = $row['categoria'];
            $this->autor = $row['autor'];
            $this->fecha_publicacion = $row['fecha_publicacion'];
            return true;
        }
        return false;
    }
}
?>