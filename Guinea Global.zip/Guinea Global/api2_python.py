# app.py - Rutas para noticias
from flask import Flask, request, jsonify, render_template
from flask_mysqldb import MySQL
import MySQLdb.cursors
import json
from datetime import datetime

app = Flask(__name__)

# Configuración de MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'tu_usuario'
app.config['MYSQL_PASSWORD'] = 'tu_contraseña'
app.config['MYSQL_DB'] = 'tu_base_de_datos'

mysql = MySQL(app)

# Obtener todas las noticias para el dashboard
@app.route('/api/news', methods=['GET'])
def get_news():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    
    # Parámetros de filtro
    category = request.args.get('category', '')
    status = request.args.get('status', '')
    search = request.args.get('search', '')
    page = int(request.args.get('page', 1))
    per_page = 10
    
    query = "SELECT * FROM news WHERE 1=1"
    params = []
    
    if category:
        query += " AND category = %s"
        params.append(category)
    
    if status:
        query += " AND status = %s"
        params.append(status)
    
    if search:
        query += " AND (title LIKE %s OR content LIKE %s)"
        params.extend([f'%{search}%', f'%{search}%'])
    
    query += " ORDER BY created_at DESC LIMIT %s OFFSET %s"
    params.extend([per_page, (page-1)*per_page])
    
    cursor.execute(query, params)
    news = cursor.fetchall()
    
    # Contar total para paginación
    count_query = "SELECT COUNT(*) as total FROM news WHERE 1=1"
    count_params = []
    
    if category:
        count_query += " AND category = %s"
        count_params.append(category)
    
    if status:
        count_query += " AND status = %s"
        count_params.append(status)
    
    if search:
        count_query += " AND (title LIKE %s OR content LIKE %s)"
        count_params.extend([f'%{search}%', f'%{search}%'])
    
    cursor.execute(count_query, count_params)
    total = cursor.fetchone()['total']
    
    cursor.close()
    
    return jsonify({
        'news': news,
        'total': total,
        'page': page,
        'per_page': per_page,
        'total_pages': (total + per_page - 1) // per_page
    })

# Obtener noticias por categoría para las páginas públicas
@app.route('/api/news/category/<category>')
def get_news_by_category(category):
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    
    cursor.execute("""
        SELECT * FROM news 
        WHERE category = %s AND status = 'published' 
        ORDER BY created_at DESC 
        LIMIT 20
    """, (category,))
    
    news = cursor.fetchall()
    cursor.close()
    
    return jsonify(news)

# Obtener una noticia específica
@app.route('/api/news/<int:news_id>')
def get_single_news(news_id):
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("SELECT * FROM news WHERE id = %s", (news_id,))
    news = cursor.fetchone()
    cursor.close()
    
    if news:
        return jsonify(news)
    else:
        return jsonify({'error': 'Noticia no encontrada'}), 404

# Crear o actualizar noticia
@app.route('/api/news', methods=['POST'])
@app.route('/api/news/<int:news_id>', methods=['PUT'])
def manage_news(news_id=None):
    data = request.json
    
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    
    try:
        if request.method == 'POST':
            # Crear nueva noticia
            cursor.execute("""
                INSERT INTO news (title, excerpt, content, category, image_url, status, author, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                data['title'],
                data['excerpt'],
                data['content'],
                data['category'],
                data.get('image_url', ''),
                data['status'],
                data.get('author', 'Admin'),
                datetime.now(),
                datetime.now()
            ))
            mysql.connection.commit()
            news_id = cursor.lastrowid
            
        else:  # PUT - Actualizar
            cursor.execute("""
                UPDATE news 
                SET title = %s, excerpt = %s, content = %s, category = %s, 
                    image_url = %s, status = %s, updated_at = %s
                WHERE id = %s
            """, (
                data['title'],
                data['excerpt'],
                data['content'],
                data['category'],
                data.get('image_url', ''),
                data['status'],
                datetime.now(),
                news_id
            ))
            mysql.connection.commit()
        
        cursor.close()
        return jsonify({'success': True, 'id': news_id})
        
    except Exception as e:
        mysql.connection.rollback()
        cursor.close()
        return jsonify({'error': str(e)}), 500

# Eliminar noticia
@app.route('/api/news/<int:news_id>', methods=['DELETE'])
def delete_news(news_id):
    cursor = mysql.connection.cursor()
    
    try:
        cursor.execute("DELETE FROM news WHERE id = %s", (news_id,))
        mysql.connection.commit()
        cursor.close()
        return jsonify({'success': True})
    except Exception as e:
        mysql.connection.rollback()
        cursor.close()
        return jsonify({'error': str(e)}), 500

# Rutas para las páginas públicas de categorías
@app.route('/deportes')
def deportes():
    return render_template('deportes.html')

@app.route('/politica')
def politica():
    return render_template('politica.html')

@app.route('/tecnologia')
def tecnologia():
    return render_template('tecnologia.html')

@app.route('/cultura')
def cultura():
    return render_template('cultura.html')

@app.route('/noticias')
def noticias():
    return render_template('noticias.html')

if __name__ == '__main__':
    app.run(debug=True)