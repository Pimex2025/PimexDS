<?php
// admin/media.php
require_once 'auth.php';
requireAuth();

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$current_user = getCurrentUser();

// Crear directorio de uploads si no existe
$upload_dir = '../uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Procesar subida de archivos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['media_files'])) {
    $uploaded_files = $_FILES['media_files'];
    $upload_errors = [];
    $upload_success = [];
    
    // Procesar cada archivo
    for ($i = 0; $i < count($uploaded_files['name']); $i++) {
        if ($uploaded_files['error'][$i] === UPLOAD_ERR_OK) {
            $file_name = $uploaded_files['name'][$i];
            $file_tmp = $uploaded_files['tmp_name'][$i];
            $file_size = $uploaded_files['size'][$i];
            $file_type = $uploaded_files['type'][$i];
            
            // Validar tipo de archivo
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
            if (!in_array($file_type, $allowed_types)) {
                $upload_errors[] = "Tipo de archivo no permitido: $file_name";
                continue;
            }
            
            // Validar tamaño (máximo 10MB)
            if ($file_size > 10 * 1024 * 1024) {
                $upload_errors[] = "Archivo demasiado grande: $file_name (máximo 10MB)";
                continue;
            }
            
            // Generar nombre único
            $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
            $unique_name = uniqid() . '_' . time() . '.' . $file_extension;
            $file_path = $upload_dir . $unique_name;
            
            // Mover archivo
            if (move_uploaded_file($file_tmp, $file_path)) {
                // Guardar en base de datos
                $insert_stmt = $db->prepare("INSERT INTO media (filename, original_name, file_path, file_type, file_size, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)");
                $insert_stmt->execute([$unique_name, $file_name, $file_path, $file_type, $file_size, $current_user['id']]);
                $upload_success[] = $file_name;
            } else {
                $upload_errors[] = "Error al subir: $file_name";
            }
        }
    }
    
    if (!empty($upload_success)) {
        $_SESSION['success_message'] = "Archivos subidos correctamente: " . implode(', ', $upload_success);
    }
    if (!empty($upload_errors)) {
        $_SESSION['error_message'] = implode('<br>', $upload_errors);
    }
    
    header('Location: media.php');
    exit;
}

// Procesar eliminación de archivo
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    // Obtener información del archivo
    $file_stmt = $db->prepare("SELECT * FROM media WHERE id = ?");
    $file_stmt->execute([$delete_id]);
    $file = $file_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($file) {
        // Eliminar archivo físico
        if (file_exists($file['file_path'])) {
            unlink($file['file_path']);
        }
        
        // Eliminar registro de la base de datos
        $delete_stmt = $db->prepare("DELETE FROM media WHERE id = ?");
        $delete_stmt->execute([$delete_id]);
        
        $_SESSION['success_message'] = "Archivo eliminado correctamente";
    } else {
        $_SESSION['error_message'] = "Archivo no encontrado";
    }
    
    header('Location: media.php');
    exit;
}

// Obtener archivos multimedia
$page = $_GET['page'] ?? 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$query = "
    SELECT m.*, u.full_name as uploaded_by_name 
    FROM media m 
    LEFT JOIN users u ON m.uploaded_by = u.id 
    ORDER BY m.uploaded_at DESC 
    LIMIT :limit OFFSET :offset
";
$stmt = $db->prepare($query);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$media_files = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener total para paginación
$count_stmt = $db->prepare("SELECT COUNT(*) as total FROM media");
$count_stmt->execute();
$total_count = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_count / $limit);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteca Multimedia - Guinea-global</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="dashboard">
    <!-- Dashboard Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Dashboard Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header">
            <div class="dashboard-welcome">
                <h1>Biblioteca Multimedia</h1>
                <p>Gestiona los archivos multimedia del sitio</p>
            </div>
        </header>

        <!-- Mensajes de éxito/error -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <div class="dashboard-content">
            <!-- Formulario de subida -->
            <section class="dashboard-section">
                <h2>Subir Archivos</h2>
                <form method="POST" enctype="multipart/form-data" class="upload-form">
                    <div class="form-group">
                        <label for="media_files">Seleccionar archivos (máximo 10MB por archivo)</label>
                        <input type="file" id="media_files" name="media_files[]" multiple accept="image/*,application/pdf">
                        <small>Formatos permitidos: JPG, PNG, GIF, WebP, PDF</small>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Subir Archivos</button>
                </form>
            </section>

            <!-- Galería de archivos -->
            <section class="dashboard-section">
                <div class="section-header">
                    <h2>Archivos Multimedia (<?php echo $total_count; ?>)</h2>
                </div>
                
                <?php if (empty($media_files)): ?>
                    <div class="no-data">
                        <i class="fas fa-images fa-3x"></i>
                        <p>No hay archivos multimedia</p>
                    </div>
                <?php else: ?>
                    <div class="media-grid">
                        <?php foreach ($media_files as $file): ?>
                        <div class="media-item">
                            <div class="media-preview">
                                <?php if (strpos($file['file_type'], 'image/') === 0): ?>
                                    <img src="<?php echo $file['file_path']; ?>" alt="<?php echo htmlspecialchars($file['original_name']); ?>">
                                <?php else: ?>
                                    <div class="file-icon">
                                        <i class="fas fa-file-pdf fa-3x"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="media-info">
                                <h4><?php echo htmlspecialchars($file['original_name']); ?></h4>
                                <div class="file-details">
                                    <span><?php echo round($file['file_size'] / 1024, 2); ?> KB</span>
                                    <span><?php echo date('d/m/Y H:i', strtotime($file['uploaded_at'])); ?></span>
                                </div>
                                <div class="file-actions">
                                    <a href="<?php echo $file['file_path']; ?>" target="_blank" class="btn btn-sm btn-view" title="Ver">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <button class="btn btn-sm btn-copy" title="Copiar URL" data-url="<?php echo $file['file_path']; ?>">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                    <a href="media.php?delete_id=<?php echo $file['id']; ?>" class="btn btn-sm btn-delete" title="Eliminar" onclick="return confirm('¿Estás seguro de eliminar este archivo?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Paginación -->
                    <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="media.php?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="page-link">« Anterior</a>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <a href="media.php?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" class="page-link <?php echo $i == $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="media.php?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="page-link">Siguiente »</a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        </div>
    </main>

    <style>
        .upload-form {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        .media-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        .media-item {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .media-item:hover {
            transform: translateY(-5px);
        }
        .media-preview {
            height: 150px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8f9fa;
        }
        .media-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .file-icon {
            color: #dc3545;
            text-align: center;
            padding: 20px;
        }
        .media-info {
            padding: 15px;
        }
        .media-info h4 {
            margin: 0 0 10px;
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .file-details {
            display: flex;
            justify-content: space-between;
            font-size: 0.8rem;
            color: #666;
            margin-bottom: 10px;
        }
        .file-actions {
            display: flex;
            gap: 5px;
        }
        .btn-copy {
            background: #6c757d;
            color: white;
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        .no-data i {
            margin-bottom: 15px;
            color: #ddd;
        }
    </style>

    <script>
        // Copiar URL al portapapeles
        document.querySelectorAll('.btn-copy').forEach(button => {
            button.addEventListener('click', function() {
                const url = this.getAttribute('data-url');
                navigator.clipboard.writeText(url).then(() => {
                    const originalHTML = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-check"></i>';
                    this.style.background = '#28a745';
                    
                    setTimeout(() => {
                        this.innerHTML = originalHTML;
                        this.style.background = '#6c757d';
                    }, 2000);
                });
            });
        });
    </script>

    <script src="../js/dashboard.js"></script>
</body>
</html>