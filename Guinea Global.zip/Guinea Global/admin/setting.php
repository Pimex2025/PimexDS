<?php
// admin/settings.php
require_once 'auth.php';
requireAuth();

// Solo administradores pueden acceder a configuración
if ($_SESSION['user']['role'] !== 'admin') {
    header('Location: dashboard.php');
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$current_user = getCurrentUser();

// Obtener configuraciones actuales
$settings_stmt = $db->query("SELECT * FROM settings");
$settings = $settings_stmt->fetchAll(PDO::FETCH_ASSOC);

// Convertir a array asociativo
$settings_array = [];
foreach ($settings as $setting) {
    $settings_array[$setting['setting_key']] = $setting;
}

// Procesar formulario de configuración
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    foreach ($_POST['settings'] as $key => $value) {
        $update_stmt = $db->prepare("UPDATE settings SET setting_value = ?, updated_at = NOW() WHERE setting_key = ?");
        $update_stmt->execute([$value, $key]);
    }
    
    $_SESSION['success_message'] = "Configuraciones actualizadas correctamente";
    header('Location: settings.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración - Guinea-global</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="dashboard">
    <!-- Dashboard Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Dashboard Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header">
            <div class="dashboard-welcome">
                <h1>Configuración del Sitio</h1>
                <p>Configura los parámetros generales del sitio web</p>
            </div>
        </header>

        <!-- Mensajes de éxito/error -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <div class="dashboard-content">
            <form method="POST" class="settings-form">
                <!-- Configuración General -->
                <section class="dashboard-section">
                    <h2>Configuración General</h2>
                    <div class="settings-grid">
                        <div class="form-group">
                            <label for="site_name">Nombre del sitio</label>
                            <input type="text" id="site_name" name="settings[site_name]" value="<?php echo htmlspecialchars($settings_array['site_name']['setting_value']); ?>" required>
                            <small class="setting-description"><?php echo htmlspecialchars($settings_array['site_name']['description']); ?></small>
                        </div>
                        
                        <div class="form-group">
                            <label for="site_description">Descripción del sitio</label>
                            <textarea id="site_description" name="settings[site_description]" rows="3"><?php echo htmlspecialchars($settings_array['site_description']['setting_value']); ?></textarea>
                            <small class="setting-description"><?php echo htmlspecialchars($settings_array['site_description']['description']); ?></small>
                        </div>
                        
                        <div class="form-group">
                            <label for="site_email">Email de contacto</label>
                            <input type="email" id="site_email" name="settings[site_email]" value="<?php echo htmlspecialchars($settings_array['site_email']['setting_value']); ?>" required>
                            <small class="setting-description"><?php echo htmlspecialchars($settings_array['site_email']['description']); ?></small>
                        </div>
                        
                        <div class="form-group">
                            <label for="items_per_page">Elementos por página</label>
                            <input type="number" id="items_per_page" name="settings[items_per_page]" value="<?php echo htmlspecialchars($settings_array['items_per_page']['setting_value']); ?>" min="5" max="50" required>
                            <small class="setting-description"><?php echo htmlspecialchars($settings_array['items_per_page']['description']); ?></small>
                        </div>
                    </div>
                </section>

                <!-- Configuración de Funcionalidades -->
                <section class="dashboard-section">
                    <h2>Funcionalidades</h2>
                    <div class="settings-grid">
                        <div class="form-group checkbox-group">
                            <label>
                                <input type="checkbox" name="settings[allow_comments]" value="1" <?php echo $settings_array['allow_comments']['setting_value'] == '1' ? 'checked' : ''; ?>>
                                Permitir comentarios en las noticias
                            </label>
                            <small class="setting-description"><?php echo htmlspecialchars($settings_array['allow_comments']['description']); ?></small>
                        </div>
                        
                        <div class="form-group checkbox-group">
                            <label>
                                <input type="checkbox" name="settings[maintenance_mode]" value="1" <?php echo $settings_array['maintenance_mode']['setting_value'] == '1' ? 'checked' : ''; ?>>
                                Modo mantenimiento
                            </label>
                            <small class="setting-description"><?php echo htmlspecialchars($settings_array['maintenance_mode']['description']); ?></small>
                        </div>
                    </div>
                </section>

                <!-- Configuración de SEO -->
                <section class="dashboard-section">
                    <h2>Configuración SEO</h2>
                    <div class="settings-grid">
                        <div class="form-group">
                            <label for="meta_keywords">Palabras clave (separadas por comas)</label>
                            <input type="text" id="meta_keywords" name="settings[meta_keywords]" value="<?php echo htmlspecialchars($settings_array['meta_keywords']['setting_value'] ?? ''); ?>">
                            <small class="setting-description">Palabras clave para SEO del sitio</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="google_analytics">Código de Google Analytics</label>
                            <textarea id="google_analytics" name="settings[google_analytics]" rows="4" placeholder="Pega aquí tu código de Google Analytics"><?php echo htmlspecialchars($settings_array['google_analytics']['setting_value'] ?? ''); ?></textarea>
                            <small class="setting-description">Código de seguimiento de Google Analytics</small>
                        </div>
                    </div>
                </section>

                <div class="form-actions">
                    <button type="submit" name="update_settings" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar Configuraciones
                    </button>
                    <button type="reset" class="btn btn-secondary">Restablecer</button>
                </div>
            </form>

            <!-- Estadísticas del Sistema -->
            <section class="dashboard-section">
                <h2>Estadísticas del Sistema</h2>
                <div class="system-stats">
                    <?php
                    // Obtener estadísticas
                    $news_count = $db->query("SELECT COUNT(*) FROM news")->fetchColumn();
                    $published_news = $db->query("SELECT COUNT(*) FROM news WHERE status = 'published'")->fetchColumn();
                    $users_count = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
                    $comments_count = $db->query("SELECT COUNT(*) FROM comments")->fetchColumn();
                    $media_count = $db->query("SELECT COUNT(*) FROM media")->fetchColumn();
                    $total_views = $db->query("SELECT SUM(views) FROM news")->fetchColumn();
                    ?>
                    
                    <div class="stats-grid">
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $news_count; ?></div>
                            <div class="stat-label">Total Noticias</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $published_news; ?></div>
                            <div class="stat-label">Noticias Publicadas</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $users_count; ?></div>
                            <div class="stat-label">Usuarios</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $comments_count; ?></div>
                            <div class="stat-label">Comentarios</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $media_count; ?></div>
                            <div class="stat-label">Archivos Multimedia</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $total_views ?: '0'; ?></div>
                            <div class="stat-label">Total Vistas</div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Información del Sistema -->
            <section class="dashboard-section">
                <h2>Información del Sistema</h2>
                <div class="system-info">
                    <div class="info-grid">
                        <div class="info-item">
                            <strong>PHP Version:</strong> <?php echo phpversion(); ?>
                        </div>
                        <div class="info-item">
                            <strong>MySQL Version:</strong> <?php echo $db->getAttribute(PDO::ATTR_SERVER_VERSION); ?>
                        </div>
                        <div class="info-item">
                            <strong>Servidor Web:</strong> <?php echo $_SERVER['SERVER_SOFTWARE']; ?>
                        </div>
                        <div class="info-item">
                            <strong>Espacio en disco:</strong> 
                            <?php
                            $free_space = disk_free_space("/");
                            $total_space = disk_total_space("/");
                            echo round($free_space / 1024 / 1024 / 1024, 2) . ' GB libres de ' . round($total_space / 1024 / 1024 / 1024, 2) . ' GB';
                            ?>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <style>
        .settings-form {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .settings-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .setting-description {
            display: block;
            margin-top: 5px;
            color: #666;
            font-size: 0.8rem;
        }
        .checkbox-group {
            display: flex;
            flex-direction: column;
        }
        .checkbox-group label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
        }
        .form-actions {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            display: flex;
            gap: 10px;
        }
        .system-stats, .system-info {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }
        .stat-item {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 6px;
        }
        .stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: #000;
            margin-bottom: 5px;
        }
        .stat-label {
            font-size: 0.9rem;
            color: #666;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .info-item {
            padding: 10px;
            background: #f8f9fa;
            border-radius: 4px;
        }
        @media (max-width: 768px) {
            .settings-grid, .info-grid {
                grid-template-columns: 1fr;
            }
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>

    <script>
        // Manejar checkboxes para valores booleanos
        document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                this.value = this.checked ? '1' : '0';
            });
        });
    </script>

    <script src="../js/dashboard.js"></script>
</body>
</html>