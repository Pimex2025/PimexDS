<?php
// admin/categories.php
require_once 'auth.php';
requireAuth();

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$current_user = getCurrentUser();

// Obtener categorías con información de sección
$query = "
    SELECT c.*, s.name as section_name, COUNT(n.id) as news_count 
    FROM categories c 
    LEFT JOIN sections s ON c.section_id = s.id 
    LEFT JOIN news n ON n.category_id = c.id 
    GROUP BY c.id 
    ORDER BY s.name, c.name
";
$stmt = $db->prepare($query);
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener secciones para el formulario
$sections = $db->query("SELECT * FROM sections")->fetchAll(PDO::FETCH_ASSOC);

// Procesar formulario para agregar categoría
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $name = trim($_POST['name']);
    $slug = trim($_POST['slug']);
    $section_id = $_POST['section_id'];
    $description = trim($_POST['description']);
    
    // Validaciones
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'El nombre es obligatorio';
    }
    
    if (empty($slug)) {
        $slug = strtolower(str_replace(' ', '-', $name));
    }
    
    if (empty($section_id)) {
        $errors[] = 'La sección es obligatoria';
    }
    
    // Verificar si la categoría ya existe
    $check_stmt = $db->prepare("SELECT id FROM categories WHERE slug = ?");
    $check_stmt->execute([$slug]);
    if ($check_stmt->fetch()) {
        $errors[] = 'Ya existe una categoría con ese slug';
    }
    
    if (empty($errors)) {
        $insert_stmt = $db->prepare("INSERT INTO categories (name, slug, section_id, description) VALUES (?, ?, ?, ?)");
        $insert_stmt->execute([$name, $slug, $section_id, $description]);
        
        $_SESSION['success_message'] = "Categoría agregada correctamente";
        header('Location: categories.php');
        exit;
    } else {
        $_SESSION['error_message'] = implode('<br>', $errors);
    }
}

// Procesar eliminación de categoría
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    // Verificar si hay noticias usando esta categoría
    $check_news = $db->prepare("SELECT COUNT(*) as count FROM news WHERE category_id = ?");
    $check_news->execute([$delete_id]);
    $news_count = $check_news->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($news_count > 0) {
        $_SESSION['error_message'] = "No se puede eliminar la categoría porque tiene noticias asociadas";
    } else {
        $delete_stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
        $delete_stmt->execute([$delete_id]);
        $_SESSION['success_message'] = "Categoría eliminada correctamente";
    }
    
    header('Location: categories.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Categorías - Guinea-global</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="dashboard">
    <!-- Dashboard Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Dashboard Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header">
            <div class="dashboard-welcome">
                <h1>Gestión de Categorías</h1>
                <p>Administra las categorías de noticias</p>
            </div>
        </header>

        <!-- Mensajes de éxito/error -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <div class="dashboard-content">
            <!-- Formulario para agregar categoría -->
            <section class="dashboard-section">
                <h2>Agregar Nueva Categoría</h2>
                <form method="POST" class="category-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">Nombre de la categoría *</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="slug">Slug (URL)</label>
                            <input type="text" id="slug" name="slug" placeholder="Se generará automáticamente si se deja vacío">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="section_id">Sección *</label>
                            <select id="section_id" name="section_id" required>
                                <option value="">Seleccionar sección</option>
                                <?php foreach ($sections as $section): ?>
                                    <option value="<?php echo $section['id']; ?>"><?php echo htmlspecialchars($section['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="description">Descripción</label>
                            <textarea id="description" name="description" rows="3"></textarea>
                        </div>
                    </div>
                    <button type="submit" name="add_category" class="btn btn-primary">Agregar Categoría</button>
                </form>
            </section>

            <!-- Lista de categorías -->
            <section class="dashboard-section">
                <h2>Lista de Categorías</h2>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Slug</th>
                                <th>Sección</th>
                                <th>Descripción</th>
                                <th>Noticias</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($categories)): ?>
                                <tr>
                                    <td colspan="6" class="no-data">No hay categorías registradas</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($categories as $category): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($category['name']); ?></strong>
                                    </td>
                                    <td><?php echo htmlspecialchars($category['slug']); ?></td>
                                    <td><?php echo htmlspecialchars($category['section_name']); ?></td>
                                    <td><?php echo htmlspecialchars($category['description']); ?></td>
                                    <td>
                                        <span class="news-count"><?php echo $category['news_count']; ?></span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="category_edit.php?id=<?php echo $category['id']; ?>" class="btn btn-sm btn-edit" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="categories.php?delete_id=<?php echo $category['id']; ?>" class="btn btn-sm btn-delete" title="Eliminar" onclick="return confirm('¿Estás seguro de eliminar esta categoría?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </main>

    <style>
        .category-form {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 15px;
        }
        .news-count {
            background: #17a2b8;
            color: white;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <script>
        // Generar slug automáticamente desde el nombre
        document.getElementById('name').addEventListener('input', function() {
            const slugField = document.getElementById('slug');
            if (!slugField.value) {
                const slug = this.value
                    .toLowerCase()
                    .replace(/[^a-z0-9 -]/g, '')
                    .replace(/\s+/g, '-')
                    .replace(/-+/g, '-');
                slugField.value = slug;
            }
        });
    </script>

    <script src="../js/dashboard.js"></script>
</body>
</html>