<?php
// Configuración de la carpeta uploads
$upload_dir = 'uploads/';

// Verificar y crear carpeta uploads si no existe
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Verificar permisos de escritura
if (!is_writable($upload_dir)) {
    chmod($upload_dir, 0755);
}

// Aquí puedes agregar más código PHP si necesitas
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guinea-global - Periódico Digital</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Breaking News -->
    <div class="breaking-news">
        <div class="breaking-label">ÚLTIMA HORA</div>
        <div class="breaking-content">
            <div class="breaking-item">Presidente anuncia nuevas medidas económicas para impulsar el desarrollo nacional</div>
            <div class="breaking-item">Selección nacional de fútbol se prepara para el próximo campeonato africano</div>
            <div class="breaking-item">Inauguran nuevo centro cultural en Malabo con participación internacional</div>
        </div>
    </div>

    <!-- Header -->
    <header>
        <div class="header-top">
            <div class="container">
                <div class="date">Martes, 5 de septiembre de 2023</div>
                <div class="weather-widget">
                    <span><i class="fas fa-sun"></i> Malabo: 28°C</span>
                </div>
            </div>
        </div>
        <div class="header-main">
            <div class="container">
                <div class="logo">
                    <img src="img/logo/logo.png" alt="Guinea-global">
                </div>
                <div class="search-bar">
                    <input type="text" placeholder="Buscar noticias...">
                    <button><i class="fas fa-search"></i></button>
                </div>
                <div class="auth-buttons">
                    <button class="subscribe-btn">Suscribirse</button>
                    <button class="login-btn" id="admin-login-btn"><a href="dashboard.html">Admin</a></button>
                </div>
            </div>
        </div>
    </header>

    <!-- Navigation -->
    <nav class="main-nav">
        <div class="container">
            <ul class="nav-menu">
                <li><a href="index.html">Inicio</a></li>
                <li class="dropdown">
                    <a href="noticias.html">Noticias <i class="fas fa-chevron-down"></i></a>
                    <ul class="submenu">
                        <li><a href="noticias.html#nacionales">Nacionales</a></li>
                        <li><a href="noticias.html#internacionales">Internacionales</a></li>
                        <li><a href="noticias.html#ultima-hora">Última Hora</a></li>
                        <li><a href="tecnologia.html">Tecnología</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="cultura .html">Cultura <i class="fas fa-chevron-down"></i></a>
                    <ul class="submenu">
                        <li><a href="cultura.html#cultura-general">Cultura General</a></li>
                        <li><a href="cultura.html#centros-culturales">Centros Culturales</a></li>
                        <li><a href="cultura.html#grupos-etnicos">Grupos Étnicos</a></li>
                        <li><a href="cultura.html#festivales">Festivales Culturales</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="deportes.html">Deportes <i class="fas fa-chevron-down"></i></a>
                    <ul class="submenu">
                        <li><a href="deportes.html#nacional">Nacional</a></li>
                        <li><a href="deportes.html#internacional">Internacional</a></li>
                        <li><a href="deportes.html#africa">África</a></li>
                        <li><a href="deportes.html#europa">Europa</a></li>
                        <li><a href="deportes.html#america">América</a></li>
                        <li><a href="deportes.html#guinea-ecuatorial">Guinea Ecuatorial</a></li>
                    </ul>
                </li>
                <li><a href="politica.html">Política</a></li>
                <li><a href="sobre-nosotros.html">Sobre Nosotros</a></li>
                <li><a href="el-tiempo.html">El Tiempo</a></li>
                <li><a href="contacto.html">Contacto</a></li>
            </ul>
            <div class="mobile-menu-toggle">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <!-- Image Slider -->
        <section class="slider">
            <div class="slider-container">
                <div class="slide active">
                    <img src="img/post-10.jpg" alt="Noticia destacada 1">
                    <div class="slide-content">
                        <h2>Nuevas políticas económicas impulsan el desarrollo nacional</h2>
                        <p>El gobierno anuncia un paquete de medidas para fortalecer la economía y atraer inversiones extranjeras.</p>
                        <a href="noticias.html#nacionales" class="read-more">Leer más</a>
                    </div>
                </div>
                <div class="slide">
                    <img src="img/entertaiment-05.jpg" alt="Noticia destacada 2">
                    <div class="slide-content">
                        <h2>Festival cultural reúne a comunidades de todo el país</h2>
                        <p>Celebración anual promueve la diversidad cultural y el intercambio entre los diferentes grupos étnicos.</p>
                        <a href="cultura.html#festivales" class="read-more">Leer más</a>
                    </div>
                </div>
                <div class="slide">
                    <img src="img/deportes.jpg" alt="Noticia destacada 3">
                    <div class="slide-content">
                        <h2>La selección nacional se prepara para el campeonato africano</h2>
                        <p>Entrenamientos intensivos y partidos de preparación marcan la agenda del equipo nacional de fútbol.</p>
                        <a href="deportes.html#nacional" class="read-more">Leer más</a>
                    </div>
                </div>
            </div>
            <div class="slider-controls">
                <button class="prev"><i class="fas fa-chevron-left"></i></button>
                <button class="next"><i class="fas fa-chevron-right"></i></button>
            </div>
            <div class="slider-dots">
                <span class="dot active"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>
        </section>

        <!-- Partner Companies -->
        <section class="partners">
            <div class="container">
                <h3>Empresas Afiliadas</h3>
                <div class="partners-grid">
                    <div class="partner-item">
                        <img src="img/gitge-logo-guinea.png" alt="Partner 1">
                    </div>
                    <div class="partner-item">
                        <img src="img/Logo.jpg" alt="Partner 2">
                    </div>
                    <div class="partner-item">
                        <img src="img/SEGESA_logo.png" alt="Partner 3">
                    </div>
                    <div class="partner-item">
                        <img src="img/banco11.png" alt="Partner 4">
                    </div>
                    <div class="partner-item">
                        <img src="img/baners/banner.jpg" alt="Partner 5">
                    </div>
                </div>
            </div>
        </section>

        <!-- News Sections -->
        <section class="news-sections">
            <div class="container">
                <div class="section-header">
                    <h2>Últimas Noticias</h2>
                    <div class="section-filters">
                        <select id="category-filter">
                            <option value="all">Todas las categorías</option>
                            <option value="nacionales">Nacionales</option>
                            <option value="internacionales">Internacionales</option>
                            <option value="tecnologia">Tecnología</option>
                            <option value="cultura">Cultura</option>
                            <option value="deportes">Deportes</option>
                            <option value="politica">Política</option>
                        </select>
                    </div>
                </div>
                <div class="news-grid">
                    <article class="news-card" data-category="nacionales">
                        <div class="news-image">
                            <img src="img/vice.png" alt="Noticia nacional">
                            <span class="category-tag nacionales">Nacionales</span>
                        </div>
                        <div class="news-content">
                            <h3>Gobierno anuncia plan de infraestructura para zonas rurales</h3>
                            <p class="news-excerpt">El Ministerio de Obras Públicas ha presentado un ambicioso plan para mejorar las infraestructuras en las zonas rurales del país.</p>
                            <div class="news-meta">
                                <span class="author">Por Redacción Guinea-global</span>
                                <span class="date">Hace 2 horas</span>
                            </div>
                            <a href="#" class="read-more">Leer más</a>
                        </div>
                    </article>
                    <article class="news-card" data-category="internacionales">
                        <div class="news-image">
                            <img src="img/post-16.jpg" alt="Noticia internacional">
                            <span class="category-tag internacionales">Internacionales</span>
                        </div>
                        <div class="news-content">
                            <h3>Cumbre africana aborda desafíos económicos post-pandemia</h3>
                            <p class="news-excerpt">Líderes de varios países africanos se reúnen en Addis Abeba para discutir estrategias de recuperación económica.</p>
                            <div class="news-meta">
                                <span class="author">Por María Ondo</span>
                                <span class="date">Hace 4 horas</span>
                            </div>
                            <a href="#" class="read-more">Leer más</a>
                        </div>
                    </article>
                    <article class="news-card" data-category="tecnologia">
                        <div class="news-image">
                            <img src="img/latest-03.jpg" alt="Noticia tecnología">
                            <span class="category-tag tecnologia">Tecnología</span>
                        </div>
                        <div class="news-content">
                            <h3>Empresa local desarrolla aplicación para agricultura inteligente</h3>
                            <p class="news-excerpt">Una startup ecuatoguineana ha creado una app que ayuda a los agricultores a optimizar el uso de recursos.</p>
                            <div class="news-meta">
                                <span class="author">Por Javier Mbá</span>
                                <span class="date">Hace 6 horas</span>
                            </div>
                            <a href="#" class="read-more">Leer más</a>
                        </div>
                    </article>
                    <article class="news-card" data-category="cultura">
                        <div class="news-image">
                            <img src="img/popular-post-04.jpg" alt="Noticia cultura">
                            <span class="category-tag cultura">Cultura</span>
                        </div>
                        <div class="news-content">
                            <h3>Exposición de arte tradicional bubi atrae a visitantes internacionales</h3>
                            <p class="news-excerpt">Museo Nacional de Guinea Ecuatorial presenta una colección única de artefactos y obras de arte del pueblo bubi.</p>
                            <div class="news-meta">
                                <span class="author">Por Ana Nsue</span>
                                <span class="date">Ayer</span>
                            </div>
                            <a href="#" class="read-more">Leer más</a>
                        </div>
                    </article>
                    <article class="news-card" data-category="deportes">
                        <div class="news-image">
                            <img src="img/deportes2.jpg" alt="Noticia deportes">
                            <span class="category-tag deportes">Deportes</span>
                        </div>
                        <div class="news-content">
                            <h3>Atleta ecuatoguineano gana medalla de oro en competición africana</h3>
                            <p class="news-excerpt">Benjamín Eneme obtiene el primer puesto en los 400 metros llanos durante el Campeonato Africano de Atletismo.</p>
                            <div class="news-meta">
                                <span class="author">Por Pedro Obama</span>
                                <span class="date">Ayer</span>
                            </div>
                            <a href="#" class="read-more">Leer más</a>
                        </div>
                    </article>
                    <article class="news-card" data-category="politica">
                        <div class="news-image">
                            <img src="img/malabo-radio-macuto.jpg" alt="Noticia política">
                            <span class="category-tag politica">Política</span>
                        </div>
                        <div class="news-content">
                            <h3>Presidente se reúne con embajadores de la UE para fortalecer relaciones</h3>
                            <p class="news-excerpt">Encuentro diplomático busca ampliar la cooperación en áreas de desarrollo sostenible y gobernanza.</p>
                            <div class="news-meta">
                                <span class="author">Por Redacción Guinea-global</span>
                                <span class="date">Hace 2 días</span>
                            </div>
                            <a href="#" class="read-more">Leer más</a>
                        </div>
                    </article>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-logo">
                        <img src="images/logo.png" alt="Guinea-global">
                    </div>
                    <p>Periódico digital líder en Guinea Ecuatorial, ofreciendo noticias confiables y actualizadas sobre todos los aspectos de la vida nacional e internacional.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Secciones</h4>
                    <ul>
                        <li><a href="noticias.html">Noticias</a></li>
                        <li><a href="cultura.html">Cultura</a></li>
                        <li><a href="deportes.html">Deportes</a></li>
                        <li><a href="politica.html">Política</a></li>
                        <li><a href="el-tiempo.html">El Tiempo</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Enlaces Útiles</h4>
                    <ul>
                        <li><a href="sobre-nosotros.html">Sobre Nosotros</a></li>
                        <li><a href="contacto.html">Contacto</a></li>
                        <li><a href="#">Política de Privacidad</a></li>
                        <li><a href="#">Términos de Uso</a></li>
                        <li><a href="#">Publicidad</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Suscríbete a nuestro boletín</h4>
                    <p>Recibe las noticias más importantes directamente en tu correo.</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Tu correo electrónico" required>
                        <button type="submit">Suscribirse</button>
                    </form>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2023 Guinea-global. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Admin Login Modal -->
    <div class="modal" id="admin-login-modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h2>Acceso Administrativo</h2>
            <form id="admin-login-form">
                <div class="form-group">
                    <label for="admin-username">Usuario</label>
                    <input type="text" id="admin-username" required>
                </div>
                <div class="form-group">
                    <label for="admin-password">Contraseña</label>
                    <input type="password" id="admin-password" required>
                </div>
                <button type="submit" class="login-submit">Iniciar Sesión</button>
            </form>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>
</html>