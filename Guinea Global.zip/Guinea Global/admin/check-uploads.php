<?php
/**
 * Verificador de permisos para carpeta uploads/
 * Guardar como: check-uploads.php en la raíz del sitio
 */

class UploadsPermissionChecker {
    private $upload_dir = 'uploads/';
    
    public function checkPermissions() {
        echo "<h2>Verificación de Permisos - Carpeta Uploads</h2>";
        
        // 1. Verificar si la carpeta existe
        if (!file_exists($this->upload_dir)) {
            $this->createUploadsFolder();
        } else {
            echo "✅ La carpeta 'uploads/' existe<br>";
        }
        
        // 2. Verificar permisos de escritura
        $this->checkWritePermissions();
        
        // 3. Mostrar permisos actuales
        $this->showCurrentPermissions();
        
        // 4. Intentar crear archivo de prueba
        $this->testFileCreation();
    }
    
    private function createUploadsFolder() {
        echo "⚠️ La carpeta 'uploads/' no existe. Creándola...<br>";
        
        if (mkdir($this->upload_dir, 0755, true)) {
            echo "✅ Carpeta 'uploads/' creada exitosamente<br>";
        } else {
            echo "❌ Error: No se pudo crear la carpeta 'uploads/'<br>";
            echo "Solución: Crea la carpeta manualmente o verifica permisos del servidor<br>";
        }
    }
    
    private function checkWritePermissions() {
        if (is_writable($this->upload_dir)) {
            echo "✅ La carpeta 'uploads/' tiene permisos de escritura<br>";
        } else {
            echo "❌ La carpeta 'uploads/' NO tiene permisos de escritura<br>";
            echo "Intentando corregir automáticamente...<br>";
            
            if (chmod($this->upload_dir, 0755)) {
                echo "✅ Permisos corregidos a 755<br>";
            } else {
                echo "❌ No se pudieron cambiar los permisos automáticamente<br>";
                echo "Solución manual: Ejecuta 'chmod 755 uploads/' por SSH<br>";
            }
        }
    }
    
    private function showCurrentPermissions() {
        $perms = fileperms($this->upload_dir);
        
        if ($perms !== false) {
            $permission = substr(sprintf('%o', $perms), -3);
            echo "📊 Permisos actuales: " . $permission . "<br>";
            
            switch ($permission) {
                case '755':
                    echo "✅ Permisos correctos (755)<br>";
                    break;
                case '775':
                    echo "⚠️ Permisos 775 - Aceptable pero menos seguro<br>";
                    break;
                case '777':
                    echo "❌ PERMISOS PELIGROSOS (777) - Cambia inmediatamente a 755<br>";
                    break;
                default:
                    echo "⚠️ Permisos inusuales: " . $permission . "<br>";
            }
        }
    }
    
    private function testFileCreation() {
        $test_file = $this->upload_dir . 'test-write.txt';
        $test_content = "Este es un archivo de prueba - " . date('Y-m-d H:i:s');
        
        if (file_put_contents($test_file, $test_content) !== false) {
            echo "✅ Archivo de prueba creado exitosamente<br>";
            
            // Limpiar archivo de prueba
            if (unlink($test_file)) {
                echo "✅ Archivo de prueba eliminado<br>";
            }
        } else {
            echo "❌ No se pudo crear archivo de prueba<br>";
        }
    }
}

// Ejecutar la verificación
$checker = new UploadsPermissionChecker();
$checker->checkPermissions();

echo "<hr>";
echo "<h3>Información del Servidor:</h3>";
echo "PHP Version: " . PHP_VERSION . "<br>";
echo "Sistema: " . PHP_OS . "<br>";
echo "Usuario: " . (function_exists('get_current_user') ? get_current_user() : 'Desconocido') . "<br>";

?>