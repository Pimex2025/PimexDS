<?php
// admin/auth.php
session_start();

// Verificar si el usuario está autenticado
function isAuthenticated() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Redirigir al login si no está autenticado
function requireAuth() {
    if (!isAuthenticated()) {
        header('Location: login.php');
        exit;
    }
}

// Obtener información del usuario actual
function getCurrentUser() {
    if (isAuthenticated()) {
        return $_SESSION['user'];
    }
    return null;
}

// Verificar permisos de administrador
function requireAdmin() {
    if (!isAuthenticated() || $_SESSION['user']['role'] !== 'admin') {
        header('Location: dashboard.php');
        exit;
    }
}

// Cerrar sesión
function logout() {
    session_destroy();
    header('Location: login.php');
    exit;
}
?>