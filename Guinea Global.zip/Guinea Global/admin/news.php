<?php
// admin/news.php
require_once 'auth.php';
requireAuth();

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$current_user = getCurrentUser();

// Obtener parámetros de búsqueda y filtro
$search = $_GET['search'] ?? '';
$section_id = $_GET['section_id'] ?? '';
$category_id = $_GET['category_id'] ?? '';
$status = $_GET['status'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Construir consulta base
$query = "
    SELECT n.*, s.name as section_name, c.name as category_name, u.full_name as author_name 
    FROM news n 
    LEFT JOIN sections s ON n.section_id = s.id 
    LEFT JOIN categories c ON n.category_id = c.id 
    LEFT JOIN users u ON n.author_id = u.id 
    WHERE 1=1
";

$count_query = "
    SELECT COUNT(*) as total 
    FROM news n 
    LEFT JOIN sections s ON n.section_id = s.id 
    LEFT JOIN categories c ON n.category_id = c.id 
    WHERE 1=1
";

$params = [];
$count_params = [];

if (!empty($search)) {
    $query .= " AND (n.title LIKE :search OR n.content LIKE :search)";
    $count_query .= " AND (n.title LIKE :search OR n.content LIKE :search)";
    $params[':search'] = $count_params[':search'] = "%$search%";
}

if (!empty($section_id)) {
    $query .= " AND n.section_id = :section_id";
    $count_query .= " AND n.section_id = :section_id";
    $params[':section_id'] = $count_params[':section_id'] = $section_id;
}

if (!empty($category_id)) {
    $query .= " AND n.category_id = :category_id";
    $count_query .= " AND n.category_id = :category_id";
    $params[':category_id'] = $count_params[':category_id'] = $category_id;
}

if (!empty($status)) {
    $query .= " AND n.status = :status";
    $count_query .= " AND n.status = :status";
    $params[':status'] = $count_params[':status'] = $status;
}

$query .= " ORDER BY n.created_at DESC LIMIT :limit OFFSET :offset";

// Obtener noticias
$stmt = $db->prepare($query);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}

$stmt->execute();
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener total para paginación
$count_stmt = $db->prepare($count_query);
foreach ($count_params as $key => $value) {
    $count_stmt->bindValue($key, $value);
}
$count_stmt->execute();
$total_count = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_count / $limit);

// Obtener secciones y categorías para filtros
$sections = $db->query("SELECT * FROM sections")->fetchAll(PDO::FETCH_ASSOC);
$categories = $db->query("SELECT * FROM categories")->fetchAll(PDO::FETCH_ASSOC);

// Procesar eliminación de noticia
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    // Verificar que la noticia existe y pertenece al usuario (o es admin)
    $check_stmt = $db->prepare("SELECT * FROM news WHERE id = ?");
    $check_stmt->execute([$delete_id]);
    $news_to_delete = $check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($news_to_delete && ($current_user['role'] === 'admin' || $news_to_delete['author_id'] == $current_user['id'])) {
        // Eliminar imagen si existe
        if ($news_to_delete['image'] && file_exists("../uploads/news/" . $news_to_delete['image'])) {
            unlink("../uploads/news/" . $news_to_delete['image']);
        }
        
        // Eliminar noticia
        $delete_stmt = $db->prepare("DELETE FROM news WHERE id = ?");
        $delete_stmt->execute([$delete_id]);
        
        $_SESSION['success_message'] = "Noticia eliminada correctamente";
        header('Location: news.php');
        exit;
    } else {
        $_SESSION['error_message'] = "No tienes permisos para eliminar esta noticia";
        header('Location: news.php');
        exit;
    }
}

// Procesar cambio de estado
if (isset($_GET['publish_id'])) {
    $publish_id = $_GET['publish_id'];
    
    $check_stmt = $db->prepare("SELECT * FROM news WHERE id = ?");
    $check_stmt->execute([$publish_id]);
    $news_to_publish = $check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($news_to_publish && ($current_user['role'] === 'admin' || $news_to_publish['author_id'] == $current_user['id'])) {
        $new_status = $news_to_publish['status'] === 'published' ? 'draft' : 'published';
        $publish_at = $new_status === 'published' ? date('Y-m-d H:i:s') : null;
        
        $update_stmt = $db->prepare("UPDATE news SET status = ?, published_at = ? WHERE id = ?");
        $update_stmt->execute([$new_status, $publish_at, $publish_id]);
        
        $_SESSION['success_message'] = $new_status === 'published' ? "Noticia publicada correctamente" : "Noticia movida a borrador";
        header('Location: news.php');
        exit;
    } else {
        $_SESSION['error_message'] = "No tienes permisos para modificar esta noticia";
        header('Location: news.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Noticias - Guinea-global</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="dashboard">
    <!-- Dashboard Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Dashboard Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header">
            <div class="dashboard-welcome">
                <h1>Gestión de Noticias</h1>
                <p>Administra todas las noticias del sitio</p>
            </div>
            <div class="dashboard-actions">
                <a href="news_edit.php" class="btn btn-primary"><i class="fas fa-plus"></i> Nueva Noticia</a>
            </div>
        </header>

        <!-- Mensajes de éxito/error -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <!-- Filtros de Búsqueda -->
        <section class="dashboard-section">
            <div class="search-filters">
                <form method="GET" class="filter-form">
                    <div class="filter-group">
                        <input type="text" name="search" placeholder="Buscar noticias..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="filter-group">
                        <select name="section_id">
                            <option value="">Todas las secciones</option>
                            <?php foreach ($sections as $section): ?>
                                <option value="<?php echo $section['id']; ?>" <?php echo $section_id == $section['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($section['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <select name="category_id">
                            <option value="">Todas las categorías</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" <?php echo $category_id == $category['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <select name="status">
                            <option value="">Todos los estados</option>
                            <option value="draft" <?php echo $status == 'draft' ? 'selected' : ''; ?>>Borrador</option>
                            <option value="published" <?php echo $status == 'published' ? 'selected' : ''; ?>>Publicado</option>
                            <option value="archived" <?php echo $status == 'archived' ? 'selected' : ''; ?>>Archivado</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-filter"><i class="fas fa-search"></i> Filtrar</button>
                    <a href="news.php" class="btn btn-secondary">Limpiar</a>
                </form>
            </div>
        </section>

        <!-- Lista de Noticias -->
        <section class="dashboard-section">
            <div class="section-header">
                <h2>Lista de Noticias (<?php echo $total_count; ?>)</h2>
            </div>
            
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Título</th>
                            <th>Sección</th>
                            <th>Categoría</th>
                            <th>Autor</th>
                            <th>Fecha</th>
                            <th>Estado</th>
                            <th>Vistas</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($news)): ?>
                            <tr>
                                <td colspan="8" class="no-data">No se encontraron noticias</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($news as $item): ?>
                            <tr>
                                <td>
                                    <div class="news-title">
                                        <strong><?php echo htmlspecialchars($item['title']); ?></strong>
                                        <?php if ($item['image']): ?>
                                            <span class="has-image" title="Tiene imagen"><i class="fas fa-image"></i></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="news-excerpt">
                                        <?php echo htmlspecialchars(mb_substr($item['excerpt'] ?: $item['content'], 0, 100)) . '...'; ?>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($item['section_name']); ?></td>
                                <td><?php echo htmlspecialchars($item['category_name']); ?></td>
                                <td><?php echo htmlspecialchars($item['author_name']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($item['created_at'])); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $item['status']; ?>">
                                        <?php 
                                        $status_text = [
                                            'draft' => 'Borrador',
                                            'published' => 'Publicado',
                                            'archived' => 'Archivado'
                                        ];
                                        echo $status_text[$item['status']];
                                        ?>
                                    </span>
                                </td>
                                <td><?php echo $item['views']; ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="news_edit.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-edit" title="Editar">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        
                                        <?php if ($item['status'] == 'draft' || $item['status'] == 'archived'): ?>
                                            <a href="news.php?publish_id=<?php echo $item['id']; ?>" class="btn btn-sm btn-publish" title="Publicar">
                                                <i class="fas fa-check"></i>
                                            </a>
                                        <?php elseif ($item['status'] == 'published'): ?>
                                            <a href="news.php?publish_id=<?php echo $item['id']; ?>" class="btn btn-sm btn-unpublish" title="Despublicar">
                                                <i class="fas fa-eye-slash"></i>
                                            </a>
                                        <?php endif; ?>
                                        
                                        <a href="../noticia.php?id=<?php echo $item['id']; ?>" target="_blank" class="btn btn-sm btn-view" title="Ver">
                                            <i class="fas fa-external-link-alt"></i>
                                        </a>
                                        
                                        <a href="news.php?delete_id=<?php echo $item['id']; ?>" class="btn btn-sm btn-delete" title="Eliminar" onclick="return confirm('¿Estás seguro de eliminar esta noticia?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="news.php?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="page-link">« Anterior</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="news.php?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" class="page-link <?php echo $i == $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="news.php?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="page-link">Siguiente »</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </section>
    </main>

    <style>
        .news-title {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .news-excerpt {
            font-size: 0.8rem;
            color: #666;
            margin-top: 5px;
        }
        .has-image {
            color: #17a2b8;
        }
        .btn-unpublish {
            background: #6c757d;
            color: white;
        }
        .btn-view {
            background: #17a2b8;
            color: white;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }
        .page-link {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #333;
        }
        .page-link.active {
            background: #000;
            color: white;
            border-color: #000;
        }
        .page-link:hover {
            background: #f8f9fa;
        }
    </style>

    <script src="../js/dashboard.js"></script>
</body>
</html>