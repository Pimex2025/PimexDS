<?php
// admin/sidebar.php
$current_user = getCurrentUser();

// Obtener contadores para mostrar en el sidebar
require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$pending_comments = $db->query("SELECT COUNT(*) FROM comments WHERE status = 'pending'")->fetchColumn();
$draft_news = $db->query("SELECT COUNT(*) FROM news WHERE status = 'draft'")->fetchColumn();
?>

<aside class="dashboard-sidebar">
    <div class="dashboard-logo">
        <a href="../index.html"><img src="../images/logo.png" alt="Guinea-global"></a>
    </div>
    
    <nav class="dashboard-nav">
        <ul>
            <li>
                <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="news.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'news.php' ? 'active' : ''; ?>">
                    <i class="fas fa-newspaper"></i> Gestión de Noticias
                    <?php if ($draft_news > 0): ?>
                        <span class="nav-badge"><?php echo $draft_news; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li>
                <a href="categories.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'active' : ''; ?>">
                    <i class="fas fa-tags"></i> Categorías
                </a>
            </li>
            <li>
                <a href="media.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'media.php' ? 'active' : ''; ?>">
                    <i class="fas fa-images"></i> Biblioteca Multimedia
                </a>
            </li>
            <?php if ($current_user['role'] === 'admin'): ?>
            <li>
                <a href="users.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i> Usuarios
                </a>
            </li>
            <?php endif; ?>
            <li>
                <a href="comments.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'comments.php' ? 'active' : ''; ?>">
                    <i class="fas fa-comments"></i> Comentarios
                    <?php if ($pending_comments > 0): ?>
                        <span class="nav-badge"><?php echo $pending_comments; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <?php if ($current_user['role'] === 'admin'): ?>
            <li>
                <a href="settings.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i> Configuración
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </nav>
    
    <div class="sidebar-footer">
        <div class="user-info">
            <div class="user-avatar">
                <img src="../images/admin-avatar.jpg" alt="<?php echo htmlspecialchars($current_user['full_name']); ?>">
            </div>
            <div class="user-details">
                <h4><?php echo htmlspecialchars($current_user['full_name']); ?></h4>
                <p><?php echo htmlspecialchars(ucfirst($current_user['role'])); ?></p>
            </div>
        </div>
        <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
    </div>
</aside>

<style>
    .nav-badge {
        background: #dc3545;
        color: white;
        border-radius: 10px;
        padding: 2px 6px;
        font-size: 0.7rem;
        font-weight: 600;
        margin-left: auto;
    }
    .dashboard-nav a {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
</style>