<?php
require_once 'auth.php';
requireAuth();

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$id = $_GET['id'];
if ($id) {
    // Publicar la noticia
    $query = "UPDATE news SET status = 'published', published_at = NOW() WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$id]);
}

header('Location: news.php');
exit;