<?php
// admin/news_edit.php
require_once 'auth.php';
requireAuth();

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$current_user = getCurrentUser();
$news_id = $_GET['id'] ?? null;
$news = null;
$errors = [];

// Si estamos editando, cargar la noticia
if ($news_id) {
    $stmt = $db->prepare("SELECT * FROM news WHERE id = ?");
    $stmt->execute([$news_id]);
    $news = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$news) {
        header('Location: news.php');
        exit;
    }
    
    // Verificar permisos (solo admin o el autor puede editar)
    if ($current_user['role'] !== 'admin' && $news['author_id'] != $current_user['id']) {
        $_SESSION['error_message'] = "No tienes permisos para editar esta noticia";
        header('Location: news.php');
        exit;
    }
}

// Obtener secciones y categorías
$sections = $db->query("SELECT * FROM sections")->fetchAll(PDO::FETCH_ASSOC);
$categories = $db->query("SELECT * FROM categories")->fetchAll(PDO::FETCH_ASSOC);

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $excerpt = trim($_POST['excerpt']);
    $section_id = $_POST['section_id'];
    $category_id = $_POST['category_id'];
    $status = $_POST['status'];
    $published_at = $_POST['published_at'];
    $meta_description = trim($_POST['meta_description']);
    $meta_keywords = trim($_POST['meta_keywords']);
    
    // Validaciones
    if (empty($title)) {
        $errors[] = 'El título es obligatorio';
    }
    if (empty($content)) {
        $errors[] = 'El contenido es obligatorio';
    }
    if (empty($section_id)) {
        $errors[] = 'La sección es obligatoria';
    }
    if (empty($category_id)) {
        $errors[] = 'La categoría es obligatoria';
    }
    
    // Procesar imagen
    $image = $news['image'] ?? null;
    $image_alt = $news['image_alt'] ?? '';
    
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
        $file_type = $_FILES['image']['type'];
        
        if (in_array($file_type, $allowed_types)) {
            $upload_dir = '../uploads/news/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $image_name = uniqid() . '_' . time() . '.' . $file_extension;
            $image_path = $upload_dir . $image_name;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
                $image = $image_name;
                $image_alt = $_POST['image_alt'] ?: pathinfo($_FILES['image']['name'], PATHINFO_FILENAME);
                
                // Eliminar imagen anterior si existe
                if ($news && $news['image'] && file_exists($upload_dir . $news['image'])) {
                    unlink($upload_dir . $news['image']);
                }
            } else {
                $errors[] = 'Error al subir la imagen';
            }
        } else {
            $errors[] = 'Tipo de archivo no permitido. Use JPG, PNG, GIF o WebP.';
        }
    } elseif (isset($_POST['image_alt'])) {
        $image_alt = $_POST['image_alt'];
    }
    
    // Si no hay errores, guardar
    if (empty($errors)) {
        if ($news_id) {
            // Actualizar noticia existente
            $query = "UPDATE news SET title = ?, content = ?, excerpt = ?, image = ?, image_alt = ?, section_id = ?, category_id = ?, status = ?, published_at = ?, meta_description = ?, meta_keywords = ?, updated_at = NOW() WHERE id = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([$title, $content, $excerpt, $image, $image_alt, $section_id, $category_id, $status, $published_at, $meta_description, $meta_keywords, $news_id]);
            $message = 'Noticia actualizada correctamente';
        } else {
            // Crear nueva noticia
            $query = "INSERT INTO news (title, content, excerpt, image, image_alt, section_id, category_id, author_id, status, published_at, meta_description, meta_keywords) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $db->prepare($query);
            $stmt->execute([$title, $content, $excerpt, $image, $image_alt, $section_id, $category_id, $current_user['id'], $status, $published_at, $meta_description, $meta_keywords]);
            $news_id = $db->lastInsertId();
            $message = 'Noticia creada correctamente';
        }
        
        $_SESSION['success_message'] = $message;
        header('Location: news_edit.php?id=' . $news_id);
        exit;
    }
}

// Si hay éxito en la operación anterior
$success = isset($_SESSION['success_message']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $news ? 'Editar' : 'Crear'; ?> Noticia - Guinea-global</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
</head>
<body class="dashboard">
    <!-- Dashboard Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Dashboard Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header">
            <div class="dashboard-welcome">
                <h1><?php echo $news ? 'Editar Noticia' : 'Crear Nueva Noticia'; ?></h1>
                <p><?php echo $news ? 'Modifica los datos de la noticia' : 'Completa el formulario para crear una nueva noticia'; ?></p>
            </div>
            <div class="dashboard-actions">
                <a href="news.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Volver</a>
            </div>
        </header>

        <div class="dashboard-content">
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <strong>Errores:</strong>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data" class="editor-container">
                <div class="editor-main">
                    <div class="form-group">
                        <label for="title">Título de la Noticia *</label>
                        <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($news['title'] ?? ''); ?>" required placeholder="Ingresa un título llamativo para la noticia">
                    </div>
                    
                    <div class="form-group">
                        <label for="excerpt">Extracto o Resumen</label>
                        <textarea id="excerpt" name="excerpt" placeholder="Breve descripción que aparecerá en los listados de noticias"><?php echo htmlspecialchars($news['excerpt'] ?? ''); ?></textarea>
                        <small>Máximo 160 caracteres recomendado para SEO</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="content">Contenido de la Noticia *</label>
                        <textarea id="content" name="content" required><?php echo htmlspecialchars($news['content'] ?? ''); ?></textarea>
                    </div>
                </div>
                
                <div class="editor-sidebar">
                    <!-- Sección y Categoría -->
                    <div class="sidebar-section">
                        <h3>Clasificación</h3>
                        <div class="form-group">
                            <label for="section_id">Sección *</label>
                            <select id="section_id" name="section_id" required>
                                <option value="">Seleccionar Sección</option>
                                <?php foreach ($sections as $section): ?>
                                    <option value="<?php echo $section['id']; ?>" <?php echo ($news['section_id'] ?? '') == $section['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($section['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="category_id">Categoría *</label>
                            <select id="category_id" name="category_id" required>
                                <option value="">Seleccionar Categoría</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" <?php echo ($news['category_id'] ?? '') == $category['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Imagen destacada -->
                    <div class="sidebar-section">
                        <h3>Imagen Destacada</h3>
                        <div class="form-group">
                            <label for="image">Subir imagen</label>
                            <input type="file" id="image" name="image" accept="image/*">
                            <small>Formatos: JPG, PNG, GIF, WebP. Máx. 10MB</small>
                        </div>
                        
                        <?php if ($news && $news['image']): ?>
                        <div class="image-preview">
                            <img src="../uploads/news/<?php echo $news['image']; ?>" alt="Imagen actual">
                            <p><small>Imagen actual</small></p>
                        </div>
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label for="image_alt">Texto alternativo (ALT)</label>
                            <input type="text" id="image_alt" name="image_alt" value="<?php echo htmlspecialchars($news['image_alt'] ?? ''); ?>" placeholder="Descripción de la imagen para SEO">
                        </div>
                    </div>

                    <!-- Configuración de publicación -->
                    <div class="sidebar-section">
                        <h3>Publicación</h3>
                        <div class="form-group">
                            <label for="published_at">Fecha de Publicación</label>
                            <input type="datetime-local" id="published_at" name="published_at" 
                                   value="<?php echo $news ? date('Y-m-d\TH:i', strtotime($news['published_at'])) : date('Y-m-d\TH:i'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="status">Estado</label>
                            <select id="status" name="status">
                                <option value="draft" <?php echo ($news['status'] ?? 'draft') == 'draft' ? 'selected' : ''; ?>>Borrador</option>
                                <option value="published" <?php echo ($news['status'] ?? '') == 'published' ? 'selected' : ''; ?>>Publicado</option>
                                <option value="archived" <?php echo ($news['status'] ?? '') == 'archived' ? 'selected' : ''; ?>>Archivado</option>
                            </select>
                        </div>
                    </div>

                    <!-- SEO -->
                    <div class="sidebar-section">
                        <h3>Configuración SEO</h3>
                        <div class="form-group">
                            <label for="meta_description">Meta Descripción</label>
                            <textarea id="meta_description" name="meta_description" rows="3" placeholder="Descripción para motores de búsqueda"><?php echo htmlspecialchars($news['meta_description'] ?? ''); ?></textarea>
                            <small>Recomendado: 150-160 caracteres</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="meta_keywords">Palabras Clave</label>
                            <input type="text" id="meta_keywords" name="meta_keywords" value="<?php echo htmlspecialchars($news['meta_keywords'] ?? ''); ?>" placeholder="palabra1, palabra2, palabra3">
                            <small>Separadas por comas</small>
                        </div>
                    </div>

                    <!-- Acciones -->
                    <div class="publish-actions">
                        <button type="submit" name="action" value="publish" class="btn btn-primary btn-block">
                            <i class="fas fa-save"></i> <?php echo $news ? 'Actualizar' : 'Publicar'; ?> Noticia
                        </button>
                        
                        <?php if (!$news): ?>
                            <button type="submit" name="action" value="draft" class="btn btn-secondary btn-block">
                                <i class="fas fa-file-alt"></i> Guardar como Borrador
                            </button>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($news): ?>
                        <div class="news-info">
                            <h4>Información de la Noticia</h4>
                            <p><strong>Creada:</strong> <?php echo date('d/m/Y H:i', strtotime($news['created_at'])); ?></p>
                            <p><strong>Modificada:</strong> <?php echo date('d/m/Y H:i', strtotime($news['updated_at'])); ?></p>
                            <p><strong>Autor:</strong> <?php echo htmlspecialchars($current_user['full_name']); ?></p>
                            <p><strong>Vistas:</strong> <?php echo $news['views']; ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </main>

    <style>
        .editor-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        .editor-main {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .editor-sidebar {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .sidebar-section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .sidebar-section h3 {
            margin: 0 0 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f8f9fa;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: #000;
            outline: none;
        }
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        #content {
            min-height: 400px;
        }
        .image-preview {
            margin: 10px 0;
            text-align: center;
        }
        .image-preview img {
            max-width: 100%;
            max-height: 200px;
            border-radius: 6px;
            border: 1px solid #ddd;
        }
        .publish-actions {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
        }
        .btn-block {
            width: 100%;
            margin-bottom: 10px;
        }
        .news-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            font-size: 0.9rem;
        }
        .news-info h4 {
            margin: 0 0 10px;
            color: #333;
        }
        .news-info p {
            margin: 5px 0;
            color: #666;
        }
        @media (max-width: 1200px) {
            .editor-container {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <script>
        // Inicializar CKEditor
        CKEDITOR.replace('content', {
            toolbar: [
                { name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Strike', '-', 'RemoveFormat'] },
                { name: 'paragraph', items: ['NumberedList', 'BulletedList', '-', 'Blockquote'] },
                { name: 'links', items: ['Link', 'Unlink'] },
                { name: 'insert', items: ['Image', 'Table', 'HorizontalRule'] },
                { name: 'styles', items: ['Styles', 'Format'] },
                { name: 'tools', items: ['Maximize', 'Source'] }
            ],
            height: 400,
            removePlugins: 'elementspath',
            resize_enabled: false
        });

        // Cambiar el estado según el botón presionado
        document.querySelectorAll('button[type="submit"]').forEach(button => {
            button.addEventListener('click', function() {
                const statusSelect = document.getElementById('status');
                if (this.value === 'publish') {
                    statusSelect.value = 'published';
                } else if (this.value === 'draft') {
                    statusSelect.value = 'draft';
                }
            });
        });
        
        // Previsualización de imagen
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    let preview = document.querySelector('.image-preview');
                    if (!preview) {
                        preview = document.createElement('div');
                        preview.className = 'image-preview';
                        document.querySelector('input[name="image"]').after(preview);
                    }
                    preview.innerHTML = `<img src="${e.target.result}" alt="Vista previa"><p><small>Vista previa</small></p>`;
                };
                reader.readAsDataURL(file);
            }
        });

        // Generar excerpt automáticamente desde el contenido
        document.getElementById('title').addEventListener('blur', function() {
            const excerptField = document.getElementById('excerpt');
            if (!excerptField.value && this.value) {
                excerptField.value = this.value.substring(0, 160);
            }
        });

        // Generar meta description automáticamente
        document.getElementById('excerpt').addEventListener('blur', function() {
            const metaDescField = document.getElementById('meta_description');
            if (!metaDescField.value && this.value) {
                metaDescField.value = this.value.substring(0, 160);
            }
        });
    </script>

    <script src="../js/dashboard.js"></script>
</body>
</html>