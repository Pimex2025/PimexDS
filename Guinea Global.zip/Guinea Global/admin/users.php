<?php
// admin/users.php
require_once 'auth.php';
requireAuth();

// Solo administradores pueden gestionar usuarios
if ($_SESSION['user']['role'] !== 'admin') {
    header('Location: dashboard.php');
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$current_user = getCurrentUser();

// Obtener usuarios
$query = "SELECT * FROM users ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Procesar formulario para agregar usuario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    
    // Validaciones
    $errors = [];
    
    if (empty($username) || empty($password) || empty($full_name) || empty($email)) {
        $errors[] = 'Todos los campos son obligatorios';
    }
    
    if ($password !== $confirm_password) {
        $errors[] = 'Las contraseñas no coinciden';
    }
    
    if (strlen($password) < 6) {
        $errors[] = 'La contraseña debe tener al menos 6 caracteres';
    }
    
    // Verificar si el usuario ya existe
    $check_stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $check_stmt->execute([$username, $email]);
    if ($check_stmt->fetch()) {
        $errors[] = 'El usuario o email ya existe';
    }
    
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $insert_stmt = $db->prepare("INSERT INTO users (username, password, full_name, email, role) VALUES (?, ?, ?, ?, ?)");
        $insert_stmt->execute([$username, $hashed_password, $full_name, $email, $role]);
        
        $_SESSION['success_message'] = "Usuario agregado correctamente";
        header('Location: users.php');
        exit;
    } else {
        $_SESSION['error_message'] = implode('<br>', $errors);
    }
}

// Procesar eliminación de usuario
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    // No permitir eliminarse a sí mismo
    if ($delete_id == $current_user['id']) {
        $_SESSION['error_message'] = "No puedes eliminar tu propio usuario";
    } else {
        $delete_stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        $delete_stmt->execute([$delete_id]);
        $_SESSION['success_message'] = "Usuario eliminado correctamente";
    }
    
    header('Location: users.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios - Guinea-global</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="dashboard">
    <!-- Dashboard Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Dashboard Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header">
            <div class="dashboard-welcome">
                <h1>Gestión de Usuarios</h1>
                <p>Administra los usuarios del sistema</p>
            </div>
        </header>

        <!-- Mensajes de éxito/error -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <div class="dashboard-content">
            <!-- Formulario para agregar usuario -->
            <section class="dashboard-section">
                <h2>Agregar Nuevo Usuario</h2>
                <form method="POST" class="user-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="username">Nombre de usuario *</label>
                            <input type="text" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email *</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="full_name">Nombre completo *</label>
                            <input type="text" id="full_name" name="full_name" required>
                        </div>
                        <div class="form-group">
                            <label for="role">Rol *</label>
                            <select id="role" name="role" required>
                                <option value="editor">Editor</option>
                                <option value="admin">Administrador</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="password">Contraseña *</label>
                            <input type="password" id="password" name="password" required minlength="6">
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirmar contraseña *</label>
                            <input type="password" id="confirm_password" name="confirm_password" required minlength="6">
                        </div>
                    </div>
                    <button type="submit" name="add_user" class="btn btn-primary">Agregar Usuario</button>
                </form>
            </section>

            <!-- Lista de usuarios -->
            <section class="dashboard-section">
                <h2>Lista de Usuarios</h2>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Usuario</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th>Fecha registro</th>
                                <th>Último acceso</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($users)): ?>
                                <tr>
                                    <td colspan="7" class="no-data">No hay usuarios registrados</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td>
                                        <span class="role-badge <?php echo $user['role']; ?>">
                                            <?php echo ucfirst($user['role']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <?php echo $user['last_login'] ? date('d/m/Y H:i', strtotime($user['last_login'])) : 'Nunca'; ?>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="user_edit.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-edit" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($user['id'] != $current_user['id']): ?>
                                                <a href="users.php?delete_id=<?php echo $user['id']; ?>" class="btn btn-sm btn-delete" title="Eliminar" onclick="return confirm('¿Estás seguro de eliminar este usuario?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            <?php else: ?>
                                                <span class="btn btn-sm btn-disabled" title="No puedes eliminarte a ti mismo">
                                                    <i class="fas fa-trash"></i>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </main>

    <style>
        .user-form {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        .role-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .role-badge.admin {
            background: #dc3545;
            color: white;
        }
        .role-badge.editor {
            background: #17a2b8;
            color: white;
        }
        .btn-disabled {
            background: #6c757d;
            color: white;
            cursor: not-allowed;
            opacity: 0.6;
        }
    </style>

    <script src="../js/dashboard.js"></script>
</body>
</html>