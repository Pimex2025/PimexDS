<?php
// admin/dashboard.php
require_once 'auth.php';
requireAuth();

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Obtener estadísticas reales
$news_count = $db->query("SELECT COUNT(*) FROM news")->fetchColumn();
$published_count = $db->query("SELECT COUNT(*) FROM news WHERE status = 'published'")->fetchColumn();
$pending_news = $db->query("SELECT COUNT(*) FROM news WHERE status = 'draft'")->fetchColumn();
$users_count = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$comments_count = $db->query("SELECT COUNT(*) FROM comments")->fetchColumn();
$pending_comments = $db->query("SELECT COUNT(*) FROM comments WHERE status = 'pending'")->fetchColumn();
$media_count = $db->query("SELECT COUNT(*) FROM media")->fetchColumn();
$total_views = $db->query("SELECT SUM(views) FROM news")->fetchColumn();

// Obtener noticias recientes (5 más recientes)
$recent_news = $db->query("
    SELECT n.*, s.name as section_name, u.full_name as author_name 
    FROM news n 
    LEFT JOIN sections s ON n.section_id = s.id 
    LEFT JOIN users u ON n.author_id = u.id 
    ORDER BY n.created_at DESC 
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Obtener comentarios recientes (5 más recientes pendientes)
$recent_comments = $db->query("
    SELECT c.*, n.title as news_title 
    FROM comments c 
    LEFT JOIN news n ON c.news_id = n.id 
    WHERE c.status = 'pending'
    ORDER BY c.created_at DESC 
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Obtener actividad reciente (combinación de noticias y comentarios)
$activity_query = "
    (SELECT 'news' as type, id, title as content, created_at, author_id, NULL as author_name 
     FROM news 
     ORDER BY created_at DESC 
     LIMIT 10)
    UNION ALL
    (SELECT 'comment' as type, id, content, created_at, NULL as author_id, author_name 
     FROM comments 
     WHERE status = 'approved'
     ORDER BY created_at DESC 
     LIMIT 10)
    ORDER BY created_at DESC 
    LIMIT 10
";
$recent_activity = $db->query($activity_query)->fetchAll(PDO::FETCH_ASSOC);

$current_user = getCurrentUser();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Guinea-global</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="dashboard">
    <!-- Dashboard Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Dashboard Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header">
            <div class="dashboard-welcome">
                <h1>Panel de Administración</h1>
                <p>Bienvenido, <?php echo htmlspecialchars($current_user['full_name']); ?></p>
                <div class="dashboard-stats-mini">
                    <span class="stat-mini"><i class="fas fa-newspaper"></i> <?php echo $news_count; ?> Noticias</span>
                    <span class="stat-mini"><i class="fas fa-comments"></i> <?php echo $comments_count; ?> Comentarios</span>
                    <span class="stat-mini"><i class="fas fa-users"></i> <?php echo $users_count; ?> Usuarios</span>
                </div>
            </div>
            <div class="dashboard-actions">
                <a href="news_edit.php" class="btn btn-primary"><i class="fas fa-plus"></i> Nueva Noticia</a>
                <div class="notification-bell">
                    <i class="fas fa-bell"></i>
                    <?php if ($pending_comments > 0): ?>
                        <span class="notification-count"><?php echo $pending_comments; ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </header>

        <!-- Dashboard Stats -->
        <section class="dashboard-stats">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-newspaper"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo $news_count; ?></div>
                    <div class="stat-label">Total Noticias</div>
                    <div class="stat-detail"><?php echo $published_count; ?> publicadas • <?php echo $pending_news; ?> borradores</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-eye"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo $total_views ?: '0'; ?></div>
                    <div class="stat-label">Total Vistas</div>
                    <div class="stat-detail">Todas las noticias</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo $users_count; ?></div>
                    <div class="stat-label">Usuarios</div>
                    <div class="stat-detail">Administradores y editores</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-comments"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo $comments_count; ?></div>
                    <div class="stat-label">Comentarios</div>
                    <div class="stat-detail"><?php echo $pending_comments; ?> pendientes</div>
                </div>
            </div>
        </section>

        <!-- Dashboard Content -->
        <div class="dashboard-content">
            <!-- Quick Actions -->
            <section class="dashboard-section">
                <h2>Acciones Rápidas</h2>
                <div class="quick-actions">
                    <a href="news_edit.php" class="action-card">
                        <i class="fas fa-edit"></i>
                        <span>Redactar Noticia</span>
                    </a>
                    <a href="media.php" class="action-card">
                        <i class="fas fa-upload"></i>
                        <span>Subir Multimedia</span>
                    </a>
                    <a href="categories.php" class="action-card">
                        <i class="fas fa-tags"></i>
                        <span>Gestionar Categorías</span>
                    </a>
                    <a href="users.php" class="action-card">
                        <i class="fas fa-user-plus"></i>
                        <span>Añadir Usuario</span>
                    </a>
                    <a href="comments.php" class="action-card">
                        <i class="fas fa-comments"></i>
                        <span>Moderar Comentarios</span>
                        <?php if ($pending_comments > 0): ?>
                            <span class="action-badge"><?php echo $pending_comments; ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="settings.php" class="action-card">
                        <i class="fas fa-cog"></i>
                        <span>Configuración</span>
                    </a>
                </div>
            </section>

            <div class="dashboard-columns">
                <!-- Noticias Recientes -->
                <section class="dashboard-section">
                    <div class="section-header">
                        <h2>Noticias Recientes</h2>
                        <a href="news.php" class="view-all">Ver Todas</a>
                    </div>
                    
                    <div class="recent-news">
                        <?php foreach ($recent_news as $news): ?>
                        <div class="news-item">
                            <div class="news-info">
                                <h4><?php echo htmlspecialchars($news['title']); ?></h4>
                                <div class="news-meta">
                                    <span><?php echo htmlspecialchars($news['section_name']); ?></span> • 
                                    <span><?php echo date('d/m/Y', strtotime($news['created_at'])); ?></span> • 
                                    <span class="status-badge <?php echo $news['status']; ?>"><?php echo $news['status']; ?></span>
                                </div>
                                <div class="news-stats">
                                    <span><i class="fas fa-eye"></i> <?php echo $news['views']; ?> vistas</span>
                                    <?php if ($news['image']): ?>
                                        <span><i class="fas fa-image"></i> Con imagen</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="news-actions">
                                <a href="news_edit.php?id=<?php echo $news['id']; ?>" class="btn btn-sm btn-edit" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="../noticia.php?id=<?php echo $news['id']; ?>" target="_blank" class="btn btn-sm btn-view" title="Ver">
                                    <i class="fas fa-external-link-alt"></i>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <!-- Comentarios Recientes -->
                <section class="dashboard-section">
                    <div class="section-header">
                        <h2>Comentarios Pendientes</h2>
                        <a href="comments.php?status=pending" class="view-all">Ver Todos</a>
                    </div>
                    
                    <div class="recent-comments">
                        <?php if (empty($recent_comments)): ?>
                            <div class="no-comments">
                                <i class="fas fa-check-circle"></i>
                                <p>No hay comentarios pendientes</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($recent_comments as $comment): ?>
                            <div class="comment-item">
                                <div class="comment-avatar">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="comment-content">
                                    <div class="comment-header">
                                        <h4><?php echo htmlspecialchars($comment['author_name']); ?></h4>
                                        <span class="comment-date"><?php echo date('d/m/Y H:i', strtotime($comment['created_at'])); ?></span>
                                    </div>
                                    <p class="comment-text"><?php echo htmlspecialchars(mb_substr($comment['content'], 0, 100)) . '...'; ?></p>
                                    <div class="comment-news">En: <?php echo htmlspecialchars($comment['news_title']); ?></div>
                                    <div class="comment-actions">
                                        <a href="comments.php?action=approve&id=<?php echo $comment['id']; ?>&status=pending" class="btn btn-sm btn-approve">Aprobar</a>
                                        <a href="comments.php?action=reject&id=<?php echo $comment['id']; ?>&status=pending" class="btn btn-sm btn-reject">Rechazar</a>
                                        <a href="comments.php?action=delete&id=<?php echo $comment['id']; ?>&status=pending" class="btn btn-sm btn-delete">Eliminar</a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>
            </div>

            <!-- Actividad Reciente -->
            <section class="dashboard-section">
                <h2>Actividad Reciente</h2>
                <div class="activity-timeline">
                    <?php foreach ($recent_activity as $activity): ?>
                    <div class="activity-item">
                        <div class="activity-icon">
                            <?php if ($activity['type'] == 'news'): ?>
                                <i class="fas fa-newspaper"></i>
                            <?php else: ?>
                                <i class="fas fa-comment"></i>
                            <?php endif; ?>
                        </div>
                        <div class="activity-content">
                            <div class="activity-text">
                                <?php if ($activity['type'] == 'news'): ?>
                                    <strong>Nueva noticia publicada:</strong> 
                                    <?php echo htmlspecialchars(mb_substr($activity['content'], 0, 50)) . '...'; ?>
                                <?php else: ?>
                                    <strong><?php echo htmlspecialchars($activity['author_name']); ?> comentó:</strong> 
                                    <?php echo htmlspecialchars(mb_substr($activity['content'], 0, 50)) . '...'; ?>
                                <?php endif; ?>
                            </div>
                            <div class="activity-time">
                                <?php echo date('d/m/Y H:i', strtotime($activity['created_at'])); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
    </main>

    <style>
        .dashboard-stats-mini {
            display: flex;
            gap: 15px;
            margin-top: 10px;
        }
        .stat-mini {
            font-size: 0.9rem;
            color: #666;
        }
        .stat-mini i {
            margin-right: 5px;
        }
        .stat-detail {
            font-size: 0.8rem;
            color: #666;
            margin-top: 5px;
        }
        .dashboard-columns {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }
        .action-badge {
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            position: absolute;
            top: -5px;
            right: -5px;
        }
        .news-stats {
            display: flex;
            gap: 10px;
            margin-top: 5px;
            font-size: 0.8rem;
            color: #666;
        }
        .no-comments {
            text-align: center;
            padding: 30px;
            color: #666;
        }
        .no-comments i {
            font-size: 2rem;
            margin-bottom: 10px;
            color: #28a745;
        }
        .activity-timeline {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .activity-item {
            display: flex;
            gap: 15px;
            padding: 15px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .activity-content {
            flex: 1;
        }
        .activity-text {
            margin-bottom: 5px;
        }
        .activity-time {
            font-size: 0.8rem;
            color: #666;
        }
        @media (max-width: 992px) {
            .dashboard-columns {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <script src="../js/dashboard.js"></script>
</body>
</html>