<?php
// admin/comments.php
require_once 'auth.php';
requireAuth();

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$current_user = getCurrentUser();

// Obtener parámetros de filtro
$status = $_GET['status'] ?? 'pending';
$page = $_GET['page'] ?? 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Construir consulta
$query = "
    SELECT c.*, n.title as news_title, n.slug as news_slug 
    FROM comments c 
    LEFT JOIN news n ON c.news_id = n.id 
    WHERE c.status = :status 
    ORDER BY c.created_at DESC 
    LIMIT :limit OFFSET :offset
";

$count_query = "
    SELECT COUNT(*) as total 
    FROM comments 
    WHERE status = :status
";

// Obtener comentarios
$stmt = $db->prepare($query);
$stmt->bindValue(':status', $status);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener total para paginación
$count_stmt = $db->prepare($count_query);
$count_stmt->bindValue(':status', $status);
$count_stmt->execute();
$total_count = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_count / $limit);

// Procesar acciones sobre comentarios
if (isset($_GET['action']) && isset($_GET['id'])) {
    $comment_id = $_GET['id'];
    $action = $_GET['action'];
    
    $new_status = '';
    $message = '';
    
    switch ($action) {
        case 'approve':
            $new_status = 'approved';
            $message = 'Comentario aprobado';
            break;
        case 'reject':
            $new_status = 'rejected';
            $message = 'Comentario rechazado';
            break;
        case 'delete':
            $delete_stmt = $db->prepare("DELETE FROM comments WHERE id = ?");
            $delete_stmt->execute([$comment_id]);
            $_SESSION['success_message'] = "Comentario eliminado";
            header('Location: comments.php?status=' . $status);
            exit;
    }
    
    if ($new_status) {
        $update_stmt = $db->prepare("UPDATE comments SET status = ? WHERE id = ?");
        $update_stmt->execute([$new_status, $comment_id]);
        $_SESSION['success_message'] = $message;
        header('Location: comments.php?status=' . $status);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Comentarios - Guinea-global</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="dashboard">
    <!-- Dashboard Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Dashboard Main Content -->
    <main class="dashboard-main">
        <header class="dashboard-header">
            <div class="dashboard-welcome">
                <h1>Gestión de Comentarios</h1>
                <p>Modera los comentarios de los lectores</p>
            </div>
        </header>

        <!-- Mensajes de éxito/error -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <div class="dashboard-content">
            <!-- Filtros -->
            <section class="dashboard-section">
                <div class="comments-filters">
                    <a href="comments.php?status=pending" class="filter-btn <?php echo $status == 'pending' ? 'active' : ''; ?>">
                        <i class="fas fa-clock"></i> Pendientes (<?php echo $db->query("SELECT COUNT(*) FROM comments WHERE status = 'pending'")->fetchColumn(); ?>)
                    </a>
                    <a href="comments.php?status=approved" class="filter-btn <?php echo $status == 'approved' ? 'active' : ''; ?>">
                        <i class="fas fa-check"></i> Aprobados (<?php echo $db->query("SELECT COUNT(*) FROM comments WHERE status = 'approved'")->fetchColumn(); ?>)
                    </a>
                    <a href="comments.php?status=rejected" class="filter-btn <?php echo $status == 'rejected' ? 'active' : ''; ?>">
                        <i class="fas fa-times"></i> Rechazados (<?php echo $db->query("SELECT COUNT(*) FROM comments WHERE status = 'rejected'")->fetchColumn(); ?>)
                    </a>
                </div>
            </section>

            <!-- Lista de comentarios -->
            <section class="dashboard-section">
                <div class="section-header">
                    <h2>
                        <?php 
                        $status_titles = [
                            'pending' => 'Comentarios Pendientes',
                            'approved' => 'Comentarios Aprobados', 
                            'rejected' => 'Comentarios Rechazados'
                        ];
                        echo $status_titles[$status] . " ($total_count)";
                        ?>
                    </h2>
                </div>
                
                <?php if (empty($comments)): ?>
                    <div class="no-data">
                        <i class="fas fa-comments fa-3x"></i>
                        <p>No hay comentarios <?php echo $status; ?></p>
                    </div>
                <?php else: ?>
                    <div class="comments-list">
                        <?php foreach ($comments as $comment): ?>
                        <div class="comment-item">
                            <div class="comment-header">
                                <div class="comment-author">
                                    <strong><?php echo htmlspecialchars($comment['author_name']); ?></strong>
                                    <?php if ($comment['author_email']): ?>
                                        <span class="comment-email">(<?php echo htmlspecialchars($comment['author_email']); ?>)</span>
                                    <?php endif; ?>
                                </div>
                                <div class="comment-meta">
                                    <span class="comment-date"><?php echo date('d/m/Y H:i', strtotime($comment['created_at'])); ?></span>
                                    <span class="comment-news">
                                        En: <a href="../noticia.php?slug=<?php echo $comment['news_slug']; ?>" target="_blank"><?php echo htmlspecialchars($comment['news_title']); ?></a>
                                    </span>
                                </div>
                            </div>
                            <div class="comment-content">
                                <?php echo nl2br(htmlspecialchars($comment['content'])); ?>
                            </div>
                            <div class="comment-actions">
                                <?php if ($status == 'pending'): ?>
                                    <a href="comments.php?action=approve&id=<?php echo $comment['id']; ?>&status=<?php echo $status; ?>" class="btn btn-sm btn-approve">
                                        <i class="fas fa-check"></i> Aprobar
                                    </a>
                                    <a href="comments.php?action=reject&id=<?php echo $comment['id']; ?>&status=<?php echo $status; ?>" class="btn btn-sm btn-reject">
                                        <i class="fas fa-times"></i> Rechazar
                                    </a>
                                <?php endif; ?>
                                <a href="comments.php?action=delete&id=<?php echo $comment['id']; ?>&status=<?php echo $status; ?>" class="btn btn-sm btn-delete" onclick="return confirm('¿Estás seguro de eliminar este comentario?')">
                                    <i class="fas fa-trash"></i> Eliminar
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Paginación -->
                    <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="comments.php?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="page-link">« Anterior</a>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <a href="comments.php?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" class="page-link <?php echo $i == $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="comments.php?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="page-link">Siguiente »</a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        </div>
    </main>

    <style>
        .comments-filters {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .filter-btn {
            padding: 10px 20px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
        }
        .filter-btn.active {
            background: #000;
            color: white;
            border-color: #000;
        }
        .filter-btn:hover {
            background: #e9ecef;
        }
        .filter-btn.active:hover {
            background: #333;
        }
        .comments-list {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .comment-item {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .comment-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }
        .comment-author {
            font-size: 1.1rem;
        }
        .comment-email {
            font-size: 0.9rem;
            color: #666;
        }
        .comment-meta {
            text-align: right;
            font-size: 0.9rem;
            color: #666;
        }
        .comment-news a {
            color: #007bff;
            text-decoration: none;
        }
        .comment-content {
            margin-bottom: 15px;
            line-height: 1.5;
        }
        .comment-actions {
            display: flex;
            gap: 10px;
        }
        @media (max-width: 768px) {
            .comment-header {
                flex-direction: column;
                gap: 5px;
            }
            .comment-meta {
                text-align: left;
            }
            .comments-filters {
                flex-direction: column;
            }
        }
    </style>

    <script src="../js/dashboard.js"></script>
</body>
</html>