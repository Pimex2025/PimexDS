<?php
require_once 'auth.php';
requireAuth();

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$id = $_GET['id'];
if ($id) {
    // Eliminar la noticia
    $query = "DELETE FROM news WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$id]);
}

header('Location: news.php');
exit;