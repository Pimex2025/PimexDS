from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector
import re



app= Flask(__name__)
CORS(app)

lista_tablas=["categories", "comments" ,"media", "news", "sections", "settings", "users"]


def nueva_conexion():

    #aqui cambia por tus datos para conectar con tu MY
    conn= mysql.connector.connect(
        host="localhost", #tu local host
        user="root", # el nombre de tu usuario creado en mysql
        #password="", # tu contraseña (si tienes) y si no o hace falta el parametro (osea que borra 'password')
        database="guinea_global" #el nombre de la base de datos
    )

    return conn


for tabla in lista_tablas:
    print(tabla)
    if tabla.strip()=="categories":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, secction_id VARCHAR(100), name  VARCHAR(100), slug VARCHAR(100), description VARCHAR(100), create_at VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla.strip()=="comments":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, news_id VARCHAR(100), author_name VARCHAR(100), author_email VARCHAR(100), content VARCHAR(100), status VARCHAR(100), created_at VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="media":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, filename VARCHAR(100), original_name VARCHAR(100), file_path VARCHAR(100), file_type VARCHAR(100), file_size VARCHAR(100), uploaded_by VARCHAR(100), uploaded_at VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="news":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, title VARCHAR(100), content VARCHAR(100), excerpt VARCHAR(100), meta_description VARCHAR(100), meta_keywords VARCHAR(100), image VARCHAR(100), image_alt VARCHAR(100), section_id VARCHAR(100), category_id VARCHAR(100), author_id VARCHAR(100), status VARCHAR(100), published_at VARCHAR(100), created_at VARCHAR(100), updated_at VARCHAR(100), views VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="categories":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, name	VARCHAR(100), slug VARCHAR(100), 	description	VARCHAR(100), created_at VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="categories":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY,  setting_key VARCHAR(100), setting_value VARCHAR(100), setting_type VARCHAR(100), updated_at VARCHAR(100), description VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="categories":
        try:
                            
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, username VARCHAR(100), password VARCHAR(100), full_name VARCHAR(100), email VARCHAR(100), role VARCHAR(100), created_at VARCHAR(100), last_login VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)        
    
    print("creado con exito LA TABLA {tabla}".format(tabla=tabla)) #cuando ejecutes este archivo veras un mensaje en la consola 'creado con ...' eso es que todo se ha creado bien



#aqui empiezan la manera en que haces tus peticiones
#supongamos que necesitas la lista de todos los comentarios para hacer lo que sea que quieras en tu codigo

# en tu codigo js, escribe un codigo como:
"""
    const url_1='http://127.0.0.1:5000/lista/nombre_del_encabzado;
    const url_2='http://192.168.100.117:5000/lista/nombre_del_encabezado;
    const lista = fetchall(url_1);
"""

# la funcion de arriba te hace una peticion hhttps y te devuelve la lista de la tabla que has pasado como argumento


@app.route("/lista/<encabezado>", methods=['GET'])
def lista_usuarios(encabezado):
    
    if request.method=="get":
        try:
                
            conn= nueva_conexion()
            cursor= conn.cursor(dictionary=True)
            query= f"SELECT * FROM {encabezado}"
            resultados=cursor.execute(query)
            #conn.commit()
            if resultados:
                return jsonify(resultados)
            else:
                return jsonify({'error':"noy hay datos"})
        except BaseException as e:
            return jsonify({'eRORR': 'Has hecho una mala peticion, Pringao jajajaj'})
    else:
        pass

#para agregar usuario de admin o comentarios dependiendo de la tabla


"""
    // aqui creamos las mismas urls que en el ejemplo anterior, pero recuerda que cuando lo alojes se usara la url absoluta, osea la que te dara esta misma api que se conectara a mysql online
    // en la url recuerda poner el encabezado al que te refieres, supongamos que comentarios, entonces la url seria: 'http://192.168.100.117:5000/agregar/comentarios
    const añadir_coment_usuario = fetchall(url, {
        method: 'POST',
        headers: {
            'Content-Type':'application/json',
            'body':JSON/stringnify({'nombre':nombre_variable, 'apellido':variable_que_contiene_apellido, 'alg_mas':mas_cosas})  // aqui es donde pasas los datos que quieres ingresar, supongamos que añdimos un usuario 
        }
    });
"""
# FIJATE BIEN EN DONDE HAY Y NO HAY COMAS. Puedes usar comas normales o simples; dá igual
#esa funcion te devolvera un valor 200 que significa que todo ha ido bien

@app.route("/agregar/<encabezado>", methods=['POST', 'GET'])
def agregar(encabezado):

    if request.method=='POST':
            
        conn= nueva_conexion()
        cursor= conn.cursor()
        query= f"INSERT INTO {encabezado}(nombre, apellido, clave) VALUES(%s, %s, %s)"
        data= request.get_json(force=True)
        nombre= data.get("nombre", None)
        apellido= data.get("apellido", None)
        contraseña= data.get("clave", None)

        if nombre and apellido and contraseña:
            cursor.execute(query, (nombre, apellido, contraseña))
            conn.commit()
            return jsonify({"status":200})
        else:
            return jsonify({"error":"Faltan algunas casillas obligatorias"})
    else:
        return jsonify({"ERROR": 'cambia el metodo de la peticion a "POST"'})

# lo mismo haces para actualizar una info, la misma manera cuando agregabas algo con una sola cosa:
# primero consulta la lista de la tabala que quieres actualizar e indentifica su ID y ponlo en la url:
# 'http://192.168.100.117:5000/actualizar/AQUI_PONES_EL_ID_QUE_QUIERES_ACTUALIZAR_UNA_INFo'
# osea que supongamos que quieres actualizar un comentario de 'juan', primero consultas cual es el ID de juan y es que usas en la url
# y despues ya haces la peticion con el metodo 'POST' como al agregar


@app.route("/actualizar/<int:id_user>", methods=['POST', 'GET'])
def actualizar(id_user):

    if request.method=="POST":
            
        conn= nueva_conexion()
        cursor= conn.cursor()

        datos= request.get_json(force=True)
        if datos:
            nombre= datos.get("nombre")
            apellidos=datos.get("apellidos")
            contraseña= datos.get("contraseña")

            if nombre:
                query= "UPDATE INTO administradores SET nombre=%s WHERE id=%s"
                cursor.execute(query, id_user)
            
            if apellidos:
                query= "UPDATE INTO administradores SET apellido=%s WHERE id=%s"
                cursor.execute(query, id_user)
            if contraseña:
                query= "UPDATE INTO administradores SET clave=%s WHERE id=%s"
                cursor.execute(query, id_user)


            return jsonify({"status":200})
        return jsonify({"error":"error de datos (no hay datos que actualizar)"}), 401
    
    else:
        return jsonify({"ERROR": 'cambia el metodo de la peticion a "POST"'})
    



# para ejecutar este archivo (abre una terminal, escribe: python api_python.py)
# fijate bien en la url que veas, es la url de conexion, si no es igual como en el ejemplo, solo sustituyelo, pero manteniendo los mismos parametros

if __name__=="__main__":
    app.run(host="0.0.0.0", port=5000)


# AHORA DEJAME TRABAJAR EN PAZ 😂😂😂😂😂😂😂