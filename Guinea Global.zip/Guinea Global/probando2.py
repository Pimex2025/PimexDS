from flask import Flask, request, jsonify
import mysql.connector

app= Flask(__name__)

def nueva_conexion():
    conn= mysql.connector.connect(host="localhost", user="root", password="admin", db="guinea_global")
    return conn

lista_tablas=['categories', 'comments', 'media', 'news', 'sections', 'settings', 'users']


for tabla in lista_tablas:

    if tabla.strip()=="categories":
        try:    
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, secction_id VARCHAR(100), name  VARCHAR(100), slug VARCHAR(100), description VARCHAR(100), create_at VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla.strip()=="comments":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, news_id VARCHAR(100), author_name VARCHAR(100), author_email VARCHAR(100), content VARCHAR(100), status VARCHAR(100), created_at VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="media":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, filename VARCHAR(100), original_name VARCHAR(100), file_path VARCHAR(100), file_type VARCHAR(100), file_size VARCHAR(100), uploaded_by VARCHAR(100), uploaded_at VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="news":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, title VARCHAR(100), content VARCHAR(100), excerpt VARCHAR(100), meta_description VARCHAR(100), meta_keywords VARCHAR(100), image VARCHAR(100), image_alt VARCHAR(100), section_id VARCHAR(100), category_id VARCHAR(100), author_id VARCHAR(100), status VARCHAR(100), published_at VARCHAR(100), created_at VARCHAR(100), updated_at VARCHAR(100), views VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="sections":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, name	VARCHAR(100), slug VARCHAR(100), 	description	VARCHAR(100), created_at VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="settings":
        try:    
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY,  setting_key VARCHAR(100), setting_value VARCHAR(100), setting_type VARCHAR(100), updated_at VARCHAR(100), description VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)
    if tabla=="users":
        try:
                            
            nombre_tabal=tabla #ejemplo (media como en tu proyecto)
            conn= nueva_conexion()
            cursor= conn.cursor()
            query=f"CREATE TABLE IF NOT EXISTS {tabla}(id int AUTO_INCREMENT PRIMARY KEY, username VARCHAR(100), password VARCHAR(100), full_name VARCHAR(100), email VARCHAR(100), role VARCHAR(100), created_at VARCHAR(100), last_login VARCHAR(100))" #donde asegurate de poner el nombre de cada encabezado de tu tabla (usuario, clave, etc...)
            cursor.execute(query)
            conn.commit()
        except BaseException as e:
            print(f"error de creacion LA TABLA {tabla}") #si ves este es que ha habido un error, me puedes dejar un whatsapp
            print(e)        
    
    print("creado con exito LA TABLA {tabla}".format(tabla=tabla)) #cuando ejecutes este archivo veras un mensaje en la consola 'creado con ...' eso es que todo se ha creado bien


@app.route("/add_categoria", methods=['POST'])
def categoria():
    if request.method=="POST":
        datos= request.get_json()
        name= datos.get('name')
        section_id= datos.get('secction_id')
        slug= datos.get('slug')
        descripcion= datos.get('description')
        create_at= datos.get('create_at')

        try:
            conn= nueva_conexion()
            query= "INSERT INTO categories (name, secction_id, slug, description, create_at) VALUES(%s, %s, %s, %s, %s)"
            data= f"{name}", f"{section_id}", f"{slug}", f"{descripcion}", f"{create_at}"

            cursor= conn.cursor()
            cursor.execute(query, data)
            conn.commit()

            return jsonify({'ok':'guardado'})
        except BaseException as e:
            print(e)
            return jsonify({'error':f"{e}"})
    else:
        return jsonify({'error':'cambia de metodo'})

app.run(host="0.0.0.0", port=5000)