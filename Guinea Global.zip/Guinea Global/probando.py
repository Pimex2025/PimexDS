import os


encontrado=None

for routes, _, files in os.walk("c:\\"):
    for file in files:
        if "flask" in file.lower():
            print(os.path.join(routes, file))
            encontrado=True
    

if not encontrado:
    print("no hay flask")