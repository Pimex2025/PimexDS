import requests
import datetime


datos={
    "name":"deporte",
    "secction_id":"2",
    "slug":"parte de slug",
    "description":"noticia hacia categoria",
    "create_at":datetime.datetime.now().strftime("%H:%M:%S")
}

headers={
    "Content-Type":"application/json"
}

res= requests.post('http://192.168.100.117:5000/add_categoria', json=datos,headers=headers)
if res:
    print(res.json())