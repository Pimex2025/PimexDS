// js/dashboard.js

// Funcionalidad específica para el panel de administración

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar funcionalidades del dashboard
    initializeDashboard();
    
    // Funcionalidad de los elementos colapsables (FAQ)
    initializeFAQ();
    
    // Funcionalidad de filtrado para las tablas
    initializeTableFilters();
    
    // Simulación de datos del dashboard
    initializeDashboardData();
});

function initializeDashboard() {
    // Toggle del sidebar en dispositivos móviles
    const sidebarToggle = document.createElement('button');
    sidebarToggle.className = 'sidebar-toggle';
    sidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
    sidebarToggle.style.display = 'none';
    
    const dashboardHeader = document.querySelector('.dashboard-header');
    if (dashboardHeader) {
        dashboardHeader.appendChild(sidebarToggle);
    }
    
    sidebarToggle.addEventListener('click', function() {
        document.querySelector('.dashboard-sidebar').classList.toggle('active');
    });
    
    // Mostrar/ocultar sidebar en móviles
    function handleResize() {
        if (window.innerWidth <= 992) {
            sidebarToggle.style.display = 'block';
            document.querySelector('.dashboard-sidebar').classList.remove('active');
        } else {
            sidebarToggle.style.display = 'none';
            document.querySelector('.dashboard-sidebar').classList.add('active');
        }
    }
    
    window.addEventListener('resize', handleResize);
    handleResize();
    
    // Notificaciones
    const notificationBell = document.querySelector('.notification-bell');
    if (notificationBell) {
        notificationBell.addEventListener('click', function() {
            alert('Tienes 3 notificaciones sin leer:\n- 2 comentarios pendientes de aprobación\n- 1 nueva solicitud de suscripción');
        });
    }
}

function initializeFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', function() {
            // Cerrar otros items abiertos
            faqItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    otherItem.classList.remove('active');
                }
            });
            
            // Alternar el item actual
            item.classList.toggle('active');
        });
    });
}

function initializeTableFilters() {
    // En una implementación real, esto filtraría los datos de la tabla
    console.log('Inicializando filtros de tabla...');
}

function initializeDashboardData() {
    // Simular la actualización de estadísticas en tiempo real
    updateStatsPeriodically();
    
    // Simular la carga de datos de gráficos
    simulateChartData();
}

function updateStatsPeriodically() {
    // Simular actualización de estadísticas cada 30 segundos
    setInterval(() => {
        const statNumbers = document.querySelectorAll('.stat-number');
        
        statNumbers.forEach(stat => {
            const currentValue = parseInt(stat.textContent.replace(/,/g, ''));
            const randomIncrement = Math.floor(Math.random() * 10) + 1;
            const newValue = currentValue + randomIncrement;
            
            // Animación simple del contador
            animateValue(stat, currentValue, newValue, 1000);
        });
    }, 30000);
}

function animateValue(element, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const value = Math.floor(progress * (end - start) + start);
        element.textContent = value.toLocaleString();
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

function simulateChartData() {
    // En una implementación real, esto cargaría datos de gráficos desde una API
    console.log('Cargando datos de gráficos...');
}

// Funcionalidad para aprobar/rechazar comentarios
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('btn-approve') || 
        e.target.parentElement.classList.contains('btn-approve')) {
        const button = e.target.classList.contains('btn-approve') ? e.target : e.target.parentElement;
        const commentItem = button.closest('.comment-item');
        
        // Simular aprobación de comentario
        commentItem.style.opacity = '0.5';
        setTimeout(() => {
            commentItem.remove();
            updateCommentCount();
        }, 500);
        
        alert('Comentario aprobado correctamente');
    }
    
    if (e.target.classList.contains('btn-reject') || 
        e.target.parentElement.classList.contains('btn-reject')) {
        const button = e.target.classList.contains('btn-reject') ? e.target : e.target.parentElement;
        const commentItem = button.closest('.comment-item');
        
        // Simular rechazo de comentario
        commentItem.style.opacity = '0.5';
        setTimeout(() => {
            commentItem.remove();
            updateCommentCount();
        }, 500);
        
        alert('Comentario rechazado correctamente');
    }
});

function updateCommentCount() {
    const commentCount = document.querySelector('.stat-comments .stat-number');
    if (commentCount) {
        const currentCount = parseInt(commentCount.textContent);
        commentCount.textContent = (currentCount - 1).toString();
    }
}

// Funcionalidad para publicar noticias pendientes
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('btn-publish') || 
        e.target.parentElement.classList.contains('btn-publish')) {
        const button = e.target.classList.contains('btn-publish') ? e.target : e.target.parentElement;
        const tableRow = button.closest('.table-row');
        const statusBadge = tableRow.querySelector('.status-badge');
        
        // Cambiar estado a publicado
        statusBadge.textContent = 'Publicado';
        statusBadge.className = 'status-badge published';
        
        // Cambiar botones
        const actionsCol = tableRow.querySelector('.col-actions');
        actionsCol.innerHTML = `
            <button class="btn btn-sm btn-edit"><i class="fas fa-edit"></i></button>
            <button class="btn btn-sm btn-delete"><i class="fas fa-trash"></i></button>
        `;
        
        alert('Noticia publicada correctamente');
    }
});

// Funcionalidad para eliminar noticias
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('btn-delete') || 
        e.target.parentElement.classList.contains('btn-delete')) {
        if (confirm('¿Estás seguro de que quieres eliminar esta noticia? Esta acción no se puede deshacer.')) {
            const button = e.target.classList.contains('btn-delete') ? e.target : e.target.parentElement;
            const tableRow = button.closest('.table-row');
            
            // Animación de eliminación
            tableRow.style.opacity = '0';
            setTimeout(() => {
                tableRow.remove();
                updateNewsCount();
            }, 500);
            
            alert('Noticia eliminada correctamente');
        }
    }
});

function updateNewsCount() {
    const newsCount = document.querySelector('.stat-news .stat-number');
    if (newsCount) {
        const currentCount = parseInt(newsCount.textContent);
        newsCount.textContent = (currentCount - 1).toString();
    }
}

// Simulación de notificaciones en tiempo real
setTimeout(() => {
    // Simular una nueva notificación después de 1 minuto
    const notificationCount = document.querySelector('.notification-count');
    if (notificationCount) {
        const currentCount = parseInt(notificationCount.textContent);
        notificationCount.textContent = (currentCount + 1).toString();
        
        // Mostrar toast de notificación
        showNotification('Nuevo comentario pendiente de aprobación');
    }
}, 60000);

function showNotification(message) {
    // Crear elemento de notificación toast
    const toast = document.createElement('div');
    toast.className = 'notification-toast';
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-bell"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close"><i class="fas fa-times"></i></button>
    `;
    
    // Estilos para el toast
    toast.style.position = 'fixed';
    toast.style.top = '20px';
    toast.style.right = '20px';
    toast.style.background = 'white';
    toast.style.padding = '15px 20px';
    toast.style.borderRadius = '8px';
    toast.style.boxShadow = '0 4px 15px rgba(0,0,0,0.1)';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '10px';
    toast.style.zIndex = '10000';
    toast.style.maxWidth = '350px';
    toast.style.borderLeft = '4px solid var(--primary-color)';
    toast.style.animation = 'slideIn 0.3s ease-out';
    
    // Estilos para el contenido
    const toastContent = toast.querySelector('.toast-content');
    toastContent.style.display = 'flex';
    toastContent.style.alignItems = 'center';
    toastContent.style.gap = '10px';
    toastContent.style.flex = '1';
    
    // Estilos para el botón de cerrar
    const toastClose = toast.querySelector('.toast-close');
    toastClose.style.background = 'none';
    toastClose.style.border = 'none';
    toastClose.style.cursor = 'pointer';
    toastClose.style.color = '#6c757d';
    
    // Añadir al documento
    document.body.appendChild(toast);
    
    // Cerrar toast al hacer clic en el botón
    toastClose.addEventListener('click', function() {
        toast.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => {
            toast.remove();
        }, 300);
    });
    
    // Cerrar automáticamente después de 5 segundos
    setTimeout(() => {
        if (document.body.contains(toast)) {
            toast.style.animation = 'slideOut 0.3s ease-in';
            setTimeout(() => {
                toast.remove();
            }, 300);
        }
    }, 5000);
}

// Añadir estilos de animación para las notificaciones
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);


// Inicialización específica del dashboard
function initPage() {
    loadDashboardStats();
    loadRecentNews();
    loadRecentComments();
    initQuickActions();
    initChartPlaceholders();
}

// Cargar estadísticas del dashboard
function loadDashboardStats() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    
    // Actualizar contadores
    document.querySelector('.stat-card:nth-child(1) .stat-number').textContent = data.news.length;
    document.querySelector('.stat-card:nth-child(2) .stat-number').textContent = '84,521';
    document.querySelector('.stat-card:nth-child(3) .stat-number').textContent = '8,452';
    document.querySelector('.stat-card:nth-child(4) .stat-number').textContent = 
        data.comments.filter(comment => comment.status === 'pending').length;
}

// Cargar noticias recientes
function loadRecentNews() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const recentNewsContainer = document.querySelector('.recent-news .news-table');
    
    if (!recentNewsContainer) return;
    
    // Limpiar contenido existente (excepto el header)
    const tableHeader = recentNewsContainer.querySelector('.table-header');
    recentNewsContainer.innerHTML = '';
    recentNewsContainer.appendChild(tableHeader);
    
    // Añadir noticias recientes (máximo 4)
    const recentNews = data.news.slice(0, 4);
    
    recentNews.forEach(news => {
        const row = document.createElement('div');
        row.className = 'table-row';
        row.innerHTML = `
            <div class="col-title">
                <h4>${news.title}</h4>
            </div>
            <div class="col-category">
                <span class="category-badge ${news.category.toLowerCase()}">${news.category}</span>
            </div>
            <div class="col-date">${formatDate(news.createdAt)}</div>
            <div class="col-status">
                <span class="status-badge ${news.status === 'published' ? 'published' : 'pending'}">
                    ${news.status === 'published' ? 'Publicado' : 'Pendiente'}
                </span>
            </div>
            <div class="col-actions">
                <button class="btn btn-sm btn-edit" onclick="editNews(${news.id})"><i class="fas fa-edit"></i></button>
                ${news.status === 'published' ? 
                    `<button class="btn btn-sm btn-delete" onclick="deleteNews(${news.id})"><i class="fas fa-trash"></i></button>` :
                    `<button class="btn btn-sm btn-publish" onclick="publishNews(${news.id})"><i class="fas fa-check"></i></button>`
                }
            </div>
        `;
        recentNewsContainer.appendChild(row);
    });
}

// Cargar comentarios recientes
function loadRecentComments() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const recentCommentsContainer = document.querySelector('.recent-comments');
    
    if (!recentCommentsContainer) return;
    
    // Limpiar contenido existente
    recentCommentsContainer.innerHTML = '';
    
    // Añadir comentarios recientes (máximo 3)
    const recentComments = data.comments.slice(0, 3);
    
    recentComments.forEach(comment => {
        const commentItem = document.createElement('div');
        commentItem.className = 'comment-item';
        commentItem.innerHTML = `
            <div class="comment-avatar">
                <img src="${comment.userAvatar}" alt="${comment.userName}">
            </div>
            <div class="comment-content">
                <div class="comment-header">
                    <h4>${comment.userName}</h4>
                    <span class="comment-date">${formatTimeAgo(comment.createdAt)}</span>
                </div>
                <p class="comment-text">${comment.content}</p>
                <div class="comment-actions">
                    <button class="btn btn-sm btn-approve" onclick="approveComment(${comment.id})">Aprobar</button>
                    <button class="btn btn-sm btn-reject" onclick="rejectComment(${comment.id})">Rechazar</button>
                    <button class="btn btn-sm btn-reply" onclick="replyToComment(${comment.id})">Responder</button>
                </div>
            </div>
        `;
        recentCommentsContainer.appendChild(commentItem);
    });
}

// Inicializar acciones rápidas
function initQuickActions() {
    const actionCards = document.querySelectorAll('.action-card');
    
    actionCards.forEach(card => {
        card.addEventListener('click', function(e) {
            e.preventDefault();
            const href = this.getAttribute('href');
            
            if (href === 'dashboard-news.html') {
                // Abrir modal para nueva noticia
                openModal('newNewsModal');
            } else {
                // Navegar a la página correspondiente
                window.location.href = href;
            }
        });
    });
}

// Inicializar gráficos de ejemplo
function initChartPlaceholders() {
    // Esta función inicializaría gráficos reales con una librería como Chart.js
    // Por ahora, solo mantenemos los placeholders
}

// Funciones para manejar noticias
function editNews(newsId) {
    // Redirigir a la página de edición de noticias
    window.location.href = `dashboard-news.html?edit=${newsId}`;
}

function deleteNews(newsId) {
    if (confirm('¿Estás seguro de que quieres eliminar esta noticia?')) {
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        data.news = data.news.filter(news => news.id !== newsId);
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Noticia eliminada correctamente', 'success');
        loadRecentNews();
        loadDashboardStats();
    }
}

function publishNews(newsId) {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const newsIndex = data.news.findIndex(news => news.id === newsId);
    
    if (newsIndex !== -1) {
        data.news[newsIndex].status = 'published';
        data.news[newsIndex].updatedAt = new Date().toISOString().split('T')[0];
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Noticia publicada correctamente', 'success');
        loadRecentNews();
        loadDashboardStats();
    }
}

// Funciones para manejar comentarios
function approveComment(commentId) {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const commentIndex = data.comments.findIndex(comment => comment.id === commentId);
    
    if (commentIndex !== -1) {
        data.comments[commentIndex].status = 'approved';
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Comentario aprobado', 'success');
        loadRecentComments();
        loadDashboardStats();
    }
}

function rejectComment(commentId) {
    if (confirm('¿Estás seguro de que quieres rechazar este comentario?')) {
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        data.comments = data.comments.filter(comment => comment.id !== commentId);
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Comentario rechazado', 'success');
        loadRecentComments();
        loadDashboardStats();
    }
}

function replyToComment(commentId) {
    // Abrir modal para responder al comentario
    openModal('replyCommentModal');
    
    // Guardar el ID del comentario para usarlo al enviar la respuesta
    const modal = document.getElementById('replyCommentModal');
    modal.setAttribute('data-comment-id', commentId);
}

// Utilidad para formatear "hace X tiempo"
function formatTimeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) {
        return 'Hace un momento';
    } else if (diffMins < 60) {
        return `Hace ${diffMins} minuto${diffMins > 1 ? 's' : ''}`;
    } else if (diffHours < 24) {
        return `Hace ${diffHours} hora${diffHours > 1 ? 's' : ''}`;
    } else if (diffDays < 7) {
        return `Hace ${diffDays} día${diffDays > 1 ? 's' : ''}`;
    } else {
        return formatDate(dateString);
    }
}

// Manejar el botón "Nueva Noticia" en el header
document.addEventListener('DOMContentLoaded', function() {
    const newNewsBtn = document.querySelector('.dashboard-actions .btn-primary');
    if (newNewsBtn) {
        newNewsBtn.addEventListener('click', function() {
            openModal('newNewsModal');
        });
    }
});

// js/dashboard.js

// Funcionalidad específica para el panel de administración

// Configuración de la API
const API_BASE_URL = 'https://tu-api-guinea-global.com/api'; // Cambia por tu URL real
const API_ENDPOINTS = {
    COMMENTS: '/comments',
    SUBSCRIBERS: '/subscribers',
    NEWS: '/news',
    CATEGORIES: '/categories'
};

// Headers para las peticiones API
const getAuthHeaders = () => {
    const token = localStorage.getItem('admin_token'); // Asumiendo que usas JWT
    return {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };
};

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar funcionalidades del dashboard
    initializeDashboard();
    
    // Funcionalidad de los elementos colapsables (FAQ)
    initializeFAQ();
    
    // Funcionalidad de filtrado para las tablas
    initializeTableFilters();
    
    // Cargar datos reales del dashboard
    initializeDashboardData();
    
    // Cargar comentarios pendientes
    loadPendingComments();
    
    // Cargar suscriptores
    loadSubscribers();
    
    // Cargar categorías para el formulario de noticias
    loadCategories();
});

// ==================== FUNCIONES PARA COMENTARIOS ====================

/**
 * Carga los comentarios pendientes de aprobación desde la API
 */
async function loadPendingComments() {
    try {
        showLoading('comments-section');
        
        const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.COMMENTS}?status=pending`, {
            method: 'GET',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        const comments = await response.json();
        displayComments(comments);
        updateCommentCount(comments.length);
        
    } catch (error) {
        console.error('Error cargando comentarios:', error);
        showError('comments-section', 'Error al cargar los comentarios');
    }
}

/**
 * Muestra los comentarios en la interfaz
 */
function displayComments(comments) {
    const commentsContainer = document.querySelector('.comments-list');
    
    if (!commentsContainer) return;
    
    if (comments.length === 0) {
        commentsContainer.innerHTML = `
            <div class="no-comments">
                <i class="fas fa-comments"></i>
                <p>No hay comentarios pendientes de aprobación</p>
            </div>
        `;
        return;
    }
    
    commentsContainer.innerHTML = comments.map(comment => `
        <div class="comment-item" data-comment-id="${comment.id}">
            <div class="comment-header">
                <div class="comment-author">
                    <strong>${comment.author_name}</strong>
                    <span class="comment-email">${comment.author_email}</span>
                </div>
                <div class="comment-date">${formatDate(comment.created_at)}</div>
            </div>
            <div class="comment-content">
                <p>${comment.content}</p>
            </div>
            <div class="comment-article">
                <small>En: ${comment.article_title || 'Artículo general'}</small>
            </div>
            <div class="comment-actions">
                <button class="btn btn-success btn-approve" onclick="approveComment(${comment.id})">
                    <i class="fas fa-check"></i> Aprobar
                </button>
                <button class="btn btn-danger btn-reject" onclick="rejectComment(${comment.id})">
                    <i class="fas fa-times"></i> Rechazar
                </button>
            </div>
        </div>
    `).join('');
}

/**
 * Aprueba un comentario
 */
async function approveComment(commentId) {
    try {
        const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.COMMENTS}/${commentId}/approve`, {
            method: 'PUT',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        // Remover el comentario de la lista
        const commentItem = document.querySelector(`[data-comment-id="${commentId}"]`);
        if (commentItem) {
            commentItem.style.opacity = '0.5';
            setTimeout(() => {
                commentItem.remove();
                updateCommentCount();
            }, 500);
        }
        
        showNotification('Comentario aprobado correctamente', 'success');
        
    } catch (error) {
        console.error('Error aprobando comentario:', error);
        showNotification('Error al aprobar el comentario', 'error');
    }
}

/**
 * Rechaza un comentario
 */
async function rejectComment(commentId) {
    if (!confirm('¿Estás seguro de que quieres rechazar este comentario?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.COMMENTS}/${commentId}/reject`, {
            method: 'PUT',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        // Remover el comentario de la lista
        const commentItem = document.querySelector(`[data-comment-id="${commentId}"]`);
        if (commentItem) {
            commentItem.style.opacity = '0.5';
            setTimeout(() => {
                commentItem.remove();
                updateCommentCount();
            }, 500);
        }
        
        showNotification('Comentario rechazado correctamente', 'success');
        
    } catch (error) {
        console.error('Error rechazando comentario:', error);
        showNotification('Error al rechazar el comentario', 'error');
    }
}

// ==================== FUNCIONES PARA SUSCRIPTORES ====================

/**
 * Carga la lista de suscriptores desde la API
 */
async function loadSubscribers() {
    try {
        showLoading('subscribers-section');
        
        const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.SUBSCRIBERS}`, {
            method: 'GET',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        const subscribers = await response.json();
        displaySubscribers(subscribers);
        updateSubscriberCount(subscribers.length);
        
    } catch (error) {
        console.error('Error cargando suscriptores:', error);
        showError('subscribers-section', 'Error al cargar los suscriptores');
    }
}

/**
 * Muestra los suscriptores en la interfaz
 */
function displaySubscribers(subscribers) {
    const subscribersContainer = document.querySelector('.subscribers-list');
    
    if (!subscribersContainer) return;
    
    if (subscribers.length === 0) {
        subscribersContainer.innerHTML = `
            <div class="no-data">
                <i class="fas fa-users"></i>
                <p>No hay suscriptores registrados</p>
            </div>
        `;
        return;
    }
    
    subscribersContainer.innerHTML = subscribers.map(subscriber => `
        <div class="subscriber-item">
            <div class="subscriber-info">
                <div class="subscriber-name">
                    <strong>${subscriber.name || 'Suscriptor'}</strong>
                </div>
                <div class="subscriber-email">${subscriber.email}</div>
                <div class="subscriber-date">
                    <small>Suscrito: ${formatDate(subscriber.subscribed_at)}</small>
                </div>
            </div>
            <div class="subscriber-actions">
                <button class="btn btn-sm btn-primary" onclick="viewSubscriberDetails(${subscriber.id})">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteSubscriber(${subscriber.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

/**
 * Elimina un suscriptor
 */
async function deleteSubscriber(subscriberId) {
    if (!confirm('¿Estás seguro de que quieres eliminar este suscriptor?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.SUBSCRIBERS}/${subscriberId}`, {
            method: 'DELETE',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        // Recargar la lista de suscriptores
        loadSubscribers();
        showNotification('Suscriptor eliminado correctamente', 'success');
        
    } catch (error) {
        console.error('Error eliminando suscriptor:', error);
        showNotification('Error al eliminar el suscriptor', 'error');
    }
}

// ==================== FUNCIONES PARA NOTICIAS ====================

/**
 * Carga las categorías disponibles para las noticias
 */
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.CATEGORIES}`, {
            method: 'GET',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        const categories = await response.json();
        populateCategorySelect(categories);
        
    } catch (error) {
        console.error('Error cargando categorías:', error);
    }
}

/**
 * Llena el select de categorías en el formulario de noticias
 */
function populateCategorySelect(categories) {
    const categorySelect = document.getElementById('news-category');
    
    if (!categorySelect) return;
    
    categorySelect.innerHTML = categories.map(category => 
        `<option value="${category.id}">${category.name}</option>`
    ).join('');
}

/**
 * Envía una nueva noticia a la API
 */
async function submitNews(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const newsData = {
        title: formData.get('title'),
        content: formData.get('content'),
        category_id: parseInt(formData.get('category_id')),
        excerpt: formData.get('excerpt'),
        featured_image: formData.get('featured_image'),
        status: formData.get('status') || 'draft'
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.NEWS}`, {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(newsData)
        });
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        const result = await response.json();
        
        showNotification('Noticia creada correctamente', 'success');
        form.reset();
        
        // Recargar la lista de noticias si es necesario
        loadPendingNews();
        
    } catch (error) {
        console.error('Error creando noticia:', error);
        showNotification('Error al crear la noticia', 'error');
    }
}

/**
 * Carga las noticias pendientes de publicación
 */
async function loadPendingNews() {
    try {
        const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.NEWS}?status=draft`, {
            method: 'GET',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        const news = await response.json();
        displayPendingNews(news);
        
    } catch (error) {
        console.error('Error cargando noticias pendientes:', error);
    }
}

// ==================== FUNCIONES AUXILIARES ====================

/**
 * Formatea una fecha para mostrarla
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/**
 * Muestra un estado de carga
 */
function showLoading(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.innerHTML = `
            <div class="loading-spinner">
                <i class="fas fa-spinner fa-spin"></i>
                <p>Cargando...</p>
            </div>
        `;
    }
}

/**
 * Muestra un mensaje de error
 */
function showError(sectionId, message) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>${message}</p>
                <button class="btn btn-retry" onclick="location.reload()">Reintentar</button>
            </div>
        `;
    }
}

/**
 * Muestra una notificación toast mejorada
 */
function showNotification(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `notification-toast ${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close"><i class="fas fa-times"></i></button>
    `;
    
    // Aplicar estilos según el tipo
    const typeStyles = {
        success: { borderLeft: '4px solid #28a745', background: '#d4edda', color: '#155724' },
        error: { borderLeft: '4px solid #dc3545', background: '#f8d7da', color: '#721c24' },
        warning: { borderLeft: '4px solid #ffc107', background: '#fff3cd', color: '#856404' },
        info: { borderLeft: '4px solid #17a2b8', background: '#d1ecf1', color: '#0c5460' }
    };
    
    Object.assign(toast.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '15px 20px',
        borderRadius: '8px',
        boxShadow: '0 4px 15px rgba(0,0,0,0.1)',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        zIndex: '10000',
        maxWidth: '350px',
        animation: 'slideIn 0.3s ease-out',
        ...typeStyles[type]
    });
    
    document.body.appendChild(toast);
    
    // Cerrar toast
    const toastClose = toast.querySelector('.toast-close');
    toastClose.addEventListener('click', function() {
        toast.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => toast.remove(), 300);
    });
    
    // Cerrar automáticamente después de 5 segundos
    setTimeout(() => {
        if (document.body.contains(toast)) {
            toast.style.animation = 'slideOut 0.3s ease-in';
            setTimeout(() => toast.remove(), 300);
        }
    }, 5000);
}

function getNotificationIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'bell';
}

// ==================== INICIALIZACIÓN MEJORADA ====================

function initializeDashboardData() {
    // Cargar estadísticas reales desde la API
    loadDashboardStats();
    
    // Simular actualización periódica
    setInterval(loadDashboardStats, 30000);
}

async function loadDashboardStats() {
    try {
        // En una implementación real, tendrías un endpoint específico para estadísticas
        const [commentsRes, subscribersRes, newsRes] = await Promise.all([
            fetch(`${API_BASE_URL}${API_ENDPOINTS.COMMENTS}/count`),
            fetch(`${API_BASE_URL}${API_ENDPOINTS.SUBSCRIBERS}/count`),
            fetch(`${API_BASE_URL}${API_ENDPOINTS.NEWS}/count`)
        ]);
        
        const commentsCount = await commentsRes.json();
        const subscribersCount = await subscribersRes.json();
        const newsCount = await newsRes.json();
        
        // Actualizar los contadores en la interfaz
        updateStatCounter('.stat-comments .stat-number', commentsCount.pending || 0);
        updateStatCounter('.stat-subscribers .stat-number', subscribersCount.total || 0);
        updateStatCounter('.stat-news .stat-number', newsCount.total || 0);
        
    } catch (error) {
        console.error('Error cargando estadísticas:', error);
    }
}

function updateStatCounter(selector, newValue) {
    const element = document.querySelector(selector);
    if (element) {
        const currentValue = parseInt(element.textContent.replace(/,/g, '')) || 0;
        if (currentValue !== newValue) {
            animateValue(element, currentValue, newValue, 1000);
        }
    }
}

// Las funciones existentes del dashboard permanecen igual...
// (initializeDashboard, initializeFAQ, initializeTableFilters, etc.)

// Añadir event listeners para el formulario de noticias
document.addEventListener('DOMContentLoaded', function() {
    const newsForm = document.getElementById('news-form');
    if (newsForm) {
        newsForm.addEventListener('submit', submitNews);
    }
});