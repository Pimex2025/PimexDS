// Variables para la gestión de medios
let currentMedia = [];
let selectedMedia = null;

// Inicialización de la página de medios
function initPage() {
    loadMedia();
    setupFilters();
    setupUploadArea();
}

// Cargar medios
function loadMedia() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    currentMedia = data.media;
    displayMedia();
}

// Mostrar medios en la cuadrícula
function displayMedia() {
    const mediaGrid = document.getElementById('mediaGrid');
    mediaGrid.innerHTML = '';
    
    if (currentMedia.length === 0) {
        mediaGrid.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1; text-align: center; padding: 40px;">
                <i class="fas fa-images" style="font-size: 48px; color: #95a5a6; margin-bottom: 15px;"></i>
                <h3>No hay archivos multimedia</h3>
                <p>Sube tu primer archivo para comenzar</p>
            </div>
        `;
        return;
    }
    
    currentMedia.forEach(media => {
        const mediaItem = document.createElement('div');
        mediaItem.className = 'media-item';
        mediaItem.innerHTML = `
            <div class="media-thumb">
                ${media.type === 'image' ? 
                    `<img src="${media.url}" alt="${media.name}" onclick="previewMedia(${media.id})">` :
                    `<i class="fas fa-file" style="font-size: 48px; color: #95a5a6;"></i>`
                }
            </div>
            <div class="media-info">
                <div class="media-name">${media.name}</div>
                <div class="media-meta">
                    <span>${media.type}</span>
                    <span>${media.size}</span>
                </div>
            </div>
            <div class="media-actions">
                <button class="btn btn-sm btn-edit" onclick="previewMedia(${media.id})">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-delete" onclick="deleteMedia(${media.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        mediaGrid.appendChild(mediaItem);
    });
}

// Configurar filtros
function setupFilters() {
    const typeFilter = document.getElementById('typeFilter');
    const dateFilter = document.getElementById('dateFilter');
    const searchFilter = document.getElementById('searchFilter');
    
    [typeFilter, dateFilter, searchFilter].forEach(filter => {
        filter.addEventListener('change', applyFilters);
        filter.addEventListener('input', applyFilters);
    });
}

// Aplicar filtros
function applyFilters() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    let filtered = data.media;
    
    const type = document.getElementById('typeFilter').value;
    const date = document.getElementById('dateFilter').value;
    const search = document.getElementById('searchFilter').value.toLowerCase();
    
    if (type) {
        filtered = filtered.filter(media => media.type === type);
    }
    
    if (date) {
        filtered = filtered.filter(media => media.uploadedAt === date);
    }
    
    if (search) {
        filtered = filtered.filter(media => 
            media.name.toLowerCase().includes(search)
        );
    }
    
    currentMedia = filtered;
    displayMedia();
}

// Configurar área de subida
function setupUploadArea() {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    
    // Click en el área de subida
    uploadArea.addEventListener('click', function() {
        fileInput.click();
    });
    
    // Arrastrar y soltar
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.style.borderColor = '#3498db';
        uploadArea.style.backgroundColor = '#f8f9fa';
    });
    
    uploadArea.addEventListener('dragleave', function() {
        uploadArea.style.borderColor = '#ddd';
        uploadArea.style.backgroundColor = '';
    });
    
    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.style.borderColor = '#ddd';
        uploadArea.style.backgroundColor = '';
        
        const files = e.dataTransfer.files;
        handleFileUpload(files);
    });
    
    // Cambio en el input de archivos
    fileInput.addEventListener('change', function() {
        handleFileUpload(this.files);
    });
}

// Manejar subida de archivos
function handleFileUpload(files) {
    if (files.length === 0) return;
    
    const uploadArea = document.getElementById('uploadArea');
    const uploadProgress = document.getElementById('uploadProgress');
    const progressFill = document.getElementById('progressFill');
    const uploadStatus = document.getElementById('uploadStatus');
    
    uploadArea.style.display = 'none';
    uploadProgress.style.display = 'block';
    
    let uploadedCount = 0;
    const totalFiles = files.length;
    
    Array.from(files).forEach((file, index) => {
        setTimeout(() => {
            uploadFile(file).then(() => {
                uploadedCount++;
                const progress = (uploadedCount / totalFiles) * 100;
                progressFill.style.width = `${progress}%`;
                uploadStatus.textContent = `Subiendo ${uploadedCount} de ${totalFiles} archivos...`;
                
                if (uploadedCount === totalFiles) {
                    setTimeout(() => {
                        showNotification(`${totalFiles} archivos subidos correctamente`, 'success');
                        closeModal();
                        loadMedia();
                    }, 500);
                }
            }).catch(error => {
                showNotification(`Error al subir ${file.name}: ${error}`, 'error');
            });
        }, index * 500); // Pequeño retraso entre archivos para simular proceso
    });
}

// Simular subida de archivo
function uploadFile(file) {
    return new Promise((resolve, reject) => {
        // En un entorno real, aquí se enviaría el archivo al servidor
        // Por ahora, simulamos la subida
        
        setTimeout(() => {
            const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
            const newId = Math.max(...data.media.map(m => m.id)) + 1;
            
            const newMedia = {
                id: newId,
                name: file.name,
                url: URL.createObjectURL(file),
                type: file.type.split('/')[0],
                size: formatFileSize(file.size),
                uploadedAt: new Date().toISOString().split('T')[0],
                uploadedBy: "Admin User"
            };
            
            data.media.unshift(newMedia);
            localStorage.setItem('guineaGlobalData', JSON.stringify(data));
            
            resolve(newMedia);
        }, 1000);
    });
}

// Formatear tamaño de archivo
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Vista previa de medio
function previewMedia(id) {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const media = data.media.find(m => m.id === id);
    
    if (media) {
        selectedMedia = media;
        document.getElementById('previewTitle').textContent = media.name;
        
        if (media.type === 'image') {
            document.getElementById('previewImage').src = media.url;
            document.getElementById('previewImage').style.display = 'block';
        } else {
            document.getElementById('previewImage').style.display = 'none';
        }
        
        document.getElementById('previewInfo').innerHTML = `
            <p><strong>Nombre:</strong> ${media.name}</p>
            <p><strong>Tipo:</strong> ${media.type}</p>
            <p><strong>Tamaño:</strong> ${media.size}</p>
            <p><strong>Subido:</strong> ${formatDate(media.uploadedAt)}</p>
            <p><strong>Subido por:</strong> ${media.uploadedBy}</p>
        `;
        
        openModal('previewModal');
    }
}

// Usar medio seleccionado
function useSelectedMedia() {
    if (selectedMedia) {
        // En un entorno real, aquí se devolvería el medio seleccionado al editor
        showNotification(`Archivo "${selectedMedia.name}" seleccionado`, 'success');
        closeModal();
    }
}

// Eliminar medio
function deleteMedia(id) {
    if (confirm('¿Estás seguro de que quieres eliminar este archivo?')) {
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        data.media = data.media.filter(media => media.id !== id);
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Archivo eliminado correctamente', 'success');
        loadMedia();
    }
}

// Abrir modal de subida
function openUploadModal() {
    document.getElementById('uploadArea').style.display = 'flex';
    document.getElementById('uploadProgress').style.display = 'none';
    document.getElementById('fileInput').value = '';
    document.getElementById('progressFill').style.width = '0%';
    document.getElementById('uploadStatus').textContent = '';
    
    openModal('uploadModal');
}

// Inicializar página cuando se carga
if (document.getElementById('mediaGrid')) {
    initPage();
}

// Estilos para la barra de progreso
const progressStyle = document.createElement('style');
progressStyle.textContent = `
    .progress-bar {
        width: 100%;
        height: 20px;
        background-color: #f0f0f0;
        border-radius: 10px;
        overflow: hidden;
        margin: 10px 0;
    }
    
    .progress-fill {
        height: 100%;
        background-color: #3498db;
        transition: width 0.3s ease;
        width: 0%;
    }
`;
document.head.appendChild(progressStyle);