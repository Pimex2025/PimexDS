// Inicialización de la página de usuarios
function initPage() {
    loadUsers();
}

// Cargar usuarios
function loadUsers() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const usersList = document.getElementById('usersList');
    usersList.innerHTML = '';
    
    data.users.forEach(user => {
        const userCard = document.createElement('div');
        userCard.className = 'user-card';
        userCard.innerHTML = `
            <div class="user-avatar">
                <img src="${user.avatar}" alt="${user.name}">
            </div>
            <div class="user-details">
                <div class="user-name">${user.name}</div>
                <div class="user-role">${user.role}</div>
                <div class="user-email">${user.email}</div>
                <div class="user-meta">
                    <span class="user-status ${user.status}">${user.status === 'active' ? 'Activo' : 'Inactivo'}</span>
                    <span class="user-joined">Miembro desde ${formatDate(user.createdAt)}</span>
                </div>
            </div>
            <div class="user-actions">
                <button class="btn btn-sm btn-edit" onclick="editUser(${user.id})">
                    <i class="fas fa-edit"></i>
                </button>
                ${user.id !== 1 ? `
                    <button class="btn btn-sm btn-delete" onclick="deleteUser(${user.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                ` : ''}
            </div>
        `;
        usersList.appendChild(userCard);
    });
}

// Crear nuevo usuario
function newUser() {
    document.getElementById('userModalTitle').textContent = 'Nuevo Usuario';
    document.getElementById('userForm').reset();
    document.getElementById('userId').value = '';
    document.getElementById('userPassword').required = true;
    document.getElementById('avatarPreview').innerHTML = '';
    document.getElementById('userStatusActive').checked = true;
    openModal('newUserModal');
}

// Editar usuario
function editUser(id) {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const user = data.users.find(u => u.id === id);
    
    if (user) {
        document.getElementById('userModalTitle').textContent = 'Editar Usuario';
        document.getElementById('userId').value = user.id;
        document.getElementById('userName').value = user.name;
        document.getElementById('userEmail').value = user.email;
        document.getElementById('userRole').value = user.role;
        document.getElementById('userPassword').required = false;
        
        if (user.status === 'active') {
            document.getElementById('userStatusActive').checked = true;
        } else {
            document.getElementById('userStatusInactive').checked = true;
        }
        
        // Mostrar previsualización de avatar si existe
        if (user.avatar) {
            document.getElementById('avatarPreview').innerHTML = `
                <img src="${user.avatar}" alt="Previsualización" style="width: 80px; height: 80px; border-radius: 50%; margin-top: 10px;">
            `;
        }
        
        openModal('newUserModal');
    }
}

// Guardar usuario
document.getElementById('userForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const userId = document.getElementById('userId').value;
    const name = document.getElementById('userName').value;
    const email = document.getElementById('userEmail').value;
    const role = document.getElementById('userRole').value;
    const password = document.getElementById('userPassword').value;
    const status = document.querySelector('input[name="userStatus"]:checked').value;
    
    if (userId) {
        // Editar usuario existente
        const index = data.users.findIndex(u => u.id === parseInt(userId));
        if (index !== -1) {
            data.users[index].name = name;
            data.users[index].email = email;
            data.users[index].role = role;
            data.users[index].status = status;
            
            // Actualizar avatar si se subió uno nuevo
            const avatarFile = document.getElementById('userAvatar').files[0];
            if (avatarFile) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    data.users[index].avatar = e.target.result;
                    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
                    showNotification('Usuario actualizado correctamente', 'success');
                    closeModal();
                    loadUsers();
                };
                reader.readAsDataURL(avatarFile);
                return;
            }
        }
    } else {
        // Crear nuevo usuario
        if (!password) {
            showNotification('La contraseña es obligatoria para nuevos usuarios', 'error');
            return;
        }
        
        const newId = Math.max(...data.users.map(u => u.id)) + 1;
        const avatarFile = document.getElementById('userAvatar').files[0];
        let avatarUrl = 'images/user-default.jpg';
        
        if (avatarFile) {
            const reader = new FileReader();
            reader.onload = function(e) {
                avatarUrl = e.target.result;
                createUser(data, newId, name, email, role, password, status, avatarUrl);
            };
            reader.readAsDataURL(avatarFile);
            return;
        } else {
            createUser(data, newId, name, email, role, password, status, avatarUrl);
            return;
        }
    }
    
    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
    showNotification('Usuario guardado correctamente', 'success');
    closeModal();
    loadUsers();
});

// Función auxiliar para crear usuario
function createUser(data, id, name, email, role, password, status, avatar) {
    const newUser = {
        id: id,
        name: name,
        email: email,
        role: role,
        avatar: avatar,
        status: status,
        createdAt: new Date().toISOString().split('T')[0]
    };
    data.users.push(newUser);
    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
    showNotification('Usuario creado correctamente', 'success');
    closeModal();
    loadUsers();
}

// Eliminar usuario
function deleteUser(id) {
    if (id === 1) {
        showNotification('No se puede eliminar el usuario administrador principal', 'error');
        return;
    }
    
    if (confirm('¿Estás seguro de que quieres eliminar este usuario?')) {
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        data.users = data.users.filter(user => user.id !== id);
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Usuario eliminado correctamente', 'success');
        loadUsers();
    }
}

// Manejar subida de avatar
document.getElementById('userAvatar').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('avatarPreview').innerHTML = `
                <img src="${e.target.result}" alt="Previsualización" style="width: 80px; height: 80px; border-radius: 50%; margin-top: 10px;">
            `;
        };
        reader.readAsDataURL(file);
    }
});

// Inicializar página cuando se carga
if (document.getElementById('usersList')) {
    initPage();
}

// Estilos adicionales para usuarios
const userStyles = document.createElement('style');
userStyles.textContent = `
    .user-status {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 500;
    }
    
    .user-status.active {
        background-color: #d4edda;
        color: #155724;
    }
    
    .user-status.inactive {
        background-color: #f8d7da;
        color: #721c24;
    }
    
    .user-meta {
        display: flex;
        gap: 15px;
        margin-top: 5px;
        font-size: 12px;
        color: #95a5a6;
    }
    
    .user-joined {
        font-style: italic;
    }
`;
document.head.appendChild(userStyles);