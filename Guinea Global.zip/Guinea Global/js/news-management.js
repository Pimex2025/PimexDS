// Variables para paginación
let currentPage = 1;
const itemsPerPage = 10;
let filteredNews = [];

// Inicialización de la página de noticias
function initPage() {
    loadNews();
    setupFilters();
    setupPagination();
    setupEditor();
}

// Cargar noticias
function loadNews() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    filteredNews = data.news;
    displayNews();
}

// Mostrar noticias en la tabla
function displayNews() {
    const tableBody = document.getElementById('newsTableBody');
    tableBody.innerHTML = '';
    
    // Aplicar paginación
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const newsToDisplay = filteredNews.slice(startIndex, endIndex);
    
    if (newsToDisplay.length === 0) {
        tableBody.innerHTML = `
            <div class="table-row">
                <div class="col-empty" colspan="7">No se encontraron noticias</div>
            </div>
        `;
        return;
    }
    
    newsToDisplay.forEach(news => {
        const row = document.createElement('div');
        row.className = 'table-row';
        row.innerHTML = `
            <div class="col-title">
                <h4>${news.title}</h4>
                <p class="news-excerpt">${news.excerpt}</p>
            </div>
            <div class="col-category">
                <span class="category-badge ${news.category.toLowerCase()}">${news.category}</span>
            </div>
            <div class="col-author">${news.author}</div>
            <div class="col-date">${formatDate(news.createdAt)}</div>
            <div class="col-views">${news.views}</div>
            <div class="col-status">
                <span class="status-badge ${news.status}">
                    ${getStatusText(news.status)}
                </span>
            </div>
            <div class="col-actions">
                <button class="btn btn-sm btn-edit" onclick="editNews(${news.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-delete" onclick="deleteNews(${news.id})">
                    <i class="fas fa-trash"></i>
                </button>
                ${news.status !== 'published' ? `
                    <button class="btn btn-sm btn-publish" onclick="publishNews(${news.id})">
                        <i class="fas fa-check"></i>
                    </button>
                ` : ''}
            </div>
        `;
        tableBody.appendChild(row);
    });
    
    updatePaginationInfo();
}

// Configurar filtros
function setupFilters() {
    const categoryFilter = document.getElementById('categoryFilter');
    const statusFilter = document.getElementById('statusFilter');
    const dateFilter = document.getElementById('dateFilter');
    const searchFilter = document.getElementById('searchFilter');
    
    [categoryFilter, statusFilter, dateFilter, searchFilter].forEach(filter => {
        filter.addEventListener('change', applyFilters);
        filter.addEventListener('input', applyFilters);
    });
}

// Aplicar filtros
function applyFilters() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    let filtered = data.news;
    
    const category = document.getElementById('categoryFilter').value;
    const status = document.getElementById('statusFilter').value;
    const date = document.getElementById('dateFilter').value;
    const search = document.getElementById('searchFilter').value.toLowerCase();
    
    if (category) {
        filtered = filtered.filter(news => news.category === category);
    }
    
    if (status) {
        filtered = filtered.filter(news => news.status === status);
    }
    
    if (date) {
        filtered = filtered.filter(news => news.createdAt === date);
    }
    
    if (search) {
        filtered = filtered.filter(news => 
            news.title.toLowerCase().includes(search) || 
            news.excerpt.toLowerCase().includes(search)
        );
    }
    
    filteredNews = filtered;
    currentPage = 1;
    displayNews();
}

// Configurar paginación
function setupPagination() {
    document.getElementById('prevPage').addEventListener('click', goToPrevPage);
    document.getElementById('nextPage').addEventListener('click', goToNextPage);
}

function goToPrevPage() {
    if (currentPage > 1) {
        currentPage--;
        displayNews();
    }
}

function goToNextPage() {
    const totalPages = Math.ceil(filteredNews.length / itemsPerPage);
    if (currentPage < totalPages) {
        currentPage++;
        displayNews();
    }
}

function updatePaginationInfo() {
    const totalPages = Math.ceil(filteredNews.length / itemsPerPage);
    document.getElementById('pageInfo').textContent = `Página ${currentPage} de ${totalPages}`;
    
    document.getElementById('prevPage').disabled = currentPage === 1;
    document.getElementById('nextPage').disabled = currentPage === totalPages || totalPages === 0;
}

// Configurar editor de texto enriquecido
function setupEditor() {
    const editor = document.getElementById('newsContent');
    const toolbar = document.querySelector('.editor-toolbar');
    
    toolbar.addEventListener('click', function(e) {
        if (e.target.matches('button') || e.target.closest('button')) {
            e.preventDefault();
            const button = e.target.matches('button') ? e.target : e.target.closest('button');
            const command = button.getAttribute('data-command');
            
            if (command === 'createLink') {
                const url = prompt('Introduce la URL:');
                if (url) {
                    document.execCommand('createLink', false, url);
                }
            } else if (command === 'insertImage') {
                const url = prompt('Introduce la URL de la imagen:');
                if (url) {
                    document.execCommand('insertImage', false, url);
                }
            } else {
                document.execCommand(command, false, null);
            }
            
            editor.focus();
        }
    });
}

// Obtener texto del estado
function getStatusText(status) {
    const statusMap = {
        'published': 'Publicado',
        'pending': 'Pendiente',
        'draft': 'Borrador'
    };
    return statusMap[status] || status;
}

// Crear nueva noticia
function newNews() {
    document.getElementById('newsModalTitle').textContent = 'Nueva Noticia';
    document.getElementById('newsForm').reset();
    document.getElementById('newsId').value = '';
    document.getElementById('newsContent').innerHTML = '';
    document.getElementById('imagePreview').innerHTML = '';
    openModal('newNewsModal');
}

// Editar noticia
function editNews(id) {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const news = data.news.find(n => n.id === id);
    
    if (news) {
        document.getElementById('newsModalTitle').textContent = 'Editar Noticia';
        document.getElementById('newsId').value = news.id;
        document.getElementById('newsTitle').value = news.title;
        document.getElementById('newsExcerpt').value = news.excerpt;
        document.getElementById('newsContent').innerHTML = news.content;
        document.getElementById('newsCategory').value = news.category;
        document.getElementById('newsStatus').value = news.status;
        
        // Mostrar previsualización de imagen si existe
        if (news.featuredImage) {
            document.getElementById('imagePreview').innerHTML = `
                <img src="${news.featuredImage}" alt="Previsualización" style="max-width: 200px; margin-top: 10px;">
            `;
        }
        
        openModal('newNewsModal');
    }
}

// Guardar noticia
document.getElementById('newsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const newsId = document.getElementById('newsId').value;
    const title = document.getElementById('newsTitle').value;
    const excerpt = document.getElementById('newsExcerpt').value;
    const content = document.getElementById('newsContent').innerHTML;
    const category = document.getElementById('newsCategory').value;
    const status = document.getElementById('newsStatus').value;
    
    if (newsId) {
        // Editar noticia existente
        const index = data.news.findIndex(n => n.id === parseInt(newsId));
        if (index !== -1) {
            data.news[index].title = title;
            data.news[index].excerpt = excerpt;
            data.news[index].content = content;
            data.news[index].category = category;
            data.news[index].status = status;
            data.news[index].updatedAt = new Date().toISOString().split('T')[0];
        }
    } else {
        // Crear nueva noticia
        const newId = Math.max(...data.news.map(n => n.id)) + 1;
        const newNews = {
            id: newId,
            title: title,
            excerpt: excerpt,
            content: content,
            category: category,
            author: "Admin User",
            status: status,
            featuredImage: "images/news-placeholder.jpg",
            createdAt: new Date().toISOString().split('T')[0],
            updatedAt: new Date().toISOString().split('T')[0],
            views: 0,
            comments: 0
        };
        data.news.unshift(newNews);
    }
    
    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
    showNotification('Noticia guardada correctamente', 'success');
    closeModal();
    loadNews();
});

// Eliminar noticia
function deleteNews(id) {
    if (confirm('¿Estás seguro de que quieres eliminar esta noticia?')) {
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        data.news = data.news.filter(news => news.id !== id);
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Noticia eliminada correctamente', 'success');
        loadNews();
    }
}

// Publicar noticia
function publishNews(id) {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const newsIndex = data.news.findIndex(news => news.id === id);
    
    if (newsIndex !== -1) {
        data.news[newsIndex].status = 'published';
        data.news[newsIndex].updatedAt = new Date().toISOString().split('T')[0];
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Noticia publicada correctamente', 'success');
        loadNews();
    }
}

// Manejar subida de imagen
document.getElementById('newsImage').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('imagePreview').innerHTML = `
                <img src="${e.target.result}" alt="Previsualización" style="max-width: 200px; margin-top: 10px;">
            `;
        };
        reader.readAsDataURL(file);
    }
});

// Inicializar página cuando se carga
if (document.getElementById('newsTableBody')) {
    initPage();
}

// Manejar parámetros de URL para edición
window.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const editId = urlParams.get('edit');
    
    if (editId) {
        editNews(parseInt(editId));
    }
});