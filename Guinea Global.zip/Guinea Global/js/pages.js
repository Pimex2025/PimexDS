// js/pages.js

// Funcionalidad específica para páginas adicionales

document.addEventListener('DOMContentLoaded', function() {
    // Actualizar fecha actual
    function updateCurrentDate() {
        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = now.toLocaleDateString('es-ES', options);
        const dateElements = document.querySelectorAll('#current-date');
        
        dateElements.forEach(element => {
            element.textContent = formattedDate;
        });
    }
    
    updateCurrentDate();
    
    // Filtrado de deportes por categoría
    const sportCategories = document.querySelectorAll('.sport-category');
    const matchCards = document.querySelectorAll('.match-card');
    
    if (sportCategories.length > 0) {
        sportCategories.forEach(category => {
            category.addEventListener('click', function() {
                // Remover clase activa de todas las categorías
                sportCategories.forEach(cat => cat.classList.remove('active'));
                
                // Agregar clase activa a la categoría clickeada
                this.classList.add('active');
                
                const selectedSport = this.dataset.sport;
                
                // Mostrar/ocultar tarjetas de partidos según la categoría
                matchCards.forEach(card => {
                    if (selectedSport === 'all' || card.dataset.sport === selectedSport) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }
    
    // Filtrado de política por categoría
    const politicsCategories = document.querySelectorAll('.politics-category');
    const politicianCards = document.querySelectorAll('.politician-card');
    
    if (politicsCategories.length > 0) {
        politicsCategories.forEach(category => {
            category.addEventListener('click', function() {
                // Remover clase activa de todas las categorías
                politicsCategories.forEach(cat => cat.classList.remove('active'));
                
                // Agregar clase activa a la categoría clickeada
                this.classList.add('active');
                
                const selectedCategory = this.dataset.category;
                
                // Mostrar/ocultar tarjetas de políticos según la categoría
                politicianCards.forEach(card => {
                    if (selectedCategory === 'all' || card.dataset.category === selectedCategory) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }
    
    // Simulación de datos meteorológicos para la página del tiempo
    function initializeWeatherWidget() {
        const weatherWidget = document.querySelector('.weather-widget-large');
        
        if (weatherWidget) {
            // En una implementación real, estos datos vendrían de una API
            const weatherData = {
                location: 'Malabo',
                temperature: 28,
                condition: 'Parcialmente nublado',
                humidity: 78,
                wind: 12,
                pressure: 1012,
                forecast: [
                    { day: 'Hoy', condition: 'Parcialmente nublado', high: 29, low: 24 },
                    { day: 'Mañana', condition: 'Lluvia ligera', high: 27, low: 23 },
                    { day: 'Viernes', condition: 'Tormenta', high: 26, low: 22 },
                    { day: 'Sábado', condition: 'Lluvia', high: 27, low: 23 },
                    { day: 'Domingo', condition: 'Nublado', high: 28, low: 24 }
                ]
            };
            
            // Actualizar widget con datos simulados
            document.querySelector('.weather-temp').textContent = `${weatherData.temperature}°C`;
            document.querySelector('.weather-info h2').textContent = `${weatherData.location}, ${weatherData.condition}`;
            document.querySelector('.humidity-value').textContent = `${weatherData.humidity}%`;
            document.querySelector('.wind-value').textContent = `${weatherData.wind} km/h`;
            document.querySelector('.pressure-value').textContent = `${weatherData.pressure} hPa`;
            
            // Actualizar pronóstico
            const forecastContainer = document.querySelector('.weather-forecast');
            if (forecastContainer) {
                forecastContainer.innerHTML = '';
                
                weatherData.forecast.forEach(day => {
                    const forecastDay = document.createElement('div');
                    forecastDay.className = 'forecast-day';
                    
                    // Determinar icono según condición
                    let iconClass = 'fa-sun';
                    if (day.condition.includes('Lluvia')) iconClass = 'fa-cloud-rain';
                    if (day.condition.includes('Tormenta')) iconClass = 'fa-bolt';
                    if (day.condition.includes('Nublado')) iconClass = 'fa-cloud';
                    
                    forecastDay.innerHTML = `
                        <h4>${day.day}</h4>
                        <div class="forecast-icon">
                            <i class="fas ${iconClass}"></i>
                        </div>
                        <div class="forecast-temp">${day.high}° / ${day.low}°</div>
                    `;
                    
                    forecastContainer.appendChild(forecastDay);
                });
            }
            
            // Generar recomendaciones basadas en el clima
            const recommendationsContainer = document.querySelector('.weather-recommendations');
            if (recommendationsContainer) {
                let recommendations = [];
                
                if (weatherData.condition.includes('Lluvia') || weatherData.condition.includes('Tormenta')) {
                    recommendations = [
                        { icon: 'fa-umbrella', text: 'Lleve un paraguas o impermeable' },
                        { icon: 'fa-car', text: 'Conduzca con precaución en carreteras mojadas' },
                        { icon: 'fa-home', text: 'Revise que no haya fugas en su vivienda' }
                    ];
                } else if (weatherData.temperature > 30) {
                    recommendations = [
                        { icon: 'fa-tint', text: 'Manténgase hidratado durante el día' },
                        { icon: 'fa-sun', text: 'Use protector solar si va a estar al aire libre' },
                        { icon: 'fa-tshirt', text: 'Use ropa ligera y de colores claros' }
                    ];
                } else {
                    recommendations = [
                        { icon: 'fa-walking', text: 'Excelente día para actividades al aire libre' },
                        { icon: 'fa-tree', text: 'Ideal para visitar parques y áreas naturales' },
                        { icon: 'fa-bicycle', text: 'Buen momento para practicar deportes' }
                    ];
                }
                
                const recommendationsList = recommendationsContainer.querySelector('.recommendations-list');
                if (recommendationsList) {
                    recommendationsList.innerHTML = '';
                    
                    recommendations.forEach(rec => {
                        const recItem = document.createElement('div');
                        recItem.className = 'recommendation-item';
                        recItem.innerHTML = `
                            <i class="fas ${rec.icon}"></i>
                            <p>${rec.text}</p>
                        `;
                        
                        recommendationsList.appendChild(recItem);
                    });
                }
            }
        }
    }
    
    initializeWeatherWidget();
    
    // Manejo del formulario de contacto
    const contactForm = document.getElementById('contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // En una implementación real, aquí se enviarían los datos al servidor
            const formData = new FormData(this);
            const name = formData.get('name');
            const email = formData.get('email');
            const subject = formData.get('subject');
            const message = formData.get('message');
            
            // Simulación de envío exitoso
            alert(`Gracias ${name}, su mensaje ha sido enviado correctamente. Nos pondremos en contacto con usted pronto.`);
            this.reset();
        });
    }
    
    // Funcionalidad del panel de administración
    const adminLoginForm = document.getElementById('admin-login-form');
    
    if (adminLoginForm) {
        adminLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('admin-username').value;
            const password = document.getElementById('admin-password').value;
            
            // Credenciales de prueba
            if (username === 'admin' && password === 'guinea2023') {
                // Redirigir al dashboard (en una implementación real)
                window.location.href = 'admin-dashboard.html';
            } else {
                alert('Credenciales incorrectas. Por favor, intente nuevamente.');
            }
        });
    }
    
    // Funcionalidad para subir noticias en el panel de administración
    const newsForm = document.getElementById('news-form');
    
    if (newsForm) {
        newsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // En una implementación real, aquí se enviarían los datos al servidor
            const formData = new FormData(this);
            const title = formData.get('title');
            const category = formData.get('category');
            
            alert(`Noticia "${title}" creada exitosamente en la categoría ${category}.`);
            this.reset();
        });
    }
    
    // Navegación suave para enlaces internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
});
// Additional JavaScript for new pages

// Dashboard functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard if we're on the dashboard page
    const dashboard = document.querySelector('.dashboard');
    
    if (dashboard) {
        initializeDashboard();
    }
    
    // Initialize weather page if we're on the weather page
    const weatherPage = document.querySelector('.weather-widget-large');
    
    if (weatherPage) {
        initializeWeatherPage();
    }
    
    // Initialize contact form if exists
    const contactForm = document.getElementById('contact-form');
    
    if (contactForm) {
        initializeContactForm();
    }
    
    // Initialize news form if exists (dashboard)
    const newsForm = document.getElementById('news-form');
    
    if (newsForm) {
        initializeNewsForm();
    }
});

// Dashboard functions
function initializeDashboard() {
    // Toggle sidebar on mobile
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const dashboardSidebar = document.querySelector('.dashboard-sidebar');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            dashboardSidebar.classList.toggle('collapsed');
        });
    }
    
    // Update stats (in a real app, this would come from an API)
    updateDashboardStats();
    
    // Initialize chart if Chart.js is available
    initializeDashboardChart();
}

function updateDashboardStats() {
    // In a real application, these values would come from an API
    const stats = {
        totalNews: 1247,
        publishedNews: 1120,
        pendingNews: 127,
        subscribers: 8452
    };
    
    document.querySelector('.stat-total-news .stat-number').textContent = stats.totalNews;
    document.querySelector('.stat-published .stat-number').textContent = stats.publishedNews;
    document.querySelector('.stat-pending .stat-number').textContent = stats.pendingNews;
    document.querySelector('.stat-subscribers .stat-number').textContent = stats.subscribers;
}

function initializeDashboardChart() {
    // This would initialize a chart using Chart.js or similar library
    // For now, we'll just log that we would initialize a chart here
    console.log('Initializing dashboard chart...');
}

// Weather page functions
function initializeWeatherPage() {
    // Update weather data periodically
    updateWeatherData();
    
    // Set up auto-refresh every 10 minutes
    setInterval(updateWeatherData, 600000);
    
    // Initialize city selector if exists
    const citySelector = document.getElementById('city-selector');
    
    if (citySelector) {
        citySelector.addEventListener('change', function() {
            updateWeatherForCity(this.value);
        });
    }
}

function updateWeatherData() {
    // In a real application, this would fetch data from a weather API
    console.log('Updating weather data...');
    
    // Simulate API call delay
    setTimeout(() => {
        // Update current weather
        const currentTemp = document.querySelector('.weather-temp');
        if (currentTemp) {
            // Simulate small temperature change
            const currentTempValue = parseInt(currentTemp.textContent);
            const newTemp = currentTempValue + Math.floor(Math.random() * 3) - 1;
            currentTemp.textContent = `${newTemp}°C`;
        }
        
        // Update forecast
        const forecastDays = document.querySelectorAll('.forecast-day');
        forecastDays.forEach(day => {
            const tempElement = day.querySelector('.forecast-temp');
            if (tempElement) {
                const temps = tempElement.textContent.split(' / ');
                const high = parseInt(temps[0]) + Math.floor(Math.random() * 2) - 1;
                const low = parseInt(temps[1]) + Math.floor(Math.random() * 2) - 1;
                tempElement.textContent = `${high}° / ${low}°`;
            }
        });
    }, 1000);
}

function updateWeatherForCity(city) {
    // In a real application, this would fetch data for the selected city
    console.log(`Updating weather for city: ${city}`);
    
    // Simulate API call
    setTimeout(() => {
        alert(`Mostrando información meteorológica para ${city}`);
    }, 500);
}

// Contact form functions
function initializeContactForm() {
    const contactForm = document.getElementById('contact-form');
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const name = formData.get('name');
        const email = formData.get('email');
        const subject = formData.get('subject');
        const message = formData.get('message');
        
        // Basic validation
        if (!name || !email || !subject || !message) {
            alert('Por favor, complete todos los campos obligatorios.');
            return;
        }
        
        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Por favor, ingrese una dirección de correo electrónico válida.');
            return;
        }
        
        // Simulate form submission
        simulateFormSubmission(name, email, subject, message);
    });
}

function simulateFormSubmission(name, email, subject, message) {
    // Show loading state
    const submitBtn = document.querySelector('.submit-btn');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Enviando...';
    submitBtn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // Show success message
        alert(`Gracias ${name}, su mensaje ha sido enviado correctamente. Nos pondremos en contacto con usted pronto.`);
        
        // Reset form
        document.getElementById('contact-form').reset();
        
        // Reset button
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }, 2000);
}

// News form functions (for dashboard)
function initializeNewsForm() {
    const newsForm = document.getElementById('news-form');
    const titleInput = document.getElementById('news-title');
    const contentInput = document.getElementById('news-content');
    const previewTitle = document.getElementById('preview-title');
    const previewContent = document.getElementById('preview-content');
    const previewImage = document.getElementById('preview-image');
    
    // Update preview when title changes
    if (titleInput && previewTitle) {
        titleInput.addEventListener('input', function() {
            previewTitle.textContent = this.value || 'Título de la noticia';
        });
    }
    
    // Update preview when content changes
    if (contentInput && previewContent) {
        contentInput.addEventListener('input', function() {
            previewContent.textContent = this.value || 'Contenido de la noticia...';
        });
    }
    
    // Handle image upload preview
    const imageInput = document.getElementById('news-image');
    if (imageInput && previewImage) {
        imageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Handle form submission
    if (newsForm) {
        newsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const title = formData.get('title');
            const category = formData.get('category');
            const content = formData.get('content');
            
            // Basic validation
            if (!title || !category || !content) {
                alert('Por favor, complete todos los campos obligatorios.');
                return;
            }
            
            // Simulate news creation
            simulateNewsCreation(title, category, content);
        });
    }
}

function simulateNewsCreation(title, category, content) {
    // Show loading state
    const publishBtn = document.querySelector('.btn-publish');
    const originalText = publishBtn.textContent;
    publishBtn.textContent = 'Publicando...';
    publishBtn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // Show success message
        alert(`Noticia "${title}" creada exitosamente en la categoría ${category}.`);
        
        // Reset form
        document.getElementById('news-form').reset();
        
        // Reset preview
        document.getElementById('preview-title').textContent = 'Título de la noticia';
        document.getElementById('preview-content').textContent = 'Contenido de la noticia...';
        document.getElementById('preview-image').src = 'images/default-news.jpg';
        
        // Reset button
        publishBtn.textContent = originalText;
        publishBtn.disabled = false;
        
        // In a real app, we would update the news list here
        updateNewsList(title, category);
    }, 2000);
}

function updateNewsList(title, category) {
    // In a real application, this would update the news list with the new item
    console.log(`Adding news to list: ${title} (${category})`);
    
    // For demo purposes, we'll just show an alert
    alert(`La noticia "${title}" ha sido añadida a la lista de noticias.`);
}

// Politics page filtering
function initializePoliticsFilter() {
    const politicsCategories = document.querySelectorAll('.politics-category');
    const politicianCards = document.querySelectorAll('.politician-card');
    
    if (politicsCategories.length > 0) {
        politicsCategories.forEach(category => {
            category.addEventListener('click', function() {
                // Remove active class from all categories
                politicsCategories.forEach(cat => cat.classList.remove('active'));
                
                // Add active class to clicked category
                this.classList.add('active');
                
                const selectedCategory = this.dataset.category;
                
                // Show/hide politician cards based on category
                politicianCards.forEach(card => {
                    if (selectedCategory === 'all' || card.dataset.category === selectedCategory) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }
}

// Initialize politics filter if on politics page
const politicsPage = document.querySelector('.politics-categories');
if (politicsPage) {
    initializePoliticsFilter();
}
