// js/weather.js

// Datos meteorológicos simulados para Guinea Ecuatorial
class WeatherData {
    constructor() {
        this.cities = [
            { name: 'Malabo', temp: 28, condition: 'Parcialmente nublado', humidity: 78, wind: 12, pressure: 1012, feelsLike: 30, visibility: 10 },
            { name: 'Bata', temp: 30, condition: 'Soleado', humidity: 75, wind: 10, pressure: 1010, feelsLike: 32, visibility: 12 },
            { name: 'Ebebiyín', temp: 29, condition: 'Parcialmente nublado', humidity: 80, wind: 8, pressure: 1011, feelsLike: 31, visibility: 11 },
            { name: 'Mongomo', temp: 28, condition: 'Lluvia ligera', humidity: 85, wind: 12, pressure: 1013, feelsLike: 29, visibility: 8 },
            { name: 'Luba', temp: 27, condition: 'Nublado', humidity: 82, wind: 15, pressure: 1014, feelsLike: 28, visibility: 9 }
        ];
        
        this.weatherConditions = [
            { condition: 'Soleado', icon: 'fa-sun', description: 'Cielo despejado' },
            { condition: 'Parcialmente nublado', icon: 'fa-cloud-sun', description: 'Nubes y claros' },
            { condition: 'Nublado', icon: 'fa-cloud', description: 'Cielo cubierto' },
            { condition: 'Lluvia ligera', icon: 'fa-cloud-rain', description: 'Precipitaciones débiles' },
            { condition: 'Lluvia intensa', icon: 'fa-cloud-showers-heavy', description: 'Fuertes precipitaciones' },
            { condition: 'Tormenta', icon: 'fa-bolt', description: 'Tormentas eléctricas' },
            { condition: 'Niebla', icon: 'fa-smog', description: 'Visibilidad reducida' }
        ];
        
        this.alerts = [
            { type: 'warning', title: 'Alerta por lluvias intensas', description: 'Se prevén precipitaciones de hasta 50mm en 24 horas', areas: 'Región continental', validUntil: '7 de septiembre, 18:00' },
            { type: 'info', title: 'Aviso por vientos fuertes', description: 'Ráfagas de viento de hasta 40 km/h', areas: 'Zonas costeras', validUntil: '6 de septiembre, 20:00' }
        ];
        
        this.initializeWeather();
    }
    
    initializeWeather() {
        // Generar datos iniciales o recuperar del localStorage
        const storedData = localStorage.getItem('guineaGlobalWeather');
        const today = new Date().toDateString();
        
        if (storedData) {
            const data = JSON.parse(storedData);
            if (data.date === today) {
                this.weatherData = data;
                return;
            }
        }
        
        // Generar nuevos datos para hoy
        this.generateDailyWeather();
    }
    
    generateDailyWeather() {
        const today = new Date();
        const weatherData = {
            date: today.toDateString(),
            lastUpdate: today.toISOString(),
            cities: {},
            forecasts: {},
            hourly: {}
        };
        
        // Generar datos para cada ciudad
        this.cities.forEach(city => {
            const baseTemp = city.temp;
            const baseHumidity = city.humidity;
            
            // Datos actuales con variación ligera
            weatherData.cities[city.name] = {
                ...city,
                temp: this.getRandomVariation(baseTemp, 2),
                humidity: this.getRandomVariation(baseHumidity, 5),
                wind: this.getRandomVariation(city.wind, 3),
                pressure: this.getRandomVariation(city.pressure, 2),
                feelsLike: this.getRandomVariation(city.feelsLike, 2),
                condition: this.getRandomCondition(),
                lastUpdate: today.toISOString()
            };
            
            // Pronóstico para 5 días
            weatherData.forecasts[city.name] = this.generateForecast(city, 5);
            
            // Pronóstico por horas (24 horas)
            weatherData.hourly[city.name] = this.generateHourlyForecast(city, 24);
        });
        
        this.weatherData = weatherData;
        localStorage.setItem('guineaGlobalWeather', JSON.stringify(weatherData));
    }
    
    getRandomVariation(base, range) {
        return base + (Math.random() * range * 2 - range);
    }
    
    getRandomCondition() {
        const randomIndex = Math.floor(Math.random() * this.weatherConditions.length);
        return this.weatherConditions[randomIndex];
    }
    
    generateForecast(city, days) {
        const forecast = [];
        const today = new Date();
        
        for (let i = 0; i < days; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() + i);
            
            const condition = this.getRandomCondition();
            const high = city.temp + Math.random() * 3;
            const low = city.temp - Math.random() * 4;
            
            forecast.push({
                date: date.toDateString(),
                day: date.toLocaleDateString('es-ES', { weekday: 'long' }),
                condition: condition.condition,
                icon: condition.icon,
                high: Math.round(high),
                low: Math.round(low),
                precipitation: Math.floor(Math.random() * 30)
            });
        }
        
        return forecast;
    }
    
    generateHourlyForecast(city, hours) {
        const forecast = [];
        const now = new Date();
        
        for (let i = 0; i < hours; i++) {
            const hour = new Date(now);
            hour.setHours(now.getHours() + i);
            
            // Temperatura varía según la hora del día
            const hourOfDay = hour.getHours();
            let tempVariation = 0;
            
            if (hourOfDay >= 22 || hourOfDay <= 6) {
                // Noche - más fresco
                tempVariation = -2 - Math.random() * 2;
            } else if (hourOfDay >= 12 && hourOfDay <= 16) {
                // Mediodía - más cálido
                tempVariation = 2 + Math.random() * 2;
            }
            
            const condition = this.getRandomCondition();
            
            forecast.push({
                time: hour.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
                temp: Math.round(city.temp + tempVariation),
                condition: condition.condition,
                icon: condition.icon,
                precipitation: Math.floor(Math.random() * 20)
            });
        }
        
        return forecast;
    }
    
    getCurrentWeather(cityName = 'Malabo') {
        return this.weatherData.cities[cityName];
    }
    
    getForecast(cityName = 'Malabo') {
        return this.weatherData.forecasts[cityName];
    }
    
    getHourlyForecast(cityName = 'Malabo') {
        return this.weatherData.hourly[cityName];
    }
    
    getAllCitiesWeather() {
        return this.weatherData.cities;
    }
    
    getAlerts() {
        return this.alerts;
    }
    
    getConditionIcon(condition) {
        const found = this.weatherConditions.find(c => c.condition === condition);
        return found ? found.icon : 'fa-sun';
    }
    
    updateWeatherData() {
        // Simular actualización de datos (en una app real, esto vendría de una API)
        const now = new Date();
        this.weatherData.lastUpdate = now.toISOString();
        
        // Actualizar datos de cada ciudad con variaciones pequeñas
        Object.keys(this.weatherData.cities).forEach(cityName => {
            const city = this.weatherData.cities[cityName];
            city.temp = this.getRandomVariation(city.temp, 0.5);
            city.humidity = this.getRandomVariation(city.humidity, 2);
            city.wind = this.getRandomVariation(city.wind, 1);
            city.lastUpdate = now.toISOString();
        });
        
        localStorage.setItem('guineaGlobalWeather', JSON.stringify(this.weatherData));
    }
}

// Clase para gestionar la interfaz del tiempo
class WeatherUI {
    constructor() {
        this.weatherData = new WeatherData();
        this.currentCity = 'Malabo';
        this.initializeUI();
    }
    
    initializeUI() {
        this.updateDateTime();
        this.updateCurrentWeather();
        this.updateCitiesWeather();
        this.updateForecast();
        this.updateHourlyForecast();
        this.updateAlerts();
        this.updateRecommendations();
        this.updateMap();
        
        // Actualizar cada minuto
        setInterval(() => {
            this.updateDateTime();
        }, 60000);
        
        // Actualizar datos del tiempo cada 10 minutos
        setInterval(() => {
            this.weatherData.updateWeatherData();
            this.updateCurrentWeather();
            this.updateCitiesWeather();
        }, 600000);
        
        // Verificar si es un nuevo día para regenerar pronósticos
        setInterval(() => {
            this.checkNewDay();
        }, 3600000); // Cada hora
    }
    
    updateDateTime() {
        const now = new Date();
        
        // Formatear fecha completa
        const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
        
        const dateString = now.toLocaleDateString('es-ES', dateOptions);
        const timeString = now.toLocaleTimeString('es-ES', timeOptions);
        
        // Actualizar elementos en la página
        document.getElementById('current-date').textContent = dateString;
        document.getElementById('current-time').textContent = `Actualizado: ${timeString}`;
        document.getElementById('last-update').textContent = `Última actualización: ${timeString}`;
        document.getElementById('map-update-time').textContent = timeString;
    }
    
    updateCurrentWeather() {
        const weather = this.weatherData.getCurrentWeather(this.currentCity);
        const conditionIcon = this.weatherData.getConditionIcon(weather.condition);
        
        // Actualizar elementos
        document.getElementById('current-location').textContent = `${this.currentCity}, Guinea Ecuatorial`;
        document.getElementById('current-temp').textContent = `${Math.round(weather.temp)}°C`;
        document.getElementById('current-condition').textContent = weather.condition;
        document.getElementById('current-icon').className = `fas ${conditionIcon}`;
        document.getElementById('feels-like').textContent = `${Math.round(weather.feelsLike)}°C`;
        document.getElementById('wind-speed').textContent = `${Math.round(weather.wind)} km/h`;
        document.getElementById('humidity').textContent = `${Math.round(weather.humidity)}%`;
        document.getElementById('pressure').textContent = `${Math.round(weather.pressure)} hPa`;
        document.getElementById('visibility').textContent = `${weather.visibility} km`;
        
        // Actualizar también en el header
        document.getElementById('header-weather').innerHTML = 
            `<i class="fas ${conditionIcon}"></i> ${this.currentCity}: ${Math.round(weather.temp)}°C`;
    }
    
    updateCitiesWeather() {
        const cities = this.weatherData.getAllCitiesWeather();
        const container = document.getElementById('cities-weather');
        
        container.innerHTML = '';
        
        Object.keys(cities).forEach(cityName => {
            const city = cities[cityName];
            const conditionIcon = this.weatherData.getConditionIcon(city.condition);
            
            const cityCard = document.createElement('div');
            cityCard.className = 'city-weather-card';
            cityCard.innerHTML = `
                <h3>${cityName}</h3>
                <div class="city-temp">${Math.round(city.temp)}°C</div>
                <div class="city-condition">
                    <i class="fas ${conditionIcon}"></i> ${city.condition}
                </div>
                <div class="city-details">
                    <span><i class="fas fa-wind"></i> ${Math.round(city.wind)} km/h</span>
                    <span><i class="fas fa-tint"></i> ${Math.round(city.humidity)}%</span>
                </div>
            `;
            
            // Hacer clic en una ciudad para ver su pronóstico detallado
            cityCard.addEventListener('click', () => {
                this.currentCity = cityName;
                this.updateCurrentWeather();
                this.updateForecast();
                this.updateHourlyForecast();
            });
            
            container.appendChild(cityCard);
        });
    }
    
    updateForecast() {
        const forecast = this.weatherData.getForecast(this.currentCity);
        const container = document.getElementById('daily-forecast');
        
        container.innerHTML = '';
        
        forecast.forEach(day => {
            const forecastDay = document.createElement('div');
            forecastDay.className = 'forecast-day';
            forecastDay.innerHTML = `
                <h4>${day.day}</h4>
                <div class="forecast-icon">
                    <i class="fas ${day.icon}"></i>
                </div>
                <div class="forecast-temp">${day.high}° / ${day.low}°</div>
                <div class="forecast-precipitation">
                    <i class="fas fa-tint"></i> ${day.precipitation}%
                </div>
            `;
            container.appendChild(forecastDay);
        });
    }
    
    updateHourlyForecast() {
        const hourly = this.weatherData.getHourlyForecast(this.currentCity);
        const container = document.getElementById('hourly-forecast');
        
        container.innerHTML = '';
        
        // Mostrar solo las próximas 12 horas para mejor visualización
        const next12Hours = hourly.slice(0, 12);
        
        next12Hours.forEach(hour => {
            const hourElement = document.createElement('div');
            hourElement.className = 'hour-forecast';
            hourElement.innerHTML = `
                <div class="hour-time">${hour.time}</div>
                <div class="hour-icon">
                    <i class="fas ${hour.icon}"></i>
                </div>
                <div class="hour-temp">${hour.temp}°</div>
                <div class="hour-precipitation">
                    <i class="fas fa-tint"></i> ${hour.precipitation}%
                </div>
            `;
            container.appendChild(hourElement);
        });
    }
    
    updateAlerts() {
        const alerts = this.weatherData.getAlerts();
        const container = document.getElementById('weather-alerts');
        
        container.innerHTML = '';
        
        alerts.forEach(alert => {
            const alertCard = document.createElement('div');
            alertCard.className = `alert-card ${alert.type}`;
            alertCard.innerHTML = `
                <div class="alert-icon">
                    <i class="fas ${alert.type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'}"></i>
                </div>
                <div class="alert-content">
                    <h3>${alert.title}</h3>
                    <p class="alert-validity">${alert.areas} - Válido hasta: ${alert.validUntil}</p>
                    <p>${alert.description}</p>
                </div>
            `;
            container.appendChild(alertCard);
        });
    }
    
    updateRecommendations() {
        const weather = this.weatherData.getCurrentWeather(this.currentCity);
        const container = document.getElementById('weather-recommendations');
        
        let recommendations = [];
        
        if (weather.condition.includes('Lluvia') || weather.condition.includes('Tormenta')) {
            recommendations = [
                { icon: 'fa-umbrella', text: 'Lleve un paraguas o impermeable' },
                { icon: 'fa-car', text: 'Conduzca con precaución en carreteras mojadas' },
                { icon: 'fa-home', text: 'Revise que no haya fugas en su vivienda' },
                { icon: 'fa-bolt', text: 'Evite áreas abiertas durante tormentas eléctricas' }
            ];
        } else if (weather.temp > 30) {
            recommendations = [
                { icon: 'fa-tint', text: 'Manténgase hidratado durante el día' },
                { icon: 'fa-sun', text: 'Use protector solar si va a estar al aire libre' },
                { icon: 'fa-tshirt', text: 'Use ropa ligera y de colores claros' },
                { icon: 'fa-home', text: 'Mantenga las ventanas cerradas durante las horas de más calor' }
            ];
        } else if (weather.wind > 15) {
            recommendations = [
                { icon: 'fa-wind', text: 'Asegure objetos que puedan volar con el viento' },
                { icon: 'fa-tree', text: 'Evite circular cerca de árboles grandes' },
                { icon: 'fa-ship', text: 'Precaución en actividades marítimas' }
            ];
        } else {
            recommendations = [
                { icon: 'fa-walking', text: 'Excelente día para actividades al aire libre' },
                { icon: 'fa-tree', text: 'Ideal para visitar parques y áreas naturales' },
                { icon: 'fa-bicycle', text: 'Buen momento para practicar deportes' },
                { icon: 'fa-sun', text: 'Disfrute del buen tiempo con moderación' }
            ];
        }
        
        container.innerHTML = '';
        
        recommendations.forEach(rec => {
            const recItem = document.createElement('div');
            recItem.className = 'recommendation-item';
            recItem.innerHTML = `
                <i class="fas ${rec.icon}"></i>
                <p>${rec.text}</p>
            `;
            container.appendChild(recItem);
        });
    }
    
    updateMap() {
        // En una implementación real, esto cargaría un mapa actualizado
        // Por ahora, solo actualizamos la hora de actualización
        const now = new Date();
        const timeString = now.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
        document.getElementById('map-update-time').textContent = timeString;
    }
    
    checkNewDay() {
        const today = new Date().toDateString();
        if (this.weatherData.weatherData.date !== today) {
            // Es un nuevo día, regenerar datos
            this.weatherData.generateDailyWeather();
            this.updateCurrentWeather();
            this.updateCitiesWeather();
            this.updateForecast();
            this.updateHourlyForecast();
            this.updateRecommendations();
        }
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    const weatherUI = new WeatherUI();
    
    // También inicializar funcionalidades generales del sitio
    initializeGeneralFeatures();
});

function initializeGeneralFeatures() {
    // Actualizar fecha en el header
    function updateHeaderDate() {
        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = now.toLocaleDateString('es-ES', options);
        document.getElementById('current-date').textContent = formattedDate;
    }
    
    updateHeaderDate();
    
    // Funcionalidad del modal de administrador
    const adminLoginBtn = document.getElementById('admin-login-btn');
    const adminLoginModal = document.getElementById('admin-login-modal');
    const closeModal = document.querySelector('.close-modal');
    
    if (adminLoginBtn && adminLoginModal) {
        adminLoginBtn.addEventListener('click', function() {
            adminLoginModal.style.display = 'flex';
        });
        
        closeModal.addEventListener('click', function() {
            adminLoginModal.style.display = 'none';
        });
        
        window.addEventListener('click', function(e) {
            if (e.target === adminLoginModal) {
                adminLoginModal.style.display = 'none';
            }
        });
    }
    
    // Manejo del formulario de login de administrador
    const adminLoginForm = document.getElementById('admin-login-form');
    
    if (adminLoginForm) {
        adminLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('admin-username').value;
            const password = document.getElementById('admin-password').value;
            
            // Credenciales de prueba
            if (username === 'admin' && password === 'guinea2023') {
                alert('Inicio de sesión exitoso. Redirigiendo al panel de administración...');
                window.location.href = 'admin/dashboard.php';
            } else {
                alert('Credenciales incorrectas. Por favor, intente nuevamente.');
            }
        });
    }
}