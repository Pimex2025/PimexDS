// Inicialización de la página de categorías
function initPage() {
    loadCategories();
}

// Cargar categorías
function loadCategories() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const categoriesList = document.getElementById('categoriesList');
    categoriesList.innerHTML = '';
    
    if (data.categories.length === 0) {
        categoriesList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-tags"></i>
                <h3>No hay categorías</h3>
                <p>Crea tu primera categoría para organizar las noticias</p>
            </div>
        `;
        return;
    }
    
    data.categories.forEach(category => {
        const categoryItem = document.createElement('div');
        categoryItem.className = 'category-item';
        categoryItem.innerHTML = `
            <div class="category-info">
                <h4>${category.name}</h4>
                <p class="category-meta">${category.description}</p>
                <div class="category-stats">
                    <span class="stat">${category.count} noticias</span>
                    <span class="stat">Slug: ${category.slug}</span>
                </div>
            </div>
            <div class="category-actions">
                <button class="btn btn-sm btn-edit" onclick="editCategory(${category.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-delete" onclick="deleteCategory(${category.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        categoriesList.appendChild(categoryItem);
    });
}

// Crear nueva categoría
function newCategory() {
    document.getElementById('categoryModalTitle').textContent = 'Nueva Categoría';
    document.getElementById('categoryForm').reset();
    document.getElementById('categoryId').value = '';
    openModal('newCategoryModal');
}

// Editar categoría
function editCategory(id) {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const category = data.categories.find(c => c.id === id);
    
    if (category) {
        document.getElementById('categoryModalTitle').textContent = 'Editar Categoría';
        document.getElementById('categoryId').value = category.id;
        document.getElementById('categoryName').value = category.name;
        document.getElementById('categorySlug').value = category.slug;
        document.getElementById('categoryDescription').value = category.description;
        
        openModal('newCategoryModal');
    }
}

// Guardar categoría
document.getElementById('categoryForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const categoryId = document.getElementById('categoryId').value;
    const name = document.getElementById('categoryName').value;
    const slug = document.getElementById('categorySlug').value;
    const description = document.getElementById('categoryDescription').value;
    
    if (categoryId) {
        // Editar categoría existente
        const index = data.categories.findIndex(c => c.id === parseInt(categoryId));
        if (index !== -1) {
            data.categories[index].name = name;
            data.categories[index].slug = slug;
            data.categories[index].description = description;
        }
    } else {
        // Crear nueva categoría
        const newId = Math.max(...data.categories.map(c => c.id)) + 1;
        const newCategory = {
            id: newId,
            name: name,
            slug: slug,
            description: description,
            count: 0
        };
        data.categories.push(newCategory);
    }
    
    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
    showNotification('Categoría guardada correctamente', 'success');
    closeModal();
    loadCategories();
});

// Eliminar categoría
function deleteCategory(id) {
    if (confirm('¿Estás seguro de que quieres eliminar esta categoría? Las noticias asociadas quedarán sin categoría.')) {
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        data.categories = data.categories.filter(category => category.id !== id);
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Categoría eliminada correctamente', 'success');
        loadCategories();
    }
}

// Generar slug automáticamente desde el nombre
document.getElementById('categoryName').addEventListener('input', function() {
    if (!document.getElementById('categoryId').value) {
        const name = this.value;
        const slug = name
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
        document.getElementById('categorySlug').value = slug;
    }
});

// Inicializar página cuando se carga
if (document.getElementById('categoriesList')) {
    initPage();
}