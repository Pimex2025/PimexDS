// Variables para la gestión de comentarios
let currentComments = [];
let currentFilter = 'all';

// Inicialización de la página de comentarios
function initPage() {
    loadComments();
    setupFilters();
}

// Cargar comentarios
function loadComments() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    currentComments = data.comments;
    applyCurrentFilter();
    updateCommentsCount();
}

// Mostrar comentarios
function displayComments() {
    const commentsList = document.getElementById('commentsList');
    commentsList.innerHTML = '';
    
    if (currentComments.length === 0) {
        commentsList.innerHTML = `
            <div class="empty-state" style="text-align: center; padding: 40px;">
                <i class="fas fa-comments" style="font-size: 48px; color: #95a5a6; margin-bottom: 15px;"></i>
                <h3>No hay comentarios</h3>
                <p>No se encontraron comentarios con los filtros aplicados</p>
            </div>
        `;
        return;
    }
    
    currentComments.forEach(comment => {
        const commentItem = document.createElement('div');
        commentItem.className = `comment-item ${comment.status}`;
        commentItem.innerHTML = `
            <div class="comment-avatar">
                <img src="${comment.userAvatar}" alt="${comment.userName}">
            </div>
            <div class="comment-content">
                <div class="comment-header">
                    <div class="commenter-info">
                        <h4>${comment.userName}</h4>
                        <span class="commenter-email">${comment.userEmail}</span>
                    </div>
                    <div class="comment-meta">
                        <span class="comment-date">${formatTimeAgo(comment.createdAt)}</span>
                        <span class="comment-status ${comment.status}">
                            ${getCommentStatusText(comment.status)}
                        </span>
                    </div>
                </div>
                <p class="comment-text">${comment.content}</p>
                
                ${comment.replies && comment.replies.length > 0 ? `
                    <div class="comment-replies">
                        <h5>Respuestas:</h5>
                        ${comment.replies.map(reply => `
                            <div class="reply-item">
                                <div class="reply-header">
                                    <strong>${reply.author}</strong>
                                    <span class="reply-date">${formatTimeAgo(reply.createdAt)}</span>
                                </div>
                                <p class="reply-text">${reply.content}</p>
                            </div>
                        `).join('')}
                    </div>
                ` : ''}
                
                <div class="comment-actions">
                    ${comment.status === 'pending' ? `
                        <button class="btn btn-sm btn-approve" onclick="approveComment(${comment.id})">Aprobar</button>
                        <button class="btn btn-sm btn-reject" onclick="rejectComment(${comment.id})">Rechazar</button>
                    ` : ''}
                    <button class="btn btn-sm btn-reply" onclick="openReplyModal(${comment.id})">Responder</button>
                    <button class="btn btn-sm btn-delete" onclick="deleteComment(${comment.id})">Eliminar</button>
                </div>
            </div>
        `;
        commentsList.appendChild(commentItem);
    });
}

// Configurar filtros
function setupFilters() {
    const filterButtons = document.querySelectorAll('.status-filter-btn');
    const searchInput = document.getElementById('searchComments');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remover clase active de todos los botones
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Añadir clase active al botón clickeado
            this.classList.add('active');
            
            currentFilter = this.getAttribute('data-status');
            applyCurrentFilter();
        });
    });
    
    searchInput.addEventListener('input', function() {
        applyCurrentFilter();
    });
}

// Aplicar filtros actuales
function applyCurrentFilter() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    let filtered = data.comments;
    const searchTerm = document.getElementById('searchComments').value.toLowerCase();
    
    // Filtrar por estado
    if (currentFilter !== 'all') {
        filtered = filtered.filter(comment => comment.status === currentFilter);
    }
    
    // Filtrar por búsqueda
    if (searchTerm) {
        filtered = filtered.filter(comment => 
            comment.content.toLowerCase().includes(searchTerm) ||
            comment.userName.toLowerCase().includes(searchTerm) ||
            comment.userEmail.toLowerCase().includes(searchTerm)
        );
    }
    
    currentComments = filtered;
    displayComments();
    updateCommentsCount();
}

// Actualizar contador de comentarios
function updateCommentsCount() {
    const totalComments = currentComments.length;
    const pendingComments = currentComments.filter(c => c.status === 'pending').length;
    
    let countText = `${totalComments} comentarios`;
    if (pendingComments > 0) {
        countText += ` (${pendingComments} pendientes)`;
    }
    
    document.getElementById('commentsCount').textContent = countText;
}

// Obtener texto del estado del comentario
function getCommentStatusText(status) {
    const statusMap = {
        'pending': 'Pendiente',
        'approved': 'Aprobado',
        'rejected': 'Rechazado'
    };
    return statusMap[status] || status;
}

// Aprobar comentario
function approveComment(id) {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const commentIndex = data.comments.findIndex(comment => comment.id === id);
    
    if (commentIndex !== -1) {
        data.comments[commentIndex].status = 'approved';
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Comentario aprobado', 'success');
        loadComments();
    }
}

// Rechazar comentario
function rejectComment(id) {
    if (confirm('¿Estás seguro de que quieres rechazar este comentario?')) {
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        const commentIndex = data.comments.findIndex(comment => comment.id === id);
        
        if (commentIndex !== -1) {
            data.comments[commentIndex].status = 'rejected';
            localStorage.setItem('guineaGlobalData', JSON.stringify(data));
            
            showNotification('Comentario rechazado', 'success');
            loadComments();
        }
    }
}

// Eliminar comentario
function deleteComment(id) {
    if (confirm('¿Estás seguro de que quieres eliminar este comentario?')) {
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        data.comments = data.comments.filter(comment => comment.id !== id);
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Comentario eliminado', 'success');
        loadComments();
    }
}

// Abrir modal para responder
function openReplyModal(id) {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const comment = data.comments.find(c => c.id === id);
    
    if (comment) {
        document.getElementById('commentId').value = comment.id;
        document.getElementById('originalComment').innerHTML = `
            <div class="original-comment-header">
                <strong>${comment.userName}</strong> 
                <span class="original-comment-date">${formatTimeAgo(comment.createdAt)}</span>
            </div>
            <div class="original-comment-text">${comment.content}</div>
        `;
        document.getElementById('replyContent').value = '';
        
        openModal('replyCommentModal');
    }
}

// Enviar respuesta
document.getElementById('replyForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const commentId = parseInt(document.getElementById('commentId').value);
    const replyContent = document.getElementById('replyContent').value;
    
    const commentIndex = data.comments.findIndex(comment => comment.id === commentId);
    
    if (commentIndex !== -1) {
        if (!data.comments[commentIndex].replies) {
            data.comments[commentIndex].replies = [];
        }
        
        const newReply = {
            id: data.comments[commentIndex].replies.length + 1,
            author: "Admin User",
            content: replyContent,
            createdAt: new Date().toISOString()
        };
        
        data.comments[commentIndex].replies.push(newReply);
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Respuesta enviada correctamente', 'success');
        closeModal();
        loadComments();
    }
});

// Inicializar página cuando se carga
if (document.getElementById('commentsList')) {
    initPage();
}

// Estilos adicionales para comentarios
const commentStyles = document.createElement('style');
commentStyles.textContent = `
    .comments-list {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }
    
    .comment-item {
        display: flex;
        padding: 15px;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        background-color: white;
    }
    
    .comment-item.pending {
        border-left: 4px solid #f39c12;
        background-color: #fffbf0;
    }
    
    .comment-item.approved {
        border-left: 4px solid #27ae60;
    }
    
    .comment-item.rejected {
        border-left: 4px solid #e74c3c;
        background-color: #fdf2f2;
    }
    
    .comment-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 8px;
    }
    
    .commenter-info h4 {
        margin: 0 0 2px 0;
        font-size: 14px;
    }
    
    .commenter-email {
        font-size: 12px;
        color: #95a5a6;
    }
    
    .comment-meta {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 5px;
    }
    
    .comment-date {
        font-size: 12px;
        color: #95a5a6;
    }
    
    .comment-status {
        font-size: 11px;
        padding: 2px 6px;
        border-radius: 10px;
        font-weight: 500;
    }
    
    .comment-status.pending {
        background-color: #fff3cd;
        color: #856404;
    }
    
    .comment-status.approved {
        background-color: #d4edda;
        color: #155724;
    }
    
    .comment-status.rejected {
        background-color: #f8d7da;
        color: #721c24;
    }
    
    .comment-text {
        margin-bottom: 10px;
        font-size: 14px;
        line-height: 1.5;
    }
    
    .comment-replies {
        margin: 15px 0;
        padding: 15px;
        background-color: #f8f9fa;
        border-radius: 6px;
    }
    
    .comment-replies h5 {
        margin: 0 0 10px 0;
        font-size: 14px;
        color: #2c3e50;
    }
    
    .reply-item {
        margin-bottom: 10px;
        padding-bottom: 10px;
        border-bottom: 1px solid #e9ecef;
    }
    
    .reply-item:last-child {
        margin-bottom: 0;
        padding-bottom: 0;
        border-bottom: none;
    }
    
    .reply-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 5px;
    }
    
    .reply-header strong {
        font-size: 13px;
    }
    
    .reply-date {
        font-size: 11px;
        color: #95a5a6;
    }
    
    .reply-text {
        font-size: 13px;
        margin: 0;
        color: #495057;
    }
    
    .original-comment {
        padding: 15px;
        background-color: #f8f9fa;
        border-radius: 6px;
        margin-bottom: 20px;
    }
    
    .original-comment-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
    }
    
    .original-comment-text {
        font-size: 14px;
        line-height: 1.5;
        color: #495057;
    }
`;
document.head.appendChild(commentStyles);