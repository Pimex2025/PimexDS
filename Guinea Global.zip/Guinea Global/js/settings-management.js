// Inicialización de la página de configuración
function initPage() {
    loadSettings();
    setupTabs();
}

// Cargar configuración
function loadSettings() {
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    const settings = data.settings;
    
    // General Tab
    document.getElementById('siteTitle').value = settings.siteTitle || '';
    document.getElementById('siteDescription').value = settings.siteDescription || '';
    document.getElementById('adminEmail').value = settings.adminEmail || '';
    document.getElementById('siteLanguage').value = settings.siteLanguage || 'es';
    document.getElementById('timezone').value = settings.timezone || 'Africa/Malabo';
    document.getElementById('dateFormat').value = settings.dateFormat || 'DD/MM/YYYY';
    
    // Content Tab
    document.getElementById('postsPerPage').value = settings.postsPerPage || 10;
    document.getElementById('excerptLength').value = settings.excerptLength || 150;
    document.getElementById('autoResizeImages').checked = settings.autoResizeImages || false;
    document.getElementById('compressImages').checked = settings.compressImages || false;
    document.getElementById('defaultCategory').value = settings.defaultCategory || '';
    
    // Comments Tab
    document.getElementById('commentsEnabled').checked = settings.commentsEnabled !== false;
    document.getElementById('commentModeration').checked = settings.commentModeration !== false;
    document.getElementById('userRegistration').checked = settings.userRegistration || false;
    document.getElementById('autoCloseComments').value = settings.autoCloseComments || 0;
    document.getElementById('maxLinks').value = settings.maxLinks || 2;
    document.getElementById('blacklistWords').value = settings.blacklistWords || '';
    
    // SEO Tab
    document.getElementById('metaTitle').value = settings.metaTitle || '';
    document.getElementById('metaDescription').value = settings.metaDescription || '';
    document.getElementById('metaKeywords').value = settings.metaKeywords || '';
    document.getElementById('autoMetaTags').checked = settings.autoMetaTags !== false;
    document.getElementById('openGraph').checked = settings.openGraph !== false;
    document.getElementById('twitterCards').checked = settings.twitterCards || false;
    document.getElementById('googleAnalytics').value = settings.googleAnalytics || '';
    
    // Advanced Tab
    document.getElementById('cacheDuration').value = settings.cacheDuration || 60;
    document.getElementById('backupFrequency').value = settings.backupFrequency || 'weekly';
    document.getElementById('maintenanceMode').checked = settings.maintenanceMode || false;
    document.getElementById('debugMode').checked = settings.debugMode || false;
}

// Configurar pestañas
function setupTabs() {
    const tabs = document.querySelectorAll('.settings-tab');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Remover clase active de todas las pestañas y contenidos
            tabs.forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.settings-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Añadir clase active a la pestaña y contenido seleccionados
            this.classList.add('active');
            document.getElementById(tabId + 'Tab').classList.add('active');
        });
    });
}

// Guardar configuración general
document.getElementById('generalSettingsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    
    data.settings.siteTitle = document.getElementById('siteTitle').value;
    data.settings.siteDescription = document.getElementById('siteDescription').value;
    data.settings.adminEmail = document.getElementById('adminEmail').value;
    data.settings.siteLanguage = document.getElementById('siteLanguage').value;
    data.settings.timezone = document.getElementById('timezone').value;
    data.settings.dateFormat = document.getElementById('dateFormat').value;
    
    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
    showNotification('Configuración general guardada', 'success');
});

// Guardar configuración de contenido
document.getElementById('contentSettingsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    
    data.settings.postsPerPage = parseInt(document.getElementById('postsPerPage').value);
    data.settings.excerptLength = parseInt(document.getElementById('excerptLength').value);
    data.settings.autoResizeImages = document.getElementById('autoResizeImages').checked;
    data.settings.compressImages = document.getElementById('compressImages').checked;
    data.settings.defaultCategory = document.getElementById('defaultCategory').value;
    
    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
    showNotification('Configuración de contenido guardada', 'success');
});

// Guardar configuración de comentarios
document.getElementById('commentsSettingsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    
    data.settings.commentsEnabled = document.getElementById('commentsEnabled').checked;
    data.settings.commentModeration = document.getElementById('commentModeration').checked;
    data.settings.userRegistration = document.getElementById('userRegistration').checked;
    data.settings.autoCloseComments = parseInt(document.getElementById('autoCloseComments').value);
    data.settings.maxLinks = parseInt(document.getElementById('maxLinks').value);
    data.settings.blacklistWords = document.getElementById('blacklistWords').value;
    
    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
    showNotification('Configuración de comentarios guardada', 'success');
});

// Guardar configuración SEO
document.getElementById('seoSettingsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    
    data.settings.metaTitle = document.getElementById('metaTitle').value;
    data.settings.metaDescription = document.getElementById('metaDescription').value;
    data.settings.metaKeywords = document.getElementById('metaKeywords').value;
    data.settings.autoMetaTags = document.getElementById('autoMetaTags').checked;
    data.settings.openGraph = document.getElementById('openGraph').checked;
    data.settings.twitterCards = document.getElementById('twitterCards').checked;
    data.settings.googleAnalytics = document.getElementById('googleAnalytics').value;
    
    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
    showNotification('Configuración SEO guardada', 'success');
});

// Guardar configuración avanzada
document.getElementById('advancedSettingsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
    
    data.settings.cacheDuration = parseInt(document.getElementById('cacheDuration').value);
    data.settings.backupFrequency = document.getElementById('backupFrequency').value;
    data.settings.maintenanceMode = document.getElementById('maintenanceMode').checked;
    data.settings.debugMode = document.getElementById('debugMode').checked;
    
    localStorage.setItem('guineaGlobalData', JSON.stringify(data));
    showNotification('Configuración avanzada guardada', 'success');
});

// Funciones para acciones peligrosas
function clearCache() {
    if (confirm('¿Estás seguro de que quieres limpiar la caché?')) {
        // Simular limpieza de caché
        setTimeout(() => {
            showNotification('Caché limpiada correctamente', 'success');
        }, 1000);
    }
}

function optimizeDatabase() {
    if (confirm('¿Estás seguro de que quieres optimizar la base de datos?')) {
        // Simular optimización de base de datos
        setTimeout(() => {
            showNotification('Base de datos optimizada correctamente', 'success');
        }, 1500);
    }
}

function createBackup() {
    // Simular creación de backup
    showNotification('Creando backup...', 'info');
    
    setTimeout(() => {
        // En un entorno real, aquí se descargaría el archivo de backup
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        const backupData = JSON.stringify(data, null, 2);
        const blob = new Blob([backupData], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `guinea-global-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        showNotification('Backup creado y descargado correctamente', 'success');
    }, 2000);
}

function resetSettings() {
    if (confirm('¿Estás seguro de que quieres restablecer toda la configuración a los valores por defecto? Esta acción no se puede deshacer.')) {
        const data = JSON.parse(localStorage.getItem('guineaGlobalData'));
        
        // Restablecer solo la configuración, mantener el contenido
        data.settings = mockData.settings;
        localStorage.setItem('guineaGlobalData', JSON.stringify(data));
        
        showNotification('Configuración restablecida a los valores por defecto', 'success');
        loadSettings();
    }
}

// Inicializar página cuando se carga
if (document.querySelector('.settings-tabs')) {
    initPage();
}

// Estilos adicionales para configuración
const settingsStyles = document.createElement('style');
settingsStyles.textContent = `
    .danger-actions {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 10px;
        margin-top: 10px;
    }
    
    .btn-warning {
        background-color: #f39c12;
        color: white;
    }
    
    .btn-warning:hover {
        background-color: #e67e22;
    }
    
    .form-text {
        display: block;
        margin-top: 5px;
        font-size: 12px;
        color: #95a5a6;
    }
    
    .settings-content {
        animation: fadeIn 0.3s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
`;
document.head.appendChild(settingsStyles);