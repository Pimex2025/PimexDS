// js/script.js

// Funcionalidad del menú móvil
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const dropdowns = document.querySelectorAll('.dropdown');
    
    // Toggle del menú móvil
    mobileMenuToggle.addEventListener('click', function() {
        navMenu.classList.toggle('active');
    });
    
    // Toggle de submenús en móvil
    dropdowns.forEach(dropdown => {
        const link = dropdown.querySelector('a');
        
        link.addEventListener('click', function(e) {
            if (window.innerWidth <= 768) {
                e.preventDefault();
                dropdown.classList.toggle('active');
            }
        });
    });
    
    // Cerrar menú al hacer clic fuera de él
    document.addEventListener('click', function(e) {
        if (!navMenu.contains(e.target) && !mobileMenuToggle.contains(e.target)) {
            navMenu.classList.remove('active');
        }
    });
    
    // Slider de imágenes
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    let currentSlide = 0;
    let slideInterval;
    
    // Función para mostrar slide específico
    function showSlide(n) {
        slides.forEach(slide => slide.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));
        
        currentSlide = (n + slides.length) % slides.length;
        
        slides[currentSlide].classList.add('active');
        dots[currentSlide].classList.add('active');
    }
    
    // Función para siguiente slide
    function nextSlide() {
        showSlide(currentSlide + 1);
    }
    
    // Función para slide anterior
    function prevSlide() {
        showSlide(currentSlide - 1);
    }
    
    // Event listeners para controles del slider
    nextBtn.addEventListener('click', nextSlide);
    prevBtn.addEventListener('click', prevSlide);
    
    // Event listeners para dots
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            showSlide(index);
            resetSlideInterval();
        });
    });
    
    // Iniciar intervalo automático
    function startSlideInterval() {
        slideInterval = setInterval(nextSlide, 5000);
    }
    
    // Reiniciar intervalo
    function resetSlideInterval() {
        clearInterval(slideInterval);
        startSlideInterval();
    }
    
    startSlideInterval();
    
    // Pausar slider al pasar el ratón
    const slider = document.querySelector('.slider');
    slider.addEventListener('mouseenter', () => {
        clearInterval(slideInterval);
    });
    
    slider.addEventListener('mouseleave', () => {
        startSlideInterval();
    });
    
    // Filtrado de noticias
    const categoryFilter = document.getElementById('category-filter');
    const newsCards = document.querySelectorAll('.news-card');
    
    categoryFilter.addEventListener('change', function() {
        const selectedCategory = this.value;
        
        newsCards.forEach(card => {
            if (selectedCategory === 'all' || card.dataset.category === selectedCategory) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
    
    // Funcionalidad del buscador
    const searchInput = document.querySelector('.search-bar input');
    const searchButton = document.querySelector('.search-bar button');
    
    function performSearch() {
        const searchTerm = searchInput.value.toLowerCase().trim();
        
        if (searchTerm === '') {
            // Si no hay término de búsqueda, mostrar todas las noticias
            newsCards.forEach(card => {
                card.style.display = 'block';
            });
            return;
        }
        
        newsCards.forEach(card => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            const excerpt = card.querySelector('.news-excerpt').textContent.toLowerCase();
            const category = card.querySelector('.category-tag').textContent.toLowerCase();
            
            if (title.includes(searchTerm) || excerpt.includes(searchTerm) || category.includes(searchTerm)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }
    
    searchButton.addEventListener('click', performSearch);
    searchInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    
    // Modal de login de administrador
    const adminLoginBtn = document.getElementById('admin-login-btn');
    const adminLoginModal = document.getElementById('admin-login-modal');
    const closeModal = document.querySelector('.close-modal');
    const adminLoginForm = document.getElementById('admin-login-form');
    
    adminLoginBtn.addEventListener('click', function() {
        adminLoginModal.style.display = 'flex';
    });
    
    closeModal.addEventListener('click', function() {
        adminLoginModal.style.display = 'none';
    });
    
    window.addEventListener('click', function(e) {
        if (e.target === adminLoginModal) {
            adminLoginModal.style.display = 'none';
        }
    });
    
    // Manejo del formulario de login de administrador
    adminLoginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('admin-username').value;
        const password = document.getElementById('admin-password').value;
        
        // En una implementación real, aquí se haría una petición al servidor
        // Para este ejemplo, usaremos credenciales de prueba
        if (username === 'admin' && password === 'guinea2023') {
            alert('Inicio de sesión exitoso. Redirigiendo al panel de administración...');
            // En una implementación real, redirigiríamos al dashboard
             window.location.href = 'dashboard.html';
            adminLoginModal.style.display = 'none';
        } else {
            alert('Credenciales incorrectas. Por favor, intente nuevamente.');
        }
    });
    
    // Suscripción al newsletter
    const newsletterForm = document.querySelector('.newsletter-form');
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        
        // En una implementación real, aquí se enviaría el email al servidor
        alert(`¡Gracias por suscribirse con el correo: ${email}!`);
        this.reset();
    });
    
    // Actualización de la fecha
    function updateDate() {
        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = now.toLocaleDateString('es-ES', options);
        document.querySelector('.date').textContent = formattedDate;
    }
    
    updateDate();
    
    // Simulación de datos meteorológicos
    function updateWeather() {
        // En una implementación real, se obtendrían datos de una API
        const cities = [
            { name: 'Malabo', temp: 28, icon: 'fa-sun' },
            { name: 'Bata', temp: 30, icon: 'fa-cloud-sun' },
            { name: 'Ebebiyín', temp: 29, icon: 'fa-sun' }
        ];
        
        const randomCity = cities[Math.floor(Math.random() * cities.length)];
        const weatherWidget = document.querySelector('.weather-widget');
        
        weatherWidget.innerHTML = `<span><i class="fas ${randomCity.icon}"></i> ${randomCity.name}: ${randomCity.temp}°C</span>`;
    }
    
    updateWeather();
    
    // Actualizar el clima cada hora
    setInterval(updateWeather, 3600000);
});
// Carrusel de Publicidad Automático
class AdvertisingCarousel {
    constructor() {
        this.carousel = document.querySelector('.advertising-carousel');
        this.slides = document.querySelectorAll('.ad-slide');
        this.indicators = document.querySelectorAll('.ad-indicator');
        this.prevBtn = document.querySelector('.ad-prev');
        this.nextBtn = document.querySelector('.ad-next');
        this.progressBar = document.querySelector('.ad-progress-bar');
        
        this.currentSlide = 0;
        this.slideCount = this.slides.length;
        this.autoPlayInterval = null;
        this.progressInterval = null;
        this.autoPlayDelay = 5000; // 5 segundos
        
        this.init();
    }
    
    init() {
        // Iniciar autoplay
        this.startAutoPlay();
        
        // Event listeners para controles
        this.prevBtn.addEventListener('click', () => {
            this.stopAutoPlay();
            this.prevSlide();
            this.startAutoPlay();
        });
        
        this.nextBtn.addEventListener('click', () => {
            this.stopAutoPlay();
            this.nextSlide();
            this.startAutoPlay();
        });
        
        // Event listeners para indicadores
        this.indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => {
                this.stopAutoPlay();
                this.goToSlide(index);
                this.startAutoPlay();
            });
        });
        
        // Pausar autoplay al hacer hover
        this.carousel.addEventListener('mouseenter', () => {
            this.stopAutoPlay();
        });
        
        this.carousel.addEventListener('mouseleave', () => {
            this.startAutoPlay();
        });
        
        // Soporte para touch en dispositivos móviles
        this.addTouchSupport();
    }
    
    startAutoPlay() {
        this.stopAutoPlay();
        
        this.autoPlayInterval = setInterval(() => {
            this.nextSlide();
        }, this.autoPlayDelay);
        
        this.startProgressBar();
    }
    
    stopAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
            this.autoPlayInterval = null;
        }
        
        if (this.progressInterval) {
            clearInterval(this.progressInterval);
            this.progressInterval = null;
        }
        
        this.progressBar.style.width = '0%';
    }
    
    startProgressBar() {
        this.progressBar.style.width = '0%';
        
        const startTime = Date.now();
        const duration = this.autoPlayDelay;
        
        this.progressInterval = setInterval(() => {
            const elapsed = Date.now() - startTime;
            const progress = (elapsed / duration) * 100;
            
            this.progressBar.style.width = `${progress}%`;
            
            if (progress >= 100) {
                clearInterval(this.progressInterval);
            }
        }, 50);
    }
    
    nextSlide() {
        this.currentSlide = (this.currentSlide + 1) % this.slideCount;
        this.updateCarousel();
    }
    
    prevSlide() {
        this.currentSlide = (this.currentSlide - 1 + this.slideCount) % this.slideCount;
        this.updateCarousel();
    }
    
    goToSlide(index) {
        this.currentSlide = index;
        this.updateCarousel();
    }
    
    updateCarousel() {
        // Ocultar todos los slides
        this.slides.forEach(slide => {
            slide.classList.remove('active');
        });
        
        // Mostrar slide actual
        this.slides[this.currentSlide].classList.add('active');
        
        // Actualizar indicadores
        this.indicators.forEach((indicator, index) => {
            indicator.classList.toggle('active', index === this.currentSlide);
        });
        
        // Reiniciar barra de progreso
        this.startProgressBar();
    }
    
    addTouchSupport() {
        let startX = 0;
        let endX = 0;
        
        this.carousel.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            this.stopAutoPlay();
        });
        
        this.carousel.addEventListener('touchmove', (e) => {
            endX = e.touches[0].clientX;
        });
        
        this.carousel.addEventListener('touchend', () => {
            const diff = startX - endX;
            const minSwipeDistance = 50;
            
            if (Math.abs(diff) > minSwipeDistance) {
                if (diff > 0) {
                    this.nextSlide();
                } else {
                    this.prevSlide();
                }
            }
            
            this.startAutoPlay();
        });
    }
}

// Inicializar el carrusel cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    new AdvertisingCarousel();
});

// Función para cargar anuncios dinámicamente (opcional)
function loadDynamicAds() {
    // Aquí puedes agregar lógica para cargar anuncios desde una API
    // o base de datos en el futuro
    console.log('Cargando anuncios dinámicos...');
}

// Llamar a la función de carga dinámica
loadDynamicAds();

// Datos de ejemplo para simular una base de datos
const mockData = {
    users: [
        {
            id: 1,
            name: "Admin User",
            email: "admin@guinea-global.com",
            role: "Administrador",
            avatar: "images/admin-avatar.jpg",
            status: "active",
            createdAt: "2023-01-15"
        },
        {
            id: 2,
            name: "Editor Principal",
            email: "editor@guinea-global.com",
            role: "Editor",
            avatar: "images/user-1.jpg",
            status: "active",
            createdAt: "2023-02-20"
        },
        {
            id: 3,
            name: "Periodista Deportes",
            email: "deportes@guinea-global.com",
            role: "Redactor",
            avatar: "images/user-2.jpg",
            status: "active",
            createdAt: "2023-03-10"
        }
    ],
    categories: [
        { id: 1, name: "Nacionales", slug: "nacionales", description: "Noticias nacionales de Guinea Ecuatorial", count: 425 },
        { id: 2, name: "Deportes", slug: "deportes", description: "Noticias sobre deportes nacionales e internacionales", count: 312 },
        { id: 3, name: "Política", slug: "politica", description: "Noticias sobre política nacional e internacional", count: 198 },
        { id: 4, name: "Cultura", slug: "cultura", description: "Noticias sobre cultura, arte y tradiciones", count: 156 },
        { id: 5, name: "Tecnología", slug: "tecnologia", description: "Noticias sobre tecnología e innovación", count: 89 },
        { id: 6, name: "Internacional", slug: "internacional", description: "Noticias internacionales", count: 67 }
    ],
    news: [
        {
            id: 1,
            title: "Guinea Ecuatorial lanza su primer satélite de comunicaciones",
            excerpt: "El país da un paso histórico en el ámbito tecnológico con el lanzamiento de su primer satélite.",
            content: "<p>Guinea Ecuatorial ha marcado un hito histórico en su desarrollo tecnológico con el lanzamiento exitoso de su primer satélite de comunicaciones. El proyecto, que ha sido desarrollado en colaboración con expertos internacionales, posiciona al país como pionero en la región en materia de telecomunicaciones.</p><p>El satélite, bautizado como 'GuineaSat-1', permitirá mejorar significativamente las comunicaciones en el país y ofrecerá nuevos servicios de internet y televisión por satélite a la población.</p>",
            category: "Tecnología",
            author: "Admin User",
            status: "published",
            featuredImage: "images/news-1.jpg",
            createdAt: "2023-09-05",
            updatedAt: "2023-09-05",
            views: 1250,
            comments: 24
        },
        {
            id: 2,
            title: "Selección nacional de fútbol gana partido de preparación",
            excerpt: "La selección de fútbol de Guinea Ecuatorial se prepara para la próxima competición con una victoria.",
            content: "<p>La selección nacional de fútbol de Guinea Ecuatorial logró una importante victoria en el partido de preparación ante el combinado de Camerún. El encuentro, disputado en el estadio de Malabo, finalizó con un marcador de 2-1 a favor del equipo local.</p><p>El entrenador destacó el buen rendimiento del equipo y la actitud positiva de los jugadores de cara a la próxima competición continental.</p>",
            category: "Deportes",
            author: "Periodista Deportes",
            status: "published",
            featuredImage: "images/news-2.jpg",
            createdAt: "2023-09-04",
            updatedAt: "2023-09-04",
            views: 980,
            comments: 15
        },
        {
            id: 3,
            title: "Festival cultural reúne a comunidades de todo el país",
            excerpt: "El festival anual de cultura congrega a representantes de todas las regiones del país.",
            content: "<p>La capital acogió durante el fin de semana el Festival Nacional de Cultura, un evento que reunió a representantes de todas las regiones de Guinea Ecuatorial para mostrar la riqueza y diversidad cultural del país.</p><p>Durante tres días, los asistentes pudieron disfrutar de música tradicional, danzas, gastronomía típica y exposiciones de artesanía local. El evento contó con una alta participación y fue elogiado por su capacidad para unir a las diferentes comunidades del país.</p>",
            category: "Cultura",
            author: "Editor Principal",
            status: "published",
            featuredImage: "images/news-3.jpg",
            createdAt: "2023-09-03",
            updatedAt: "2023-09-03",
            views: 750,
            comments: 12
        },
        {
            id: 4,
            title: "Gobierno anuncia plan de desarrollo para infraestructuras rurales",
            excerpt: "El gobierno presenta un ambicioso plan para mejorar las infraestructuras en zonas rurales.",
            content: "<p>El gobierno de Guinea Ecuatorial ha anunciado un ambicioso plan de desarrollo de infraestructuras para las zonas rurales del país. El proyecto, que contará con una inversión inicial de 50 millones de euros, tiene como objetivo mejorar el acceso a servicios básicos como agua potable, electricidad y comunicaciones en las comunidades más alejadas.</p><p>El plan se implementará en fases durante los próximos cinco años y se espera que beneficie a más de 200.000 personas en todo el territorio nacional.</p>",
            category: "Política",
            author: "Admin User",
            status: "pending",
            featuredImage: "images/news-4.jpg",
            createdAt: "2023-09-02",
            updatedAt: "2023-09-02",
            views: 0,
            comments: 0
        }
    ],
    comments: [
        {
            id: 1,
            newsId: 1,
            userName: "María Ondo",
            userEmail: "maria.ondo@example.com",
            userAvatar: "images/user-1.jpg",
            content: "Excelente artículo sobre el nuevo satélite. Es un gran paso para nuestro país en el ámbito tecnológico.",
            status: "pending",
            createdAt: "2023-09-05T14:30:00",
            replies: []
        },
        {
            id: 2,
            newsId: 2,
            userName: "Javier Mbá",
            userEmail: "javier.mba@example.com",
            userAvatar: "images/user-2.jpg",
            content: "Me gustaría ver más cobertura sobre los partidos de la selección nacional. ¡Gran trabajo con la página de deportes!",
            status: "pending",
            createdAt: "2023-09-05T11:15:00",
            replies: []
        },
        {
            id: 3,
            newsId: 3,
            userName: "Ana Nsue",
            userEmail: "ana.nsue@example.com",
            userAvatar: "images/user-3.jpg",
            content: "La información sobre el festival cultural fue muy completa. ¿Habrá cobertura en vivo del evento el próximo fin de semana?",
            status: "approved",
            createdAt: "2023-09-04T16:45:00",
            replies: [
                {
                    id: 1,
                    author: "Editor Principal",
                    content: "Hola Ana, sí tendremos cobertura en vivo a través de nuestras redes sociales. ¡No te lo pierdas!",
                    createdAt: "2023-09-04T17:20:00"
                }
            ]
        }
    ],
    media: [
        {
            id: 1,
            name: "satelite-guinea.jpg",
            url: "images/news-1.jpg",
            type: "image",
            size: "2.4 MB",
            uploadedAt: "2023-09-05",
            uploadedBy: "Admin User"
        },
        {
            id: 2,
            name: "seleccion-futbol.jpg",
            url: "images/news-2.jpg",
            type: "image",
            size: "1.8 MB",
            uploadedAt: "2023-09-04",
            uploadedBy: "Periodista Deportes"
        },
        {
            id: 3,
            name: "festival-cultural.jpg",
            url: "images/news-3.jpg",
            type: "image",
            size: "2.1 MB",
            uploadedAt: "2023-09-03",
            uploadedBy: "Editor Principal"
        },
        {
            id: 4,
            name: "infraestructuras-rurales.jpg",
            url: "images/news-4.jpg",
            type: "image",
            size: "2.7 MB",
            uploadedAt: "2023-09-02",
            uploadedBy: "Admin User"
        }
    ],
    settings: {
        siteTitle: "Guinea-global",
        siteDescription: "Portal de noticias de Guinea Ecuatorial",
        siteLanguage: "es",
        timezone: "Africa/Malabo",
        dateFormat: "DD/MM/YYYY",
        postsPerPage: 10,
        commentsEnabled: true,
        commentModeration: true,
        adminEmail: "admin@guinea-global.com"
    }
};

// Inicialización de la aplicación
document.addEventListener('DOMContentLoaded', function() {
    // Cargar datos en localStorage si no existen
    if (!localStorage.getItem('guineaGlobalData')) {
        localStorage.setItem('guineaGlobalData', JSON.stringify(mockData));
    }
    
    // Inicializar componentes comunes
    initNavigation();
    initModals();
    initForms();
    
    // Ejecutar inicialización específica de página
    if (typeof initPage !== 'undefined') {
        initPage();
    }
});

// Navegación entre páginas
function initNavigation() {
    // Marcar enlace activo en el sidebar
    const currentPage = window.location.pathname.split('/').pop() || 'dashboard.html';
    const navLinks = document.querySelectorAll('.dashboard-nav a');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
    
    // Manejar botón de cerrar sesión
    const logoutBtn = document.querySelector('.logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
                window.location.href = 'index.html';
            }
        });
    }
}

// Sistema de modales
function initModals() {
    // Abrir modal
    document.addEventListener('click', function(e) {
        if (e.target.matches('[data-toggle="modal"]')) {
            const modalId = e.target.getAttribute('data-target');
            openModal(modalId);
        }
    });
    
    // Cerrar modal
    document.addEventListener('click', function(e) {
        if (e.target.matches('.modal-close, .modal') || e.target.closest('.modal-close')) {
            closeModal();
        }
    });
    
    // Cerrar modal con ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.style.display = 'none';
    });
    document.body.style.overflow = 'auto';
}

// Sistema de formularios
function initForms() {
    // Manejar envío de formularios
    document.addEventListener('submit', function(e) {
        if (e.target.matches('form')) {
            e.preventDefault();
            handleFormSubmit(e.target);
        }
    });
    
    // Validación de campos requeridos
    const requiredFields = document.querySelectorAll('[required]');
    requiredFields.forEach(field => {
        field.addEventListener('blur', function() {
            validateField(this);
        });
    });
}

function validateField(field) {
    const value = field.value.trim();
    const errorElement = field.parentNode.querySelector('.field-error') || 
                         document.createElement('div');
    
    if (!errorElement.classList.contains('field-error')) {
        errorElement.className = 'field-error';
        field.parentNode.appendChild(errorElement);
    }
    
    if (field.hasAttribute('required') && !value) {
        errorElement.textContent = 'Este campo es obligatorio';
        field.classList.add('error');
        return false;
    }
    
    if (field.type === 'email' && value && !isValidEmail(value)) {
        errorElement.textContent = 'Por favor, introduce un email válido';
        field.classList.add('error');
        return false;
    }
    
    errorElement.textContent = '';
    field.classList.remove('error');
    return true;
}

function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function handleFormSubmit(form) {
    // Validar todos los campos
    const fields = form.querySelectorAll('[required]');
    let isValid = true;
    
    fields.forEach(field => {
        if (!validateField(field)) {
            isValid = false;
        }
    });
    
    if (!isValid) {
        showNotification('Por favor, completa todos los campos obligatorios', 'error');
        return;
    }
    
    // Simular envío del formulario
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    // Aquí normalmente enviaríamos los datos al servidor
    console.log('Datos del formulario:', data);
    
    // Mostrar mensaje de éxito
    showNotification('Los cambios se han guardado correctamente', 'success');
    
    // Cerrar modal si existe
    const modal = form.closest('.modal');
    if (modal) {
        closeModal();
    }
    
    // Recargar datos si es necesario
    if (typeof loadPageData !== 'undefined') {
        loadPageData();
    }
}

// Sistema de notificaciones
function showNotification(message, type = 'info') {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close"><i class="fas fa-times"></i></button>
    `;
    
    // Estilos para la notificación
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 15px 20px;
        border-radius: 4px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: space-between;
        min-width: 300px;
        max-width: 500px;
        animation: slideInRight 0.3s ease-out;
    `;
    
    // Añadir al documento
    document.body.appendChild(notification);
    
    // Configurar cierre automático
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', function() {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    });
    
    // Cerrar automáticamente después de 5 segundos
    setTimeout(() => {
        if (notification.parentNode) {
            closeBtn.click();
        }
    }, 5000);
}

function getNotificationIcon(type) {
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    return icons[type] || 'fa-info-circle';
}

function getNotificationColor(type) {
    const colors = {
        success: '#27ae60',
        error: '#e74c3c',
        warning: '#f39c12',
        info: '#3498db'
    };
    return colors[type] || '#3498db';
}

// Utilidades para fechas
function formatDate(dateString, format = 'DD/MM/YYYY') {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    
    if (format === 'DD/MM/YYYY') {
        return `${day}/${month}/${year}`;
    }
    
    return dateString;
}

// Animación CSS para notificaciones
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .field-error {
        color: #e74c3c;
        font-size: 12px;
        margin-top: 5px;
    }
    
    .form-control.error {
        border-color: #e74c3c;
    }
`;
document.head.appendChild(style);

document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  // Simulamos usuario válido
  if (username === "admin" && password === "guinea2025") {
    sessionStorage.setItem("loggedIn", "true");
    sessionStorage.setItem("user", username);
    window.location.href = "dashboard.html";
  } else {
    alert("Usuario o contraseña incorrectos");
  }
});
