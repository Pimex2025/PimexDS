from tkinter import *



root= Tk()
root.title('window')

Label(root, text="hola mundo").pack()




root.mainloop()