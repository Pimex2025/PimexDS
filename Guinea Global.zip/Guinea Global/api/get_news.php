<?php
// api/get_news.php
header('Content-Type: application/json');
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Obtener parámetros
$section = $_GET['section'] ?? '';
$category = $_GET['category'] ?? '';
$limit = $_GET['limit'] ?? 10;
$offset = $_GET['offset'] ?? 0;

// Construir consulta
$query = "
    SELECT n.id, n.title, n.excerpt, n.content, n.image, n.published_at, 
           s.name as section_name, s.slug as section_slug,
           c.name as category_name, c.slug as category_slug,
           u.full_name as author_name
    FROM news n
    LEFT JOIN sections s ON n.section_id = s.id
    LEFT JOIN categories c ON n.category_id = c.id
    LEFT JOIN users u ON n.author_id = u.id
    WHERE n.status = 'published' AND n.published_at <= NOW()
";

$params = [];

if (!empty($section)) {
    $query .= " AND s.slug = :section";
    $params[':section'] = $section;
}

if (!empty($category)) {
    $query .= " AND c.slug = :category";
    $params[':category'] = $category;
}

$query .= " ORDER BY n.published_at DESC LIMIT :limit OFFSET :offset";

// Ejecutar consulta
$stmt = $db->prepare($query);
$stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);

foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}

$stmt->execute();
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Formatear respuesta
foreach ($news as &$item) {
    if ($item['image']) {
        $item['image_url'] = '/guinea-global/uploads/news/' . $item['image'];
    }
    $item['published_at_formatted'] = date('d/m/Y H:i', strtotime($item['published_at']));
}

echo json_encode([
    'success' => true,
    'data' => $news,
    'total' => count($news)
]);
?>